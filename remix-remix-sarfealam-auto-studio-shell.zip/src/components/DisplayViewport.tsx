import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Monitor,
  Maximize2,
  Minimize2,
  PictureInPicture2,
  Expand,
  Shrink,
  FileCode2,
  Check,
  X,
  Sparkles,
  PauseCircle,
  PlayCircle,
  ChevronRight,
  Archive,
  RotateCw,
  Gamepad2,
  Smartphone,
  Radio,
  Play,
  Square,
  Download,
  CheckCircle2,
  AlertTriangle,
  Wrench,
  Loader2,
} from 'lucide-react';
import {
  PIPELINE_STAGES,
  parseStageNumber,
} from '../services/pipelineController';
import {
  downloadBroadcastBlob,
  playTwoVoiceBroadcast,
  stopTwoVoiceBroadcast,
  type BroadcastLine,
} from '../services/broadcastStudioService';
import {
  injectPreviewErrorSpy,
  isPreviewTelemetryMessage,
} from '../services/previewErrorSpy';
import {
  AssetPickerList,
  stopAssetPreviewAudio,
} from './AssetPickerList';
import {
  TARGET_ENGINES,
  type DisplayMode,
  type Language,
  type PreviewVerifyState,
  type StudioApiKeyEntry,
  type StudioAssetItem,
  type TargetEngine,
  type VirtualFile,
} from '../types/studio';

function escapeHtmlText(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function buildPreviewSrcDoc(
  files: VirtualFile[],
  projectName: string,
  stageLabel: string
): string {
  const rootIndex = files.find((f) => f.path.toLowerCase() === 'index.html');
  const docsIndex = files.find((f) => f.path.toLowerCase() === 'docs/index.html');
  const htmlFile =
    rootIndex && docsIndex
      ? rootIndex.updatedAt >= docsIndex.updatedAt
        ? rootIndex
        : docsIndex
      : rootIndex ??
        docsIndex ??
        files.find((f) => f.path.toLowerCase().endsWith('.html'));

  const cssBlocks = files
    .filter((f) => f.path.toLowerCase().endsWith('.css'))
    .map(
      (f) =>
        `<style data-studio-file="${escapeHtmlText(f.path)}">\n${f.content.replace(
          /<\/style>/gi,
          '<\\/style>'
        )}\n</style>`
    )
    .join('\n');

  const jsBlocks = files
    .filter((f) => {
      const lower = f.path.toLowerCase();
      if (!lower.endsWith('.js')) return false;
      // Skip common bundler config files that expect Node require/export
      if (/(vite|tailwind|postcss|eslint|webpack|rollup)\.config\.js$/.test(lower)) {
        return false;
      }
      return true;
    })
    .map((f) => {
      const safeJs = f.content
        .replace(/<\/script>/gi, '<\\/script>')
        .replace(/^\s*import\s+.*?;?\s*$/gm, '')
        .replace(/^\s*export\s+default\s+/gm, '')
        .replace(/^\s*export\s+/gm, '');
      return `<script data-studio-file="${escapeHtmlText(
        f.path
      )}">\ntry {\n${safeJs}\n} catch (err) { console.error(err); }\n</script>`;
    })
    .join('\n');

  const baseStyle = `<style>
    *, *::before, *::after { box-sizing: border-box; }
    html, body { margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; background: #F8FAFE; color: #0F172A; }
    #studio-stage { min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 14px; font-weight: 700; color: #0F172A; background: radial-gradient(circle at 20% 20%, rgba(0,122,255,0.12), transparent 55%), radial-gradient(circle at 80% 80%, rgba(16,185,129,0.12), transparent 55%), #F8FAFE; }
  </style>`;

  if (htmlFile) {
    if (
      htmlFile.content.includes('id="studio-game-config"') ||
      htmlFile.content.includes('id="studio-commercial-app-config"')
    ) {
      return htmlFile.content;
    }
    let doc = htmlFile.content;
    const headInject = `${baseStyle}\n${cssBlocks}`;
    if (/<\/head>/i.test(doc)) {
      doc = doc.replace(/<\/head>/i, `${headInject}\n</head>`);
    } else if (/<head[^>]*>/i.test(doc)) {
      doc = doc.replace(/<head[^>]*>/i, (m) => `${m}\n${headInject}`);
    } else {
      doc = `<!doctype html><html><head><meta charset="UTF-8" />${headInject}</head><body>${doc}</body></html>`;
    }

    if (jsBlocks) {
      if (/<\/body>/i.test(doc)) {
        doc = doc.replace(/<\/body>/i, `${jsBlocks}\n</body>`);
      } else {
        doc += `\n${jsBlocks}`;
      }
    }
    return doc;
  }

  return `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    ${baseStyle}
    ${cssBlocks}
  </head>
  <body>
    <div id="studio-stage">
      <div style="text-align:center;max-width:280px;background:rgba(255,255,255,0.88);border:1px solid rgba(15,23,42,0.1);border-radius:16px;padding:16px;box-shadow:0 8px 24px rgba(15,23,42,0.06);">
        <div style="font-size:13px;font-weight:800;color:#0F172A;">${escapeHtmlText(
          projectName
        )}</div>
        <div style="font-size:11px;color:#64748B;margin-top:4px;">${escapeHtmlText(
          stageLabel
        )} · ${files.length} virtual files</div>
      </div>
    </div>
    ${jsBlocks}
  </body>
</html>`;
}

export interface BroadcastSessionData {
  id: number;
  topic: string;
  language: Language;
  lines: BroadcastLine[];
  providerUsed: string;
}

interface DisplayViewportProps {
  displayMode: DisplayMode;
  currentStage: string;
  targetEngine: TargetEngine;
  language: Language;
  projectName: string;
  paused: boolean;
  liveActive: boolean;
  activeFile: VirtualFile | null;
  files: VirtualFile[];
  filesCount: number;
  assetsCount: number;
  candidateAssets: StudioAssetItem[];
  selectedAssets: StudioAssetItem[];
  geminiApiKey?: string;
  keyPool?: StudioApiKeyEntry[];
  geminiTtsModel?: string;
  voiceSpeed?: number;
  broadcastSession?: BroadcastSessionData | null;
  onDisplayModeChange: (mode: DisplayMode) => void;
  onStageChange: (stage: string) => void;
  onAdvanceStage?: () => void;
  onOpenCode: () => void;
  onBuild3DGame?: () => void;
  isBuilding3DGame?: boolean;
  onBuildCommercialApp?: () => void;
  isBuildingCommercialApp?: boolean;
  onCreateBroadcast?: () => void;
  isCreatingBroadcast?: boolean;
  onFixPreviewError?: (errorMessage: string) => void;
  isFixingPreviewError?: boolean;
  previewVerifyState?: PreviewVerifyState;
  onKeepAsset: (item: StudioAssetItem) => void;
  onRejectAsset: (item: StudioAssetItem) => void;
  onRemoveSelectedAsset: (item: StudioAssetItem) => void;
}

export function DisplayViewport({
  displayMode,
  currentStage,
  targetEngine,
  language,
  projectName,
  paused,
  liveActive,
  activeFile,
  files,
  filesCount,
  assetsCount,
  candidateAssets,
  selectedAssets,
  geminiApiKey,
  keyPool,
  geminiTtsModel,
  voiceSpeed = 1.05,
  broadcastSession = null,
  onDisplayModeChange,
  onStageChange,
  onAdvanceStage,
  onOpenCode,
  onBuild3DGame,
  isBuilding3DGame = false,
  onBuildCommercialApp,
  isBuildingCommercialApp = false,
  onCreateBroadcast,
  isCreatingBroadcast = false,
  onFixPreviewError,
  isFixingPreviewError = false,
  previewVerifyState,
  onKeepAsset,
  onRejectAsset,
  onRemoveSelectedAsset,
}: DisplayViewportProps) {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [viewTab, setViewTab] = useState<'preview' | 'assets' | 'broadcast'>('preview');
  const [previewKey, setPreviewKey] = useState(0);
  const [previewHealth, setPreviewHealth] = useState<{
    status: 'checking' | 'ok' | 'error';
    message: string;
  }>({ status: 'checking', message: 'Checking preview...' });
  const [broadcastPlaying, setBroadcastPlaying] = useState(false);
  const [broadcastLineIdx, setBroadcastLineIdx] = useState(-1);
  const [broadcastBlob, setBroadcastBlob] = useState<Blob | null>(null);
  const previewIframeRef = useRef<HTMLIFrameElement | null>(null);
  const broadcastCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const lastStartedBroadcastIdRef = useRef<number>(0);

  const hasReviewableAssets =
    candidateAssets.length > 0 || selectedAssets.length > 0;
  const hasBroadcast = Boolean(broadcastSession && broadcastSession.lines.length > 0);
  const assetsBadgeCount =
    candidateAssets.length > 0 ? candidateAssets.length : selectedAssets.length;
  const effectiveTab: 'preview' | 'assets' | 'broadcast' =
    viewTab === 'broadcast' && hasBroadcast
      ? 'broadcast'
      : viewTab === 'assets' && hasReviewableAssets
        ? 'assets'
        : 'preview';

  // Stop inline audio preview cleanly if Display A collapses or leaves Assets view
  useEffect(() => {
    if (displayMode === 'collapsed' || effectiveTab !== 'assets') {
      stopAssetPreviewAudio();
    }
  }, [displayMode, effectiveTab]);

  // Stop active 2-voice broadcast on unmount
  useEffect(() => {
    return () => {
      stopTwoVoiceBroadcast();
    };
  }, []);

  // Auto-open Broadcast tab & launch 2-voice 9:16 playback when a new broadcast session arrives
  useEffect(() => {
    if (!broadcastSession || broadcastSession.lines.length === 0) return;
    if (lastStartedBroadcastIdRef.current === broadcastSession.id) return;
    lastStartedBroadcastIdRef.current = broadcastSession.id;
    setViewTab('broadcast');
    setBroadcastBlob(null);

    const timerId = window.setTimeout(() => {
      setBroadcastPlaying(true);
      setBroadcastLineIdx(0);
      void playTwoVoiceBroadcast({
        lines: broadcastSession.lines,
        geminiKey: geminiApiKey,
        keyPool,
        ttsModel: geminiTtsModel,
        language: broadcastSession.language,
        voiceSpeed,
        canvasEl: broadcastCanvasRef.current,
        recordVideo: true,
        onLineChange: (idx) => {
          setBroadcastLineIdx(idx);
        },
        onRecordingReady: (blob) => {
          setBroadcastBlob(blob);
        },
      }).finally(() => {
        setBroadcastPlaying(false);
      });
    }, 80);

    return () => window.clearTimeout(timerId);
  }, [broadcastSession, geminiApiKey, geminiTtsModel, keyPool, voiceSpeed]);

  const handleReplayBroadcast = () => {
    if (!broadcastSession || broadcastSession.lines.length === 0) return;
    setBroadcastBlob(null);
    setBroadcastPlaying(true);
    setBroadcastLineIdx(0);
    void playTwoVoiceBroadcast({
      lines: broadcastSession.lines,
      geminiKey: geminiApiKey,
      keyPool,
      ttsModel: geminiTtsModel,
      language: broadcastSession.language,
      voiceSpeed,
      canvasEl: broadcastCanvasRef.current,
      recordVideo: true,
      onLineChange: (idx) => {
        setBroadcastLineIdx(idx);
      },
      onRecordingReady: (blob) => {
        setBroadcastBlob(blob);
      },
    }).finally(() => {
      setBroadcastPlaying(false);
    });
  };

  const handleStopBroadcast = () => {
    stopTwoVoiceBroadcast();
    setBroadcastPlaying(false);
    setBroadcastLineIdx(-1);
  };

  const engineLabel =
    TARGET_ENGINES.find((item) => item.value === targetEngine)?.label ?? 'Auto';
  const stageNum = parseStageNumber(currentStage);
  const activeStageIndex = stageNum - 1;
  const activeStageInfo = PIPELINE_STAGES[activeStageIndex];

  const previewSrcDoc = useMemo(
    () =>
      injectPreviewErrorSpy(
        buildPreviewSrcDoc(files, projectName, activeStageInfo.label)
      ),
    [files, projectName, activeStageInfo.label]
  );

  // Reset telemetry health check whenever preview HTML or reload key updates
  useEffect(() => {
    setPreviewHealth({ status: 'checking', message: 'Checking preview...' });
  }, [previewSrcDoc, previewKey]);

  // Listen to postMessage telemetry bridge from Display A preview iframe
  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (!isPreviewTelemetryMessage(event.data)) return;
      if (
        previewIframeRef.current &&
        event.source &&
        event.source !== previewIframeRef.current.contentWindow
      ) {
        return;
      }
      const payload = event.data;
      if (payload.type === 'error') {
        setPreviewHealth({
          status: 'error',
          message: payload.message || 'Runtime error detected in preview.',
        });
      } else {
        setPreviewHealth((prev) =>
          prev.status === 'error'
            ? prev
            : {
                status: 'ok',
                message: payload.message || 'Preview rendered cleanly',
              }
        );
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  const previewEntryFile = useMemo(() => {
    const rootIndex = files.find((f) => f.path.toLowerCase() === 'index.html');
    const docsIndex = files.find((f) => f.path.toLowerCase() === 'docs/index.html');
    return rootIndex && docsIndex
      ? rootIndex.updatedAt >= docsIndex.updatedAt
        ? rootIndex
        : docsIndex
      : rootIndex ??
        docsIndex ??
        files.find((f) => f.path.toLowerCase().endsWith('.html')) ??
        null;
  }, [files]);

  const previewEntryName =
    previewEntryFile?.path ?? activeFile?.path ?? projectName;

  // Automatically remount iframe when root index.html is freshly generated
  useEffect(() => {
    if (previewEntryFile?.path.toLowerCase() === 'index.html') {
      setViewTab('preview');
      setPreviewKey((k) => k + 1);
    }
  }, [previewEntryFile?.path, previewEntryFile?.updatedAt]);

  // Collapsed Mode: Compact 1-line Apple pill
  if (displayMode === 'collapsed' && !isFullscreen) {
    return (
      <section aria-label="Display A Collapsed">
        <button
          type="button"
          onClick={() => onDisplayModeChange('expanded')}
          className={`w-full h-11 px-3.5 rounded-full bg-white/85 backdrop-blur-xl border shadow-[0_6px_22px_rgba(15,23,42,0.06)] flex items-center justify-between gap-2 transition-all active:scale-[0.99] cursor-pointer ${
            paused
              ? 'border-[#F59E0B]/45 hover:border-[#F59E0B]'
              : 'border-slate-200/85 hover:border-[#007AFF]/40'
          }`}
        >
          <div className="flex items-center gap-2 min-w-0">
            <span
              className={`w-6 h-6 rounded-full text-white flex items-center justify-center shrink-0 ${
                paused
                  ? 'bg-gradient-to-br from-[#F59E0B] to-[#D97706]'
                  : 'bg-gradient-to-br from-[#007AFF] to-[#5856D6]'
              }`}
              aria-hidden="true"
            >
              <Monitor className="w-3.5 h-3.5" />
            </span>
            <span className="text-[12.5px] font-bold text-[#0F172A] truncate whitespace-nowrap">
              Display A · Tap to Expand
            </span>
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            <span
              className={`text-[10.5px] font-semibold whitespace-nowrap ${
                paused ? 'text-[#B45309]' : 'text-[#64748B]'
              }`}
            >
              {paused ? `Paused · Stage ${stageNum}` : `Stage ${stageNum}`}
            </span>
            <Maximize2
              className="w-3.5 h-3.5 text-[#007AFF] shrink-0"
              aria-hidden="true"
            />
          </div>
        </button>
      </section>
    );
  }

  // Floating Mode: Smooth floating mini-window so user scrolls freely
  if (displayMode === 'floating' && !isFullscreen) {
    return (
      <aside
        aria-label="Floating Display A Mini-Window"
        className={`fixed bottom-24 right-3 w-44 z-40 rounded-2xl shadow-xl mb-1.5 bg-white/92 backdrop-blur-2xl border overflow-hidden ${
          paused ? 'border-[#F59E0B]/45' : 'border-[#5856D6]/30'
        }`}
      >
        <div
          className={`px-2.5 py-2 border-b border-slate-200/75 flex items-center justify-between gap-1 ${
            paused
              ? 'bg-[#F59E0B]/12'
              : 'bg-gradient-to-r from-[#007AFF]/10 via-[#5856D6]/10 to-[#10B981]/10'
          }`}
        >
          <div className="flex items-center gap-1.5 min-w-0">
            <Monitor
              className={`w-3.5 h-3.5 shrink-0 ${
                paused ? 'text-[#D97706]' : 'text-[#5856D6]'
              }`}
              aria-hidden="true"
            />
            <span className="text-[11px] font-bold text-[#0F172A] truncate">
              Display A
            </span>
          </div>
          <span
            className={`text-[10px] font-mono font-semibold tabular-nums shrink-0 ${
              paused ? 'text-[#B45309]' : 'text-[#5856D6]'
            }`}
          >
            {paused ? `Hold ${stageNum}/5` : `${stageNum}/5`}
          </span>
        </div>

        <div className="p-2.5 flex flex-col gap-2">
          {hasReviewableAssets && (
            <div className="grid grid-cols-2 gap-1 p-0.5 rounded-lg bg-slate-100 border border-slate-200/80">
              <button
                type="button"
                onClick={() => setViewTab('preview')}
                aria-pressed={effectiveTab === 'preview'}
                className={`h-6 rounded-md text-[9.5px] font-bold transition-all cursor-pointer ${
                  effectiveTab === 'preview'
                    ? 'bg-white text-[#0F172A] shadow-2xs'
                    : 'text-[#64748B]'
                }`}
              >
                Preview
              </button>
              <button
                type="button"
                onClick={() => setViewTab('assets')}
                aria-pressed={effectiveTab === 'assets'}
                className={`h-6 rounded-md text-[9.5px] font-bold transition-all cursor-pointer tabular-nums truncate ${
                  effectiveTab === 'assets'
                    ? 'bg-[#10B981] text-white shadow-2xs'
                    : 'text-[#64748B]'
                }`}
              >
                Assets ({assetsBadgeCount})
              </button>
            </div>
          )}

          {effectiveTab === 'assets' && hasReviewableAssets ? (
            <div className="rounded-xl bg-[#F6F9FE] border border-slate-200/75 p-1.5 flex flex-col gap-1.5 max-h-36 overflow-y-auto studio-scroll">
              {(candidateAssets.length > 0 ? candidateAssets : selectedAssets)
                .slice(0, 4)
                .map((item, idx) => {
                  const isKept = selectedAssets.some(
                    (s) => s.id === item.id || (Boolean(s.url) && s.url === item.url)
                  );
                  return (
                    <div
                      key={item.id}
                      className="rounded-lg bg-white border border-slate-200/80 px-1.5 py-1 flex items-center justify-between gap-1 min-w-0"
                    >
                      <span className="text-[9.5px] font-semibold text-[#0F172A] truncate">
                        #{idx + 1} {item.name}
                      </span>
                      <div className="flex items-center gap-0.5 shrink-0">
                        <button
                          type="button"
                          onClick={() =>
                            isKept ? onRemoveSelectedAsset(item) : onKeepAsset(item)
                          }
                          aria-label={isKept ? `Remove ${item.name}` : `Keep ${item.name}`}
                          className={`w-5 h-5 rounded-md flex items-center justify-center cursor-pointer ${
                            isKept
                              ? 'bg-[#10B981] text-white'
                              : 'bg-[#10B981]/15 text-[#047857]'
                          }`}
                        >
                          <Check className="w-3 h-3" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onRejectAsset(item)}
                          aria-label={`Reject ${item.name}`}
                          className="w-5 h-5 rounded-md bg-[#FF3B30]/12 text-[#DC2626] flex items-center justify-center cursor-pointer"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  );
                })}
            </div>
          ) : (
            <div className="rounded-xl bg-[#F6F9FE] border border-slate-200/75 px-2 py-1.5">
              <p className="text-[10.5px] font-bold text-[#0F172A] truncate">
                {activeFile ? activeFile.path : projectName}
              </p>
              <p className="text-[10px] text-[#64748B] truncate mt-0.5">
                {paused
                  ? `Paused · Inspect`
                  : `${engineLabel} · ${activeStageInfo.short}`}
              </p>
            </div>
          )}

          <div className="grid grid-cols-2 gap-1">
            <button
              type="button"
              onClick={() => onDisplayModeChange('expanded')}
              className="h-7 px-1.5 rounded-lg bg-[#007AFF] hover:bg-[#0066D6] text-white text-[10.5px] font-semibold inline-flex items-center justify-center gap-1 transition-all cursor-pointer active:scale-95 whitespace-nowrap"
            >
              <Maximize2 className="w-3 h-3 shrink-0" aria-hidden="true" />
              <span>Expand</span>
            </button>
            <button
              type="button"
              onClick={() => onDisplayModeChange('collapsed')}
              className="h-7 px-1.5 rounded-lg bg-slate-100 hover:bg-slate-200/80 text-[#0F172A] text-[10.5px] font-semibold inline-flex items-center justify-center gap-1 transition-all cursor-pointer active:scale-95 whitespace-nowrap"
            >
              <Minimize2
                className="w-3 h-3 shrink-0 text-[#F59E0B]"
                aria-hidden="true"
              />
              <span>Collapse</span>
            </button>
          </div>
        </div>
      </aside>
    );
  }

  // Expanded Mode (and Fullscreen Overlay)
  const cardContent = (
    <div
      className={`relative bg-white/88 backdrop-blur-xl rounded-2xl border shadow-[0_8px_30px_rgba(15,23,42,0.07),0_0_0_1px_rgba(88,86,214,0.08)] overflow-hidden transition-all ${
        paused ? 'border-[#F59E0B]/40' : 'border-[#007AFF]/20'
      } ${
        isFullscreen
          ? 'w-full max-w-4xl h-[calc(100dvh-2rem)] flex flex-col'
          : ''
      }`}
    >
      {/* Subtle top colorful Apple accent sheen */}
      <div
        aria-hidden="true"
        className={`h-[2.5px] w-full ${
          paused
            ? 'bg-gradient-to-r from-[#F59E0B] via-[#FBBF24] to-[#D97706]'
            : 'bg-gradient-to-r from-[#007AFF] via-[#5856D6] to-[#10B981]'
        }`}
      />

      {/* Header Controls */}
      <div className="px-3 py-2.5 flex items-center justify-between gap-2 border-b border-slate-200/70">
        <div className="flex items-center gap-2 min-w-0">
          <div
            className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${
              paused
                ? 'bg-[#F59E0B]/15 text-[#D97706]'
                : 'bg-gradient-to-br from-[#007AFF]/15 to-[#5856D6]/15 text-[#007AFF]'
            }`}
            aria-hidden="true"
          >
            <Monitor className="w-3.5 h-3.5 stroke-[2.2]" />
          </div>
          <div className="min-w-0">
            <h2 className="text-[12.5px] sm:text-[13.5px] font-bold text-[#0F172A] tracking-tight truncate">
              Display A
            </h2>
          </div>
        </div>

        <div className="flex items-center gap-1 shrink-0">
          {!isFullscreen && (
            <>
              <button
                type="button"
                onClick={() => onDisplayModeChange('expanded')}
                aria-pressed={displayMode === 'expanded'}
                className="px-2 h-7 rounded-full bg-[#007AFF] text-white text-[10.5px] font-semibold inline-flex items-center gap-1 shadow-xs whitespace-nowrap cursor-pointer"
              >
                <Maximize2 className="w-3 h-3 shrink-0" aria-hidden="true" />
                <span>Expand</span>
              </button>
              <button
                type="button"
                onClick={() => onDisplayModeChange('floating')}
                aria-pressed={displayMode === 'floating'}
                className="px-2 h-7 rounded-full bg-slate-100/95 hover:bg-[#5856D6]/12 text-[#64748B] hover:text-[#5856D6] text-[10.5px] font-semibold inline-flex items-center gap-1 transition-colors whitespace-nowrap cursor-pointer"
              >
                <PictureInPicture2
                  className="w-3 h-3 shrink-0"
                  aria-hidden="true"
                />
                <span>Float</span>
              </button>
              <button
                type="button"
                onClick={() => onDisplayModeChange('collapsed')}
                aria-pressed={displayMode === 'collapsed'}
                className="px-2 h-7 rounded-full bg-slate-100/95 hover:bg-[#F59E0B]/15 text-[#64748B] hover:text-[#D97706] text-[10.5px] font-semibold inline-flex items-center gap-1 transition-colors whitespace-nowrap cursor-pointer"
              >
                <Minimize2 className="w-3 h-3 shrink-0" aria-hidden="true" />
                <span className="hidden min-[390px]:inline">Collapse</span>
              </button>
            </>
          )}

          {/* Fullscreen Toggle Button */}
          <button
            type="button"
            onClick={() => setIsFullscreen((prev) => !prev)}
            aria-label={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen Preview'}
            title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen Preview'}
            className={`w-7 h-7 rounded-full flex items-center justify-center transition-colors shrink-0 cursor-pointer ${
              isFullscreen
                ? 'bg-[#0F172A] text-white hover:bg-slate-800'
                : 'bg-slate-100/95 text-[#0F172A] hover:bg-slate-200/80'
            }`}
          >
            {isFullscreen ? (
              <Shrink className="w-3.5 h-3.5" />
            ) : (
              <Expand className="w-3.5 h-3.5" />
            )}
          </button>
        </div>
      </div>

      {/* 5-Stage Progress Strip */}
      <div className="px-3 pt-2.5 pb-1.5">
        <div
          className="grid grid-cols-5 gap-1 w-full"
          role="group"
          aria-label="Build Stages"
        >
          {PIPELINE_STAGES.map((stage, index) => {
            const isCompleted = index < activeStageIndex;
            const isCurrent = index === activeStageIndex;
            return (
              <button
                key={stage.label}
                type="button"
                onClick={() => onStageChange(stage.label)}
                aria-pressed={isCurrent}
                className={`px-1 py-1.5 rounded-xl border text-center transition-all min-w-0 cursor-pointer active:scale-[0.97] ${
                  isCurrent
                    ? paused
                      ? 'bg-[#F59E0B] border-[#F59E0B] text-white shadow-[0_2px_10px_rgba(245,158,11,0.28)]'
                      : 'bg-[#007AFF] border-[#007AFF] text-white shadow-[0_2px_10px_rgba(0,122,255,0.24)]'
                    : isCompleted
                      ? 'bg-[#10B981]/10 border-[#10B981]/30 text-[#047857]'
                      : 'bg-slate-50/90 border-slate-200/80 text-[#64748B] hover:text-[#0F172A] hover:bg-slate-100'
                }`}
              >
                <div className="flex items-center justify-center gap-0.5 text-[10px] font-bold tabular-nums leading-none">
                  {isCompleted ? (
                    <Check className="w-2.5 h-2.5 shrink-0" aria-hidden="true" />
                  ) : (
                    <span>{stage.number}.</span>
                  )}
                  <span className="truncate">{stage.short}</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Cooperative Pipeline Status Badge: Running · Stage N OR Paused at Stage N — Inspect Mode */}
      <div className="px-3 pb-2 flex items-center justify-between gap-1.5">
        <div
          className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-[11px] font-semibold min-w-0 max-w-full ${
            paused
              ? 'bg-[#F59E0B]/14 border-[#F59E0B]/35 text-[#B45309]'
              : 'bg-[#10B981]/10 border-[#10B981]/25 text-[#047857]'
          }`}
        >
          {paused ? (
            <PauseCircle className="w-3.5 h-3.5 shrink-0 text-[#D97706]" aria-hidden="true" />
          ) : (
            <PlayCircle className="w-3.5 h-3.5 shrink-0 text-[#10B981]" aria-hidden="true" />
          )}
          <span className="truncate tabular-nums">
            {paused
              ? `Paused at Stage ${stageNum} — Inspect Mode`
              : `Running · Stage ${stageNum}`}
          </span>
        </div>

        {onAdvanceStage && !paused && stageNum < 5 && (
          <button
            type="button"
            onClick={onAdvanceStage}
            className="h-6 px-2 rounded-full bg-slate-100 hover:bg-[#007AFF]/12 text-[#0F172A] hover:text-[#007AFF] text-[10.5px] font-semibold inline-flex items-center gap-0.5 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <span>Next</span>
            <ChevronRight className="w-3 h-3 shrink-0" aria-hidden="true" />
          </button>
        )}
      </div>

      {/* Display A Sub-Pill: Preview | Broadcast | Assets (N) */}
      {(hasReviewableAssets || hasBroadcast) && (
        <div className="px-3 pb-2 flex items-center justify-between gap-2 flex-wrap">
          <div
            className="inline-flex items-center p-0.5 rounded-full bg-slate-100/95 border border-slate-200/80"
            role="tablist"
            aria-label="Display A View Mode"
          >
            <button
              type="button"
              role="tab"
              aria-selected={effectiveTab === 'preview'}
              onClick={() => setViewTab('preview')}
              className={`h-7 px-2.5 rounded-full text-[11px] font-bold inline-flex items-center gap-1 transition-all cursor-pointer whitespace-nowrap ${
                effectiveTab === 'preview'
                  ? 'bg-white text-[#0F172A] shadow-2xs'
                  : 'text-[#64748B] hover:text-[#0F172A]'
              }`}
            >
              <Monitor className="w-3 h-3 shrink-0" aria-hidden="true" />
              <span>Preview</span>
            </button>
            {hasBroadcast && (
              <button
                type="button"
                role="tab"
                aria-selected={effectiveTab === 'broadcast'}
                onClick={() => setViewTab('broadcast')}
                className={`h-7 px-2.5 rounded-full text-[11px] font-bold inline-flex items-center gap-1 transition-all cursor-pointer whitespace-nowrap ${
                  effectiveTab === 'broadcast'
                    ? 'bg-gradient-to-r from-[#EC4899] to-[#F59E0B] text-white shadow-2xs'
                    : 'text-[#64748B] hover:text-[#0F172A]'
                }`}
              >
                <Radio className="w-3 h-3 shrink-0" aria-hidden="true" />
                <span>Broadcast</span>
              </button>
            )}
            {hasReviewableAssets && (
              <button
                type="button"
                role="tab"
                aria-selected={effectiveTab === 'assets'}
                onClick={() => setViewTab('assets')}
                className={`h-7 px-2.5 rounded-full text-[11px] font-bold inline-flex items-center gap-1 transition-all cursor-pointer whitespace-nowrap tabular-nums ${
                  effectiveTab === 'assets'
                    ? 'bg-gradient-to-r from-[#10B981] to-[#007AFF] text-white shadow-2xs'
                    : 'text-[#64748B] hover:text-[#0F172A]'
                }`}
              >
                <Archive className="w-3 h-3 shrink-0" aria-hidden="true" />
                <span>Assets ({assetsBadgeCount})</span>
              </button>
            )}
          </div>

          {hasReviewableAssets && (
            <span className="text-[10px] font-mono text-[#047857] font-semibold tabular-nums shrink-0">
              {selectedAssets.length} kept
            </span>
          )}
        </div>
      )}

      {/* Preview Stage Canvas OR Interactive Display A Asset Picker OR 9:16 Broadcast Studio */}
      <div className={`px-3 pb-3 ${isFullscreen ? 'flex-1 flex flex-col min-h-0' : ''}`}>
        {effectiveTab === 'broadcast' && broadcastSession ? (
          <div
            className={`rounded-xl border border-slate-200/80 bg-gradient-to-br from-[#0F172A] via-[#1E1B4B] to-[#0F172A] p-2.5 flex flex-col gap-2 text-white ${
              isFullscreen ? 'flex-1 min-h-0' : ''
            }`}
          >
            <div className="flex items-center justify-between gap-2 min-w-0">
              <div className="min-w-0">
                <p className="text-[11.5px] font-bold text-white truncate">
                  {broadcastSession.topic}
                </p>
                <p className="text-[10px] text-sky-300 truncate">
                  Aoede (Host A) ↔ Charon (Host B) · {broadcastSession.providerUsed}
                </p>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                {broadcastPlaying ? (
                  <button
                    type="button"
                    onClick={handleStopBroadcast}
                    className="h-7 px-2 rounded-lg bg-[#EF4444] hover:bg-[#DC2626] text-white text-[10.5px] font-bold inline-flex items-center gap-1 cursor-pointer active:scale-95"
                  >
                    <Square className="w-3 h-3 shrink-0" aria-hidden="true" />
                    <span>Stop</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={handleReplayBroadcast}
                    className="h-7 px-2 rounded-lg bg-[#10B981] hover:bg-[#059669] text-white text-[10.5px] font-bold inline-flex items-center gap-1 cursor-pointer active:scale-95"
                  >
                    <Play className="w-3 h-3 shrink-0" aria-hidden="true" />
                    <span>Play</span>
                  </button>
                )}
                {broadcastBlob && (
                  <button
                    type="button"
                    onClick={() =>
                      downloadBroadcastBlob(
                        broadcastBlob,
                        `${broadcastSession.topic
                          .toLowerCase()
                          .replace(/[^a-z0-9]+/g, '-')
                          .slice(0, 28) || 'broadcast'}-9x16.webm`
                      )
                    }
                    className="h-7 px-2 rounded-lg bg-[#007AFF] hover:bg-[#0066D6] text-white text-[10.5px] font-bold inline-flex items-center gap-1 cursor-pointer active:scale-95"
                  >
                    <Download className="w-3 h-3 shrink-0" aria-hidden="true" />
                    <span>WebM</span>
                  </button>
                )}
              </div>
            </div>

            <div className="flex items-center justify-center gap-2.5 min-w-0">
              <canvas
                ref={broadcastCanvasRef}
                width={360}
                height={640}
                className={`rounded-xl border border-white/15 bg-[#09152B] shadow-lg ${
                  isFullscreen ? 'h-[360px] w-[202px]' : 'h-[196px] w-[110px]'
                } shrink-0`}
              />
              <div className="flex-1 min-w-0 flex flex-col gap-1.5 max-h-[196px] overflow-y-auto studio-scroll">
                {broadcastSession.lines.map((line, idx) => {
                  const isActive = idx === broadcastLineIdx;
                  return (
                    <div
                      key={line.id}
                      className={`rounded-lg px-2 py-1.5 text-[10px] leading-snug border transition-all ${
                        isActive
                          ? line.speaker === 'Host A'
                            ? 'bg-sky-500/25 border-sky-400/70 text-white'
                            : 'bg-pink-500/25 border-pink-400/70 text-white'
                          : 'bg-white/6 border-white/10 text-slate-300'
                      }`}
                    >
                      <span
                        className={`font-bold mr-1 ${
                          line.speaker === 'Host A' ? 'text-sky-300' : 'text-pink-300'
                        }`}
                      >
                        {line.speaker}:
                      </span>
                      <span>{line.text}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        ) : effectiveTab === 'assets' && hasReviewableAssets ? (
          <div
            className={`rounded-xl border border-slate-200/80 bg-gradient-to-br from-[#F7FAFF] via-white to-[#F2FBF7] p-2.5 flex flex-col gap-2 ${
              isFullscreen
                ? 'flex-1 min-h-0 overflow-y-auto studio-scroll'
                : 'max-h-[320px] overflow-y-auto studio-scroll'
            }`}
          >
            <AssetPickerList
              candidates={candidateAssets}
              selectedAssets={selectedAssets}
              language={language}
              compact={!isFullscreen}
              onKeep={onKeepAsset}
              onReject={onRejectAsset}
              onRemoveSelected={onRemoveSelectedAsset}
            />
          </div>
        ) : (
          <div
            className={`rounded-xl border border-slate-200/80 bg-gradient-to-br from-[#F7FAFF] via-white to-[#F4F3FF] p-2.5 flex flex-col justify-between gap-2 ${
              isFullscreen ? 'flex-1 min-h-0' : ''
            }`}
          >
            <div className="flex items-center justify-between gap-1.5 min-w-0">
              <div className="min-w-0">
                <div className="flex items-center gap-1.5 min-w-0">
                  <Sparkles
                    className="w-3.5 h-3.5 text-[#5856D6] shrink-0"
                    aria-hidden="true"
                  />
                  <p className="text-[12px] font-bold text-[#0F172A] truncate">
                    {previewEntryName}
                  </p>
                </div>
                <p className="text-[10.5px] text-[#64748B] truncate">
                  {language === 'hi'
                    ? `लाइव प्रीव्यू · इंजन: ${engineLabel}`
                    : `Live Preview · Engine: ${engineLabel}`}
                </p>
              </div>

              <div className="flex items-center gap-1 shrink-0">
                <button
                  type="button"
                  onClick={() => setPreviewKey((k) => k + 1)}
                  aria-label="Reload Preview"
                  title="Reload Preview"
                  className="h-7 px-2 rounded-lg bg-white border border-slate-200/90 hover:border-[#10B981]/50 text-[10.5px] font-semibold text-[#047857] inline-flex items-center gap-1 shadow-2xs transition-colors whitespace-nowrap shrink-0 cursor-pointer active:scale-95"
                >
                  <RotateCw className="w-3 h-3 shrink-0" aria-hidden="true" />
                  <span className="hidden min-[380px]:inline">Reload</span>
                </button>
                <button
                  type="button"
                  onClick={onOpenCode}
                  className="h-7 px-2 rounded-lg bg-white border border-slate-200/90 hover:border-[#007AFF]/45 text-[10.5px] font-semibold text-[#007AFF] inline-flex items-center gap-1 shadow-2xs transition-colors whitespace-nowrap shrink-0 cursor-pointer active:scale-95"
                >
                  <FileCode2 className="w-3 h-3 shrink-0" aria-hidden="true" />
                  <span>{language === 'hi' ? 'एडिट' : 'Edit'}</span>
                </button>
              </div>
            </div>

            {/* Compact Colorful Quick Launchers (fits 360px cleanly with horizontal wrap) */}
            {(onBuild3DGame || onBuildCommercialApp || onCreateBroadcast) && (
              <div className="flex flex-wrap items-center gap-1.5">
                {onBuild3DGame && (
                  <button
                    type="button"
                    onClick={onBuild3DGame}
                    disabled={isBuilding3DGame}
                    aria-label="Build and Launch 3D Game"
                    title="Build & Launch Pro 3D Three.js Game"
                    className="h-6 px-2 rounded-lg bg-gradient-to-r from-[#5856D6] via-[#007AFF] to-[#10B981] hover:brightness-105 text-[10px] font-bold text-white inline-flex items-center gap-1 shadow-xs transition-all whitespace-nowrap cursor-pointer active:scale-95 disabled:opacity-60"
                  >
                    <Gamepad2 className="w-3 h-3 shrink-0" aria-hidden="true" />
                    <span>{isBuilding3DGame ? '3D...' : '3D Game'}</span>
                  </button>
                )}
                {onBuildCommercialApp && (
                  <button
                    type="button"
                    onClick={onBuildCommercialApp}
                    disabled={isBuildingCommercialApp}
                    aria-label="Build Commercial App"
                    title="Build Zero-Shortcut Commercial Mobile App"
                    className="h-6 px-2 rounded-lg bg-gradient-to-r from-[#7C3AED] via-[#EC4899] to-[#F59E0B] hover:brightness-105 text-[10px] font-bold text-white inline-flex items-center gap-1 shadow-xs transition-all whitespace-nowrap cursor-pointer active:scale-95 disabled:opacity-60"
                  >
                    <Smartphone className="w-3 h-3 shrink-0" aria-hidden="true" />
                    <span>{isBuildingCommercialApp ? 'App...' : 'Commercial App'}</span>
                  </button>
                )}
                {onCreateBroadcast && (
                  <button
                    type="button"
                    onClick={onCreateBroadcast}
                    disabled={isCreatingBroadcast}
                    aria-label="Create 2-Voice Broadcast"
                    title="Create 2-Voice 9:16 Broadcast Short Video"
                    className="h-6 px-2 rounded-lg bg-gradient-to-r from-[#0EA5E9] via-[#6366F1] to-[#EC4899] hover:brightness-105 text-[10px] font-bold text-white inline-flex items-center gap-1 shadow-xs transition-all whitespace-nowrap cursor-pointer active:scale-95 disabled:opacity-60"
                  >
                    <Radio className="w-3 h-3 shrink-0" aria-hidden="true" />
                    <span>{isCreatingBroadcast ? 'Live...' : 'Broadcast'}</span>
                  </button>
                )}
              </div>
            )}

            {/* Instant Sandboxed <iframe srcDoc> Live Preview */}
            <div
              className={`w-full rounded-lg overflow-hidden border border-slate-200/85 bg-white shadow-inner ${
                isFullscreen ? 'flex-1 min-h-[260px]' : 'h-[176px] sm:h-[200px]'
              }`}
            >
              <iframe
                ref={previewIframeRef}
                key={previewKey}
                title="Display A Live Preview"
                sandbox="allow-scripts"
                srcDoc={previewSrcDoc}
                className="w-full h-full border-0 bg-white block"
              />
            </div>

            {/* PostMessage Preview Telemetry & Autonomous Self-Heal Status Strip */}
            <div
              className={`rounded-lg px-2 py-1 border flex items-center justify-between gap-2 min-w-0 ${
                previewVerifyState?.status === 'healing'
                  ? 'bg-[#5856D6]/10 border-[#5856D6]/35 text-[#4338CA]'
                  : previewHealth.status === 'error'
                    ? 'bg-[#FF3B30]/10 border-[#FF3B30]/35 text-[#B91C1C]'
                    : previewVerifyState?.status === 'verified' ||
                        previewHealth.status === 'ok'
                      ? 'bg-[#10B981]/10 border-[#10B981]/30 text-[#047857]'
                      : 'bg-slate-100/85 border-slate-200/80 text-[#64748B]'
              }`}
            >
              <div className="flex items-center gap-1.5 min-w-0 flex-1">
                {previewVerifyState?.status === 'healing' ? (
                  <>
                    <Loader2
                      className="w-3.5 h-3.5 animate-spin text-[#5856D6] shrink-0"
                      aria-hidden="true"
                    />
                    <span className="text-[10.5px] font-bold whitespace-nowrap shrink-0">
                      Self-Heal {previewVerifyState.attempt}/{previewVerifyState.maxAttempts}
                    </span>
                    <span
                      className="text-[10px] font-mono text-[#4338CA] truncate"
                      title={previewVerifyState.message}
                    >
                      {previewVerifyState.message}
                    </span>
                  </>
                ) : previewHealth.status === 'error' ? (
                  <>
                    <AlertTriangle
                      className="w-3.5 h-3.5 text-[#EF4444] shrink-0"
                      aria-hidden="true"
                    />
                    <span className="text-[10.5px] font-bold whitespace-nowrap shrink-0">
                      Runtime Error
                    </span>
                    <span
                      className="text-[10px] font-mono text-[#991B1B] truncate"
                      title={previewHealth.message}
                    >
                      {previewHealth.message}
                    </span>
                  </>
                ) : previewVerifyState?.status === 'verified' ? (
                  <>
                    <CheckCircle2
                      className="w-3.5 h-3.5 text-[#10B981] shrink-0"
                      aria-hidden="true"
                    />
                    <span className="text-[10.5px] font-bold whitespace-nowrap">
                      Preview Verified ✓
                    </span>
                  </>
                ) : previewHealth.status === 'ok' ? (
                  <>
                    <CheckCircle2
                      className="w-3.5 h-3.5 text-[#10B981] shrink-0"
                      aria-hidden="true"
                    />
                    <span className="text-[10.5px] font-bold whitespace-nowrap">
                      Preview OK ✓
                    </span>
                  </>
                ) : (
                  <>
                    <Loader2
                      className="w-3 h-3 animate-spin text-[#64748B] shrink-0"
                      aria-hidden="true"
                    />
                    <span className="text-[10px] font-medium truncate">
                      {previewVerifyState?.status === 'verifying'
                        ? 'Verifying build preview...'
                        : 'Checking preview...'}
                    </span>
                  </>
                )}
              </div>

              {previewHealth.status === 'error' &&
                previewVerifyState?.status !== 'healing' &&
                onFixPreviewError && (
                  <button
                    type="button"
                    onClick={() => onFixPreviewError(previewHealth.message)}
                    disabled={isFixingPreviewError}
                    className="h-6 px-2 rounded-md bg-[#EF4444] hover:bg-[#DC2626] disabled:opacity-60 text-white text-[10px] font-bold inline-flex items-center gap-1 shadow-2xs transition-all whitespace-nowrap shrink-0 cursor-pointer active:scale-95"
                  >
                    {isFixingPreviewError ? (
                      <Loader2 className="w-3 h-3 animate-spin shrink-0" aria-hidden="true" />
                    ) : (
                      <Wrench className="w-3 h-3 shrink-0" aria-hidden="true" />
                    )}
                    <span>{isFixingPreviewError ? 'Fixing...' : 'Fix Error'}</span>
                  </button>
                )}
            </div>

            {/* Footer metadata strip */}
            <div className="pt-1.5 border-t border-slate-200/75 flex items-center justify-between gap-2 text-[10.5px] text-[#64748B]">
              <span className="font-medium text-[#0F172A] truncate">
                {paused
                  ? liveActive
                    ? 'Inspect Mode · Voice Live'
                    : 'Inspect Mode · Edit Files Safely'
                  : liveActive
                    ? 'Live Signal Active'
                    : activeStageInfo.label}
              </span>
              <span className="font-mono tabular-nums whitespace-nowrap shrink-0">
                {filesCount} files · {assetsCount} assets
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );

  if (isFullscreen) {
    return (
      <div
        className="fixed inset-0 z-50 bg-slate-900/35 backdrop-blur-sm p-4 flex items-center justify-center"
        role="dialog"
        aria-modal="true"
        aria-label="Fullscreen Display A"
      >
        {cardContent}
      </div>
    );
  }

  return <section aria-label="Display A Viewport">{cardContent}</section>;
}
