import { useMemo, useState, type FormEvent } from 'react';
import {
  ChevronDown,
  ChevronRight,
  Folder,
  FolderOpen,
  FileCode2,
  FileJson,
  FileText,
  FilePlus2,
  Trash2,
  X,
  Check,
  GitBranch,
  Loader2,
  AlertCircle,
  CheckCircle2,
} from 'lucide-react';
import type { Language, VirtualFile } from '../types/studio';

interface FileDrawerProps {
  files: VirtualFile[];
  activeFilePath: string | null;
  language: Language;
  isCloning?: boolean;
  cloneNotice?: { ok: boolean; text: string } | null;
  onSelectFile: (path: string) => void;
  onCreateFile: (path: string) => void;
  onDeleteFile: (path: string) => void;
  onCloneRepo?: (repoInput: string) => void;
}

const FOLDER_ORDER = ['src', 'assets', 'docs'];

function getFolderAccent(folder: string): {
  iconColor: string;
  badgeClass: string;
} {
  switch (folder) {
    case 'src':
      return {
        iconColor: 'text-[#007AFF]',
        badgeClass: 'bg-[#007AFF]/10 text-[#007AFF]',
      };
    case 'assets':
      return {
        iconColor: 'text-[#10B981]',
        badgeClass: 'bg-[#10B981]/12 text-[#047857]',
      };
    case 'docs':
      return {
        iconColor: 'text-[#5856D6]',
        badgeClass: 'bg-[#5856D6]/10 text-[#5856D6]',
      };
    default:
      return {
        iconColor: 'text-[#F59E0B]',
        badgeClass: 'bg-[#F59E0B]/12 text-[#B45309]',
      };
  }
}

function getFileIcon(path: string) {
  if (path.endsWith('.json')) return FileJson;
  if (path.endsWith('.tsx') || path.endsWith('.ts') || path.endsWith('.html')) {
    return FileCode2;
  }
  return FileText;
}

export function FileDrawer({
  files,
  activeFilePath,
  language,
  isCloning = false,
  cloneNotice = null,
  onSelectFile,
  onCreateFile,
  onDeleteFile,
  onCloneRepo,
}: FileDrawerProps) {
  const [drawerOpen, setDrawerOpen] = useState(true);
  const [openFolders, setOpenFolders] = useState<Record<string, boolean>>({
    src: true,
    assets: true,
    docs: true,
  });
  const [creating, setCreating] = useState(false);
  const [newPath, setNewPath] = useState('src/scene.ts');
  const [createError, setCreateError] = useState('');
  const [repoInput, setRepoInput] = useState('');

  const groupedFolders = useMemo(() => {
    const map = new Map<string, VirtualFile[]>();
    // Always preserve primary folders in order when files exist inside them
    for (const file of files) {
      const normalized = file.path.replace(/^\/+/, '');
      const slashIdx = normalized.indexOf('/');
      const folder = slashIdx > 0 ? normalized.slice(0, slashIdx) : 'root';
      const bucket = map.get(folder) ?? [];
      bucket.push(file);
      map.set(folder, bucket);
    }

    const entries = Array.from(map.entries());
    entries.sort(([a], [b]) => {
      const idxA = FOLDER_ORDER.indexOf(a);
      const idxB = FOLDER_ORDER.indexOf(b);
      if (idxA !== -1 && idxB !== -1) return idxA - idxB;
      if (idxA !== -1) return -1;
      if (idxB !== -1) return 1;
      return a.localeCompare(b);
    });
    return entries;
  }, [files]);

  const toggleFolder = (folder: string) => {
    setOpenFolders((prev) => ({
      ...prev,
      [folder]: !(prev[folder] ?? true),
    }));
  };

  const handleCreateSubmit = (e: FormEvent) => {
    e.preventDefault();
    const cleaned = newPath.trim().replace(/^\/+/, '');
    if (!cleaned || cleaned.endsWith('/')) {
      setCreateError('Enter a valid file path (e.g. src/helper.ts)');
      return;
    }
    if (files.some((f) => f.path === cleaned)) {
      setCreateError('File already exists');
      return;
    }
    const folder = cleaned.includes('/') ? cleaned.split('/')[0] : 'root';
    setOpenFolders((prev) => ({ ...prev, [folder]: true }));
    onCreateFile(cleaned);
    setCreateError('');
    setCreating(false);
    setNewPath('src/module.ts');
  };

  return (
    <section
      aria-label="Project Folder and File Drawer"
      className="bg-white/85 backdrop-blur-xl border border-slate-200/80 shadow-[0_8px_30px_rgba(15,23,42,0.06)] rounded-2xl overflow-hidden"
    >
      {/* Drawer Header */}
      <div className="px-3 py-2.5 flex items-center justify-between gap-2">
        <button
          type="button"
          onClick={() => setDrawerOpen((prev) => !prev)}
          aria-expanded={drawerOpen}
          className="flex items-center gap-2 min-w-0 flex-1 text-left cursor-pointer group"
        >
          <span
            className="w-7 h-7 rounded-lg bg-[#5856D6]/10 text-[#5856D6] flex items-center justify-center shrink-0"
            aria-hidden="true"
          >
            {drawerOpen ? (
              <FolderOpen className="w-4 h-4" />
            ) : (
              <Folder className="w-4 h-4" />
            )}
          </span>
          <div className="min-w-0 flex items-center gap-1.5">
            <h2 className="text-[12.5px] sm:text-[13.5px] font-bold text-[#0F172A] truncate">
              {language === 'hi' ? 'फ़ाइल ड्रॉअर' : 'File Drawer'}
            </h2>
            <span className="font-mono text-[11px] font-semibold text-[#64748B] tabular-nums shrink-0">
              ({files.length})
            </span>
          </div>
          {drawerOpen ? (
            <ChevronDown className="w-4 h-4 text-[#64748B] shrink-0" aria-hidden="true" />
          ) : (
            <ChevronRight className="w-4 h-4 text-[#64748B] shrink-0" aria-hidden="true" />
          )}
        </button>

        <button
          type="button"
          onClick={() => {
            setDrawerOpen(true);
            setCreating((prev) => !prev);
            setCreateError('');
          }}
          className="h-7 px-2.5 rounded-full bg-[#007AFF]/10 hover:bg-[#007AFF] text-[#007AFF] hover:text-white text-[11px] font-semibold inline-flex items-center gap-1 transition-all whitespace-nowrap shrink-0 cursor-pointer"
        >
          <FilePlus2 className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
          <span>{language === 'hi' ? 'नई फ़ाइल' : 'New File'}</span>
        </button>
      </div>

      {/* Expandable Drawer Body */}
      {drawerOpen && (
        <div className="px-3 pb-3 border-t border-slate-200/70 pt-2.5 flex flex-col gap-2">
          {/* Compact Clone GitHub Strip (fits 360px cleanly) */}
          {onCloneRepo && (
            <div className="flex flex-col gap-1">
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  const trimmed = repoInput.trim();
                  if (!trimmed || isCloning) return;
                  onCloneRepo(trimmed);
                }}
                className="flex items-center gap-1.5 w-full min-w-0"
              >
                <div className="relative flex-1 min-w-0">
                  <GitBranch
                    className="w-3.5 h-3.5 text-[#5856D6] absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none"
                    aria-hidden="true"
                  />
                  <input
                    type="text"
                    value={repoInput}
                    onChange={(e) => setRepoInput(e.target.value)}
                    placeholder="owner/repo"
                    aria-label="GitHub repository to clone"
                    className="w-full min-w-0 h-8 pl-7 pr-2 rounded-xl bg-[#F6F9FE] border border-slate-200/90 font-mono text-[11px] text-[#0F172A] placeholder:text-[#94A3B8] focus:outline-none focus:border-[#5856D6]"
                  />
                </div>
                <button
                  type="submit"
                  disabled={isCloning || !repoInput.trim()}
                  className="h-8 px-2.5 rounded-xl bg-gradient-to-r from-[#5856D6] to-[#007AFF] hover:brightness-105 disabled:opacity-50 text-white text-[11px] font-bold inline-flex items-center gap-1 shadow-2xs transition-all whitespace-nowrap shrink-0 cursor-pointer active:scale-[0.98]"
                >
                  {isCloning ? (
                    <Loader2 className="w-3 h-3 animate-spin shrink-0" aria-hidden="true" />
                  ) : (
                    <GitBranch className="w-3 h-3 shrink-0" aria-hidden="true" />
                  )}
                  <span>{isCloning ? 'Cloning...' : 'Clone GitHub'}</span>
                </button>
              </form>

              {cloneNotice && (
                <div
                  className={`rounded-lg px-2 py-1 flex items-center gap-1.5 text-[10.5px] font-medium ${
                    cloneNotice.ok
                      ? 'bg-[#10B981]/10 text-[#047857]'
                      : 'bg-[#FF3B30]/10 text-[#DC2626]'
                  }`}
                >
                  {cloneNotice.ok ? (
                    <CheckCircle2 className="w-3 h-3 shrink-0" aria-hidden="true" />
                  ) : (
                    <AlertCircle className="w-3 h-3 shrink-0" aria-hidden="true" />
                  )}
                  <span className="truncate">{cloneNotice.text}</span>
                </div>
              )}
            </div>
          )}

          {/* Inline New File Creator */}
          {creating && (
            <form
              onSubmit={handleCreateSubmit}
              className="rounded-xl bg-[#F6F9FE] border border-[#007AFF]/25 p-2 flex flex-col gap-1.5"
            >
              <div className="flex items-center gap-1.5">
                <label htmlFor="new-virtual-file-path" className="sr-only">
                  New file path
                </label>
                <input
                  id="new-virtual-file-path"
                  type="text"
                  value={newPath}
                  onChange={(e) => {
                    setNewPath(e.target.value);
                    if (createError) setCreateError('');
                  }}
                  placeholder="src/config.ts"
                  autoFocus
                  className="flex-1 min-w-0 h-8 px-2.5 rounded-lg bg-white border border-slate-200/90 font-mono text-[11.5px] text-[#0F172A] focus:outline-none focus:border-[#007AFF]"
                />
                <button
                  type="submit"
                  aria-label="Confirm create file"
                  className="w-8 h-8 rounded-lg bg-[#10B981] hover:bg-[#059669] text-white flex items-center justify-center shrink-0 cursor-pointer"
                >
                  <Check className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setCreating(false);
                    setCreateError('');
                  }}
                  aria-label="Cancel create file"
                  className="w-8 h-8 rounded-lg bg-slate-200/80 hover:bg-slate-300/80 text-[#0F172A] flex items-center justify-center shrink-0 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              {createError && (
                <p className="text-[11px] font-medium text-[#FF3B30] px-1">
                  {createError}
                </p>
              )}
            </form>
          )}

          {/* Folder Groups */}
          {groupedFolders.length === 0 ? (
            <div className="rounded-xl bg-[#F6F9FE] border border-dashed border-slate-300/80 p-3 text-center text-[11.5px] text-[#64748B]">
              {language === 'hi'
                ? 'कोई फ़ाइल नहीं। नई फ़ाइल बनाने के लिए ऊपर टैप करें।'
                : 'No virtual files yet. Tap New File to create one.'}
            </div>
          ) : (
            <div className="flex flex-col gap-1.5">
              {groupedFolders.map(([folder, folderFiles]) => {
                const isOpen = openFolders[folder] ?? true;
                const { iconColor, badgeClass } = getFolderAccent(folder);
                return (
                  <div
                    key={folder}
                    className="rounded-xl bg-[#F8FAFD] border border-slate-200/75 overflow-hidden"
                  >
                    <button
                      type="button"
                      onClick={() => toggleFolder(folder)}
                      aria-expanded={isOpen}
                      className="w-full px-2.5 py-2 flex items-center justify-between gap-2 hover:bg-slate-100/80 transition-colors cursor-pointer"
                    >
                      <div className="flex items-center gap-1.5 min-w-0">
                        {isOpen ? (
                          <ChevronDown
                            className="w-3.5 h-3.5 text-[#64748B] shrink-0"
                            aria-hidden="true"
                          />
                        ) : (
                          <ChevronRight
                            className="w-3.5 h-3.5 text-[#64748B] shrink-0"
                            aria-hidden="true"
                          />
                        )}
                        {isOpen ? (
                          <FolderOpen
                            className={`w-4 h-4 shrink-0 ${iconColor}`}
                            aria-hidden="true"
                          />
                        ) : (
                          <Folder
                            className={`w-4 h-4 shrink-0 ${iconColor}`}
                            aria-hidden="true"
                          />
                        )}
                        <span className="font-mono text-[12px] font-semibold text-[#0F172A] truncate">
                          {folder}/
                        </span>
                      </div>
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10.5px] font-mono font-semibold tabular-nums shrink-0 ${badgeClass}`}
                      >
                        {folderFiles.length}
                      </span>
                    </button>

                    {isOpen && (
                      <div className="border-t border-slate-200/70 divide-y divide-slate-200/60 bg-white/80">
                        {folderFiles.map((file) => {
                          const isSelected = activeFilePath === file.path;
                          const fileName = file.path.includes('/')
                            ? file.path.slice(file.path.indexOf('/') + 1)
                            : file.path;
                          const FileIcon = getFileIcon(file.path);

                          return (
                            <div
                              key={file.path}
                              className={`flex items-center justify-between gap-1.5 pl-3 pr-1.5 py-1 transition-colors ${
                                isSelected ? 'bg-[#007AFF]/8' : 'hover:bg-slate-50'
                              }`}
                            >
                              <button
                                type="button"
                                onClick={() => onSelectFile(file.path)}
                                className="flex items-center gap-2 min-w-0 flex-1 py-1.5 text-left cursor-pointer"
                              >
                                <FileIcon
                                  className={`w-3.5 h-3.5 shrink-0 ${
                                    isSelected ? 'text-[#007AFF]' : 'text-[#64748B]'
                                  }`}
                                  aria-hidden="true"
                                />
                                <span
                                  className={`font-mono text-[11.5px] truncate ${
                                    isSelected
                                      ? 'font-bold text-[#007AFF]'
                                      : 'font-medium text-[#0F172A]'
                                  }`}
                                >
                                  {fileName}
                                </span>
                                <span className="text-[10px] font-mono text-[#64748B] ml-auto shrink-0">
                                  {file.language}
                                </span>
                              </button>

                              <button
                                type="button"
                                onClick={() => onDeleteFile(file.path)}
                                aria-label={`Delete ${file.path}`}
                                title={`Delete ${file.path}`}
                                className="w-8 h-8 rounded-lg text-[#64748B] hover:text-[#FF3B30] hover:bg-[#FF3B30]/10 flex items-center justify-center transition-colors shrink-0 cursor-pointer"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </section>
  );
}
