import { useEffect, useMemo, useRef, useState } from 'react';
import {
  KeyRound,
  Eye,
  EyeOff,
  X,
  Github,
  Box,
  Database,
  Copy,
  Check,
  Lock,
  Loader2,
  AlertCircle,
  CheckCircle2,
  Sparkles,
  Save,
  Activity,
  Plus,
  Trash2,
  Power,
  RefreshCw,
} from 'lucide-react';
import type {
  ApiKeyProvider,
  Language,
  StudioApiKeyEntry,
  StudioSecrets,
} from '../types/studio';
import {
  DEFAULT_2026_MODELS,
  DEFAULT_ASSET_VAULT_URL,
  DEFAULT_NVIDIA_MODELS,
  DEFAULT_TARGET_REPO,
  STUDIO_SUPABASE_SQL,
  detectProviderFromKey,
  getDefaultModelForProvider,
  getProviderDisplayName,
  hydrateKeyPool,
  parseCloudflareCredential,
  saveSecrets,
  syncLegacyFieldsFromKeyPool,
  testConfiguredApiKeys,
  verifyAssetVault,
  type ApiKeyEntryTestResult,
  type VaultVerifyResult,
} from '../services/secretsService';
import {
  clearKeyCooldown,
  clearProviderCooldown,
  getKeyCooldownRemainingMs,
  markKeyCooldown,
  markProviderCooldown,
} from '../services/aiRouter';

interface SecretsPanelProps {
  open: boolean;
  secrets: StudioSecrets;
  language: Language;
  onSave: (updated: StudioSecrets) => void;
  onClose: () => void;
}

type StaticVisibilityKey = 'github' | 'studioSupabase' | 'appsSupabase' | 'addKey';

type SaveSlotKey = 'addKey' | 'githubVault' | 'studioDb' | 'appsDb' | `key:${string}`;

const PROVIDER_OPTIONS: { value: ApiKeyProvider; label: string }[] = [
  { value: 'gemini', label: 'Google Gemini' },
  { value: 'groq', label: 'Groq' },
  { value: 'nvidia', label: 'NVIDIA NIM' },
  { value: 'cloudflare', label: 'Cloudflare Workers AI' },
  { value: 'openrouter', label: 'OpenRouter' },
  { value: 'cohere', label: 'Cohere' },
  { value: 'custom', label: 'Custom /v1 (OpenAI)' },
];

function getProviderChipClass(provider: ApiKeyProvider): string {
  switch (provider) {
    case 'gemini':
      return 'bg-[#007AFF]/12 text-[#007AFF] border-[#007AFF]/30';
    case 'groq':
      return 'bg-[#F59E0B]/14 text-[#B45309] border-[#F59E0B]/30';
    case 'nvidia':
      return 'bg-[#10B981]/14 text-[#047857] border-[#10B981]/30';
    case 'cloudflare':
      return 'bg-[#F97316]/14 text-[#C2410C] border-[#F97316]/30';
    case 'openrouter':
      return 'bg-[#5856D6]/12 text-[#5856D6] border-[#5856D6]/30';
    case 'cohere':
      return 'bg-[#FF3B30]/12 text-[#DC2626] border-[#FF3B30]/30';
    case 'custom':
      return 'bg-slate-200/80 text-[#334155] border-slate-300/90';
  }
}

export function SecretsPanel({
  open,
  secrets,
  language,
  onSave,
  onClose,
}: SecretsPanelProps) {
  const [draft, setDraft] = useState<StudioSecrets>(() => ({
    ...secrets,
    keyPool: hydrateKeyPool(secrets, Array.isArray(secrets.keyPool)),
  }));
  const [visible, setVisible] = useState<Record<StaticVisibilityKey, boolean>>({
    github: false,
    studioSupabase: false,
    appsSupabase: false,
    addKey: false,
  });
  const [entryVisible, setEntryVisible] = useState<Record<string, boolean>>({});

  // Universal Add Key bar state
  const [newKeyValue, setNewKeyValue] = useState('');
  const [providerOverride, setProviderOverride] = useState<'auto' | ApiKeyProvider>('auto');
  const [newLabel, setNewLabel] = useState('');
  const [newSecondaryId, setNewSecondaryId] = useState('');
  const [newBaseUrl, setNewBaseUrl] = useState('');
  const [newModel, setNewModel] = useState('');
  const [showOptionalCustom, setShowOptionalCustom] = useState(false);

  const [verifying, setVerifying] = useState(false);
  const [verifyResult, setVerifyResult] = useState<VaultVerifyResult | null>(null);
  const [testingApis, setTestingApis] = useState(false);
  const [apiTestById, setApiTestById] = useState<Record<string, ApiKeyEntryTestResult>>({});
  const [testSummaryNote, setTestSummaryNote] = useState<string | null>(null);
  const [sqlCopied, setSqlCopied] = useState(false);
  const [savedSlots, setSavedSlots] = useState<Partial<Record<SaveSlotKey, boolean>>>({});
  const saveTimersRef = useRef<Partial<Record<SaveSlotKey, number>>>({});
  const wasOpenRef = useRef(false);

  useEffect(() => {
    if (open && !wasOpenRef.current) {
      setDraft({
        ...secrets,
        keyPool: hydrateKeyPool(secrets, Array.isArray(secrets.keyPool)),
        nvidiaModelsList:
          secrets.nvidiaModelsList && secrets.nvidiaModelsList.length > 0
            ? secrets.nvidiaModelsList
            : [...DEFAULT_NVIDIA_MODELS],
      });
      setVerifyResult(null);
      setApiTestById({});
      setTestSummaryNote(null);
      setSqlCopied(false);
      setSavedSlots({});
      setNewKeyValue('');
      setProviderOverride('auto');
      setNewLabel('');
      setNewSecondaryId('');
      setNewBaseUrl('');
      setNewModel('');
      setShowOptionalCustom(false);
    }
    wasOpenRef.current = open;
  }, [open, secrets]);

  useEffect(() => {
    const timers = saveTimersRef.current;
    return () => {
      Object.values(timers).forEach((timerId) => {
        if (typeof timerId === 'number') {
          window.clearTimeout(timerId);
        }
      });
    };
  }, []);

  const detectedProvider: ApiKeyProvider = useMemo(
    () => detectProviderFromKey(newKeyValue),
    [newKeyValue]
  );

  const effectiveAddProvider: ApiKeyProvider =
    providerOverride === 'auto' ? detectedProvider : providerOverride;

  const keyPool: StudioApiKeyEntry[] = useMemo(
    () => draft.keyPool ?? [],
    [draft.keyPool]
  );

  const nvidiaModels: string[] = useMemo(() => {
    const list =
      draft.nvidiaModelsList && draft.nvidiaModelsList.length > 0
        ? draft.nvidiaModelsList
        : DEFAULT_NVIDIA_MODELS;
    if (list.includes(DEFAULT_2026_MODELS.nvidia)) {
      return list;
    }
    return [DEFAULT_2026_MODELS.nvidia, ...list];
  }, [draft.nvidiaModelsList]);

  if (!open) return null;

  const flashSavedSlot = (slot: SaveSlotKey) => {
    setSavedSlots((prev) => ({ ...prev, [slot]: true }));
    const existingTimer = saveTimersRef.current[slot];
    if (typeof existingTimer === 'number') {
      window.clearTimeout(existingTimer);
    }
    saveTimersRef.current[slot] = window.setTimeout(() => {
      setSavedSlots((prev) => ({ ...prev, [slot]: false }));
      delete saveTimersRef.current[slot];
    }, 2000);
  };

  const toggleShow = (key: StaticVisibilityKey) => {
    setVisible((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const toggleEntryVisible = (id: string) => {
    setEntryVisible((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const updateField = <K extends keyof StudioSecrets>(
    field: K,
    value: StudioSecrets[K]
  ) => {
    setDraft((prev) => ({ ...prev, [field]: value }));
  };

  const persistDraft = (nextDraft: StudioSecrets, slot?: SaveSlotKey) => {
    const saved = saveSecrets(nextDraft);
    setDraft(saved);
    onSave(saved);
    if (slot) {
      flashSavedSlot(slot);
    }
  };

  const savePartialSecrets = (slot: SaveSlotKey) => {
    persistDraft(draft, slot);
  };

  const handleAddPoolKey = () => {
    const rawKey = newKeyValue.trim();
    if (!rawKey) return;

    const provider = effectiveAddProvider;
    const sameProviderCount = keyPool.filter((e) => e.provider === provider).length;
    const autoLabel =
      provider === 'gemini' || sameProviderCount > 0
        ? `${getProviderDisplayName(provider)} #${sameProviderCount + 1}`
        : getProviderDisplayName(provider);

    let secondaryId = newSecondaryId.trim() || undefined;
    if (provider === 'cloudflare' && !secondaryId) {
      const parsed = parseCloudflareCredential(rawKey);
      if (parsed.accountId) {
        secondaryId = parsed.accountId;
      }
    }

    const entry: StudioApiKeyEntry = {
      id: `key-${provider}-${Date.now().toString(36)}-${Math.random()
        .toString(36)
        .slice(2, 6)}`,
      provider,
      label: newLabel.trim() || autoLabel,
      apiKey: rawKey,
      ...(secondaryId ? { secondaryId } : {}),
      ...(newBaseUrl.trim() ? { baseUrl: newBaseUrl.trim() } : {}),
      model: newModel.trim() || getDefaultModelForProvider(provider),
      enabled: true,
    };

    const nextPool = [...keyPool, entry];
    const nextDraft = syncLegacyFieldsFromKeyPool(
      { ...draft, keyPool: nextPool },
      nextPool
    );

    persistDraft(nextDraft, 'addKey');
    setNewKeyValue('');
    setNewLabel('');
    setNewSecondaryId('');
    setNewBaseUrl('');
    setNewModel('');
    setProviderOverride('auto');
    setShowOptionalCustom(false);
  };

  const handleUpdatePoolEntry = (
    id: string,
    patch: Partial<StudioApiKeyEntry>,
    autoPersist = false
  ) => {
    const nextPool = keyPool.map((item) => {
      if (item.id !== id) return item;
      const updated: StudioApiKeyEntry = { ...item, ...patch };
      if (updated.provider === 'cloudflare' && patch.apiKey !== undefined) {
        const parsed = parseCloudflareCredential(updated.apiKey, updated.secondaryId);
        if (parsed.accountId) {
          updated.secondaryId = parsed.accountId;
        }
      }
      return updated;
    });
    const nextDraft = syncLegacyFieldsFromKeyPool(
      { ...draft, keyPool: nextPool },
      nextPool
    );
    if (autoPersist) {
      persistDraft(nextDraft, `key:${id}`);
    } else {
      setDraft(nextDraft);
    }
  };

  const handleDeletePoolEntry = (id: string) => {
    clearKeyCooldown(id);
    const nextPool = keyPool.filter((item) => item.id !== id);
    const nextDraft = syncLegacyFieldsFromKeyPool(
      { ...draft, keyPool: nextPool },
      nextPool
    );
    persistDraft(nextDraft);
    setApiTestById((prev) => {
      const copy = { ...prev };
      delete copy[id];
      return copy;
    });
  };

  const handleTestAllApis = async () => {
    if (testingApis) return;
    setTestingApis(true);
    setTestSummaryNote(null);
    try {
      const report = await testConfiguredApiKeys(draft);
      setApiTestById(report.byEntryId);

      const now = Date.now();
      const nextPool = keyPool.map((entry) => {
        const res = report.byEntryId[entry.id];
        if (!res) return entry;
        if (res.ok) {
          clearKeyCooldown(entry.id);
          clearProviderCooldown(entry.provider);
          return {
            ...entry,
            statusLabel:
              res.modelCount > 0 ? `Active ✓ · ${res.modelCount}` : 'Active ✓',
            cooldownUntil: undefined,
          };
        }
        if (/(503|429|Timeout)/i.test(res.statusLabel)) {
          markKeyCooldown(entry.id);
          return {
            ...entry,
            statusLabel: res.statusLabel,
            cooldownUntil: now + 60_000,
          };
        }
        return {
          ...entry,
          statusLabel: res.statusLabel,
          cooldownUntil: undefined,
        };
      });

      // Mark provider-level cooldown if every enabled key for a provider failed with 429/503/timeout
      const enabledByProvider = new Map<ApiKeyProvider, StudioApiKeyEntry[]>();
      for (const e of nextPool) {
        if (!e.enabled) continue;
        const arr = enabledByProvider.get(e.provider) ?? [];
        arr.push(e);
        enabledByProvider.set(e.provider, arr);
      }
      enabledByProvider.forEach((entries, prov) => {
        if (entries.every((e) => (e.cooldownUntil ?? 0) > now)) {
          markProviderCooldown(prov);
        }
      });

      const nextDraft = syncLegacyFieldsFromKeyPool(
        {
          ...draft,
          keyPool: nextPool,
          nvidiaModelsList: report.nvidiaModelsList,
        },
        nextPool
      );
      const saved = saveSecrets(nextDraft);
      setDraft(saved);
      onSave(saved);

      const nvidiaEntry = report.entries.find((e) => e.provider === 'nvidia' && e.ok);
      const nvidiaNote =
        nvidiaEntry && report.nvidiaModelsList.length > 0
          ? ` · NVIDIA ${report.nvidiaModelsList.length} models synced`
          : '';
      setTestSummaryNote(
        report.totalCount === 0
          ? 'No enabled keys in pool yet.'
          : `${report.activeCount}/${report.totalCount} active${nvidiaNote}`
      );
    } finally {
      setTestingApis(false);
    }
  };

  const renderEntryStatusBadge = (entry: StudioApiKeyEntry) => {
    if (!entry.enabled) {
      return (
        <span className="px-1.5 py-0.5 rounded-md bg-slate-100 text-[#64748B] border border-slate-200/80 text-[10px] font-semibold whitespace-nowrap">
          Disabled
        </span>
      );
    }

    const cooldownMs = Math.max(
      getKeyCooldownRemainingMs(entry.id),
      entry.cooldownUntil ? Math.max(0, entry.cooldownUntil - Date.now()) : 0
    );
    if (cooldownMs > 0) {
      const secs = Math.max(1, Math.ceil(cooldownMs / 1000));
      return (
        <span className="px-1.5 py-0.5 rounded-md bg-[#F59E0B]/15 text-[#B45309] border border-[#F59E0B]/35 text-[10px] font-bold whitespace-nowrap tabular-nums">
          Cooldown {secs}s
        </span>
      );
    }

    const liveRes = apiTestById[entry.id];
    if (liveRes) {
      if (liveRes.ok) {
        return (
          <span className="px-1.5 py-0.5 rounded-md bg-[#10B981]/14 text-[#047857] border border-[#10B981]/30 text-[10px] font-bold whitespace-nowrap tabular-nums">
            Active ✓{liveRes.modelCount > 0 ? ` · ${liveRes.modelCount}` : ''}
          </span>
        );
      }
      return (
        <span className="px-1.5 py-0.5 rounded-md bg-[#FF3B30]/12 text-[#DC2626] border border-[#FF3B30]/30 text-[10px] font-bold whitespace-nowrap">
          {liveRes.statusLabel}
        </span>
      );
    }

    if (entry.statusLabel) {
      const isOk = entry.statusLabel.startsWith('Active');
      return (
        <span
          className={`px-1.5 py-0.5 rounded-md border text-[10px] font-bold whitespace-nowrap ${
            isOk
              ? 'bg-[#10B981]/14 text-[#047857] border-[#10B981]/30'
              : 'bg-[#FF3B30]/12 text-[#DC2626] border-[#FF3B30]/30'
          }`}
        >
          {entry.statusLabel}
        </span>
      );
    }

    return (
      <span className="px-1.5 py-0.5 rounded-md bg-slate-100 text-[#475569] border border-slate-200/80 text-[10px] font-semibold whitespace-nowrap">
        Ready
      </span>
    );
  };

  const handleVerifyVault = async () => {
    setVerifying(true);
    setVerifyResult(null);
    const result = await verifyAssetVault(
      draft.assetVaultUrl ?? DEFAULT_ASSET_VAULT_URL
    );
    setVerifyResult(result);
    setVerifying(false);
  };

  const handleCopySql = async () => {
    try {
      await navigator.clipboard.writeText(STUDIO_SUPABASE_SQL);
      setSqlCopied(true);
      window.setTimeout(() => setSqlCopied(false), 2000);
    } catch {
      const el = document.createElement('textarea');
      el.value = STUDIO_SUPABASE_SQL;
      el.style.position = 'fixed';
      el.style.opacity = '0';
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      document.body.removeChild(el);
      setSqlCopied(true);
      window.setTimeout(() => setSqlCopied(false), 2000);
    }
  };

  const handleSaveAndLock = () => {
    const saved = saveSecrets(draft);
    onSave(saved);
    onClose();
  };

  const inputBaseClass =
    'w-full min-w-0 h-10 px-3 rounded-xl bg-white border border-slate-200/90 text-[12px] text-[#0F172A] placeholder:text-[#94A3B8] focus:outline-none focus:border-[#007AFF] focus:ring-2 focus:ring-[#007AFF]/15 transition-all';

  const geminiKeyCount = keyPool.filter(
    (e) => e.provider === 'gemini' && e.enabled
  ).length;

  return (
    <div
      className="fixed inset-0 z-[60] bg-slate-900/25 backdrop-blur-[3px] flex items-end sm:items-center justify-center sm:p-4"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label="API Keys & Vault Secrets"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-full sm:max-w-xl mx-auto bg-[#F8FAFE]/95 backdrop-blur-2xl border-t sm:border border-slate-200/90 rounded-t-3xl sm:rounded-3xl shadow-[0_-14px_48px_rgba(15,23,42,0.18)] flex flex-col max-h-[90dvh] sm:max-h-[86dvh] overflow-hidden"
      >
        {/* Drag Handle (mobile) */}
        <div className="pt-2.5 pb-1 flex justify-center sm:hidden shrink-0">
          <div className="w-10 h-1 rounded-full bg-slate-300/90" aria-hidden="true" />
        </div>

        {/* Sticky Sheet Header */}
        <div className="px-3.5 sm:px-5 py-2.5 bg-white/85 backdrop-blur-xl border-b border-slate-200/80 flex items-center justify-between gap-2 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div
              className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#F59E0B] to-[#EA580C] text-white flex items-center justify-center shadow-xs shrink-0"
              aria-hidden="true"
            >
              <KeyRound className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <h2 className="text-[14px] sm:text-[15px] font-bold text-[#0F172A] tracking-tight truncate">
                API Keys &amp; Vault Secrets
              </h2>
              <p className="text-[11px] font-medium text-[#64748B] truncate">
                {language === 'hi'
                  ? 'यूनिवर्सल स्मार्ट की पूल · ज़ीरो-सर्वर स्टोरेज'
                  : 'Universal Smart Key Pool · Zero-server storage'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close API Keys and Vault Secrets"
            className="w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200/80 text-[#0F172A] flex items-center justify-center transition-colors shrink-0 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Vertically Scrollable Form Body */}
        <div className="flex-1 min-h-0 overflow-y-auto studio-scroll px-3 sm:px-5 pt-3 pb-8 flex flex-col gap-3">
          {/* SECTION A: Universal Smart Key Pool */}
          <section className="bg-white/85 backdrop-blur-xl border border-slate-200/80 shadow-[0_6px_22px_rgba(15,23,42,0.04)] rounded-2xl p-3 flex flex-col gap-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2 min-w-0">
                <span className="w-6 h-6 rounded-lg bg-[#007AFF]/10 text-[#007AFF] flex items-center justify-center shrink-0">
                  <Sparkles className="w-3.5 h-3.5" aria-hidden="true" />
                </span>
                <h3 className="text-[12.5px] font-bold text-[#0F172A] truncate">
                  Section A · Universal Smart Key Pool ({keyPool.length})
                </h3>
              </div>
              <button
                type="button"
                onClick={() => {
                  void handleTestAllApis();
                }}
                disabled={testingApis}
                className="h-7 px-2.5 rounded-lg bg-gradient-to-r from-[#007AFF] via-[#5856D6] to-[#10B981] hover:brightness-105 disabled:opacity-60 text-white text-[10.5px] font-bold inline-flex items-center gap-1 shadow-xs transition-all whitespace-nowrap shrink-0 cursor-pointer active:scale-95"
              >
                {testingApis ? (
                  <Loader2 className="w-3 h-3 animate-spin shrink-0" aria-hidden="true" />
                ) : (
                  <Activity className="w-3 h-3 shrink-0" aria-hidden="true" />
                )}
                <span>{testingApis ? 'Testing...' : 'Test All APIs'}</span>
              </button>
            </div>

            {testSummaryNote && (
              <div className="px-2.5 py-1.5 rounded-xl bg-[#F6F9FE] border border-[#007AFF]/20 text-[11px] font-semibold text-[#0F172A] flex items-center gap-1.5">
                <CheckCircle2
                  className="w-3.5 h-3.5 text-[#10B981] shrink-0"
                  aria-hidden="true"
                />
                <span className="truncate">{testSummaryNote}</span>
              </div>
            )}

            {/* Universal Add Any API Key Bar */}
            <div className="rounded-xl bg-[#F6F9FE] border border-[#007AFF]/20 p-2.5 flex flex-col gap-2">
              <div className="flex flex-wrap items-center justify-between gap-1.5">
                <span className="text-[11.5px] font-bold text-[#0F172A]">
                  Universal Add Any API Key
                </span>
                <span
                  className={`px-2 py-0.5 rounded-full border text-[10px] font-bold whitespace-nowrap ${
                    newKeyValue.trim()
                      ? getProviderChipClass(effectiveAddProvider)
                      : 'bg-white text-[#64748B] border-slate-200/80'
                  }`}
                >
                  {newKeyValue.trim()
                    ? `${providerOverride === 'auto' ? 'Detected: ' : ''}${getProviderDisplayName(
                        effectiveAddProvider
                      )}`
                    : 'Auto-Detect Ready'}
                </span>
              </div>

              <div className="flex items-center gap-1.5 min-w-0">
                <div className="relative flex-1 min-w-0 flex items-center">
                  <input
                    id="universal-add-api-key"
                    type={visible.addKey ? 'text' : 'password'}
                    value={newKeyValue}
                    onChange={(e) => setNewKeyValue(e.target.value)}
                    placeholder="Paste AIza..., gsk_..., nvapi-..., sk-or-v1-..., AccountID:Token"
                    autoComplete="off"
                    className={`${inputBaseClass} pr-10 font-mono text-[11px]`}
                  />
                  <button
                    type="button"
                    onClick={() => toggleShow('addKey')}
                    aria-label={visible.addKey ? 'Hide key input' : 'Show key input'}
                    className="absolute right-1.5 w-8 h-8 rounded-lg text-[#64748B] hover:text-[#0F172A] flex items-center justify-center cursor-pointer"
                  >
                    {visible.addKey ? (
                      <EyeOff className="w-4 h-4" />
                    ) : (
                      <Eye className="w-4 h-4" />
                    )}
                  </button>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-1.5 min-w-0">
                <select
                  aria-label="Provider override"
                  value={providerOverride}
                  onChange={(e) =>
                    setProviderOverride(e.target.value as 'auto' | ApiKeyProvider)
                  }
                  className="flex-1 min-w-[130px] h-9 px-2.5 rounded-xl bg-white border border-slate-200/90 text-[11px] font-semibold text-[#0F172A] focus:outline-none focus:border-[#007AFF]"
                >
                  <option value="auto">
                    Auto ({getProviderDisplayName(detectedProvider)})
                  </option>
                  {PROVIDER_OPTIONS.map((opt) => (
                    <option key={opt.value} value={opt.value}>
                      {opt.label}
                    </option>
                  ))}
                </select>

                <input
                  type="text"
                  aria-label="Key label"
                  value={newLabel}
                  onChange={(e) => setNewLabel(e.target.value)}
                  placeholder="Label (optional)"
                  className="flex-1 min-w-[110px] h-9 px-2.5 rounded-xl bg-white border border-slate-200/90 text-[11px] text-[#0F172A] placeholder:text-[#94A3B8] focus:outline-none focus:border-[#007AFF]"
                />

                <button
                  type="button"
                  onClick={() => setShowOptionalCustom((prev) => !prev)}
                  className="h-9 px-2 rounded-xl bg-white border border-slate-200/90 text-[10.5px] font-semibold text-[#475569] hover:text-[#007AFF] whitespace-nowrap cursor-pointer"
                >
                  {showOptionalCustom ? 'Hide URL/Model' : 'URL/Model'}
                </button>
              </div>

              {/* Conditional Cloudflare Account ID (when user didn't paste AccountID:Token) */}
              {effectiveAddProvider === 'cloudflare' && !newKeyValue.includes(':') && (
                <input
                  type="text"
                  aria-label="Cloudflare Account ID"
                  value={newSecondaryId}
                  onChange={(e) => setNewSecondaryId(e.target.value)}
                  placeholder="Cloudflare Account ID (or paste AccountID:Token above)"
                  className="w-full min-w-0 h-9 px-2.5 rounded-xl bg-white border border-[#F97316]/35 font-mono text-[11px] text-[#0F172A] placeholder:text-[#94A3B8] focus:outline-none focus:border-[#F97316]"
                />
              )}

              {/* Base URL & Model inputs for Custom /v1 or optional override */}
              {(effectiveAddProvider === 'custom' || showOptionalCustom) && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                  <input
                    type="url"
                    aria-label="Custom Base URL"
                    value={newBaseUrl}
                    onChange={(e) => setNewBaseUrl(e.target.value)}
                    placeholder="Base URL (e.g. https://api.openai.com/v1)"
                    className="w-full min-w-0 h-9 px-2.5 rounded-xl bg-white border border-slate-200/90 font-mono text-[11px] text-[#0F172A] placeholder:text-[#94A3B8] focus:outline-none focus:border-[#007AFF]"
                  />
                  <input
                    type="text"
                    aria-label="Model override"
                    value={newModel}
                    onChange={(e) => setNewModel(e.target.value)}
                    placeholder={`Model (${getDefaultModelForProvider(effectiveAddProvider)})`}
                    className="w-full min-w-0 h-9 px-2.5 rounded-xl bg-white border border-slate-200/90 font-mono text-[11px] text-[#0F172A] placeholder:text-[#94A3B8] focus:outline-none focus:border-[#007AFF]"
                  />
                </div>
              )}

              <div className="flex items-center justify-between gap-2 pt-0.5">
                <span className="text-[10px] text-[#64748B] truncate">
                  {geminiKeyCount > 1
                    ? `${geminiKeyCount} Gemini keys active (auto-rotation ON)`
                    : 'Paste multiple Gemini keys for automatic failover rotation'}
                </span>
                <button
                  type="button"
                  onClick={handleAddPoolKey}
                  disabled={!newKeyValue.trim()}
                  className={`h-9 px-3 rounded-xl text-[11.5px] font-bold inline-flex items-center gap-1.5 transition-all whitespace-nowrap shrink-0 cursor-pointer active:scale-95 disabled:opacity-45 ${
                    savedSlots.addKey
                      ? 'bg-[#10B981] text-white shadow-xs'
                      : 'bg-gradient-to-r from-[#007AFF] to-[#5856D6] hover:brightness-105 text-white shadow-xs'
                  }`}
                >
                  {savedSlots.addKey ? (
                    <span>Saved ✓</span>
                  ) : (
                    <>
                      <Plus className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                      <span>+ Add &amp; Save</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Active Key Pool List */}
            {keyPool.length === 0 ? (
              <div className="rounded-xl bg-slate-50/90 border border-dashed border-slate-200 px-3 py-4 text-center">
                <p className="text-[11.5px] font-semibold text-[#475569]">
                  No AI keys in your Smart Pool yet.
                </p>
                <p className="text-[10.5px] text-[#64748B] mt-0.5">
                  Paste any Gemini, Groq, NVIDIA, Cloudflare (AccountID:Token), OpenRouter, Cohere, or Custom /v1 key above.
                </p>
              </div>
            ) : (
              <div className="flex flex-col gap-2">
                {keyPool.map((entry) => {
                  const slotKey: SaveSlotKey = `key:${entry.id}`;
                  const isVisible = Boolean(entryVisible[entry.id]);
                  const isSaved = Boolean(savedSlots[slotKey]);
                  const selectedNvidiaModel =
                    entry.model?.trim() || DEFAULT_2026_MODELS.nvidia;
                  const nvidiaDropdownOptions = nvidiaModels.includes(selectedNvidiaModel)
                    ? nvidiaModels
                    : [selectedNvidiaModel, ...nvidiaModels];

                  return (
                    <div
                      key={entry.id}
                      className={`rounded-xl border p-2.5 flex flex-col gap-2 transition-all ${
                        entry.enabled
                          ? 'bg-white border-slate-200/90 shadow-2xs'
                          : 'bg-slate-50/80 border-slate-200/70 opacity-75'
                      }`}
                    >
                      {/* Entry Top Row: Provider Pill + Label + Live Status Badge */}
                      <div className="flex flex-wrap items-center justify-between gap-1.5 min-w-0">
                        <div className="flex items-center gap-1.5 min-w-0 flex-1">
                          <span
                            className={`px-1.5 py-0.5 rounded-md border text-[10px] font-bold whitespace-nowrap shrink-0 ${getProviderChipClass(
                              entry.provider
                            )}`}
                          >
                            {getProviderDisplayName(entry.provider)}
                          </span>
                          <input
                            type="text"
                            aria-label={`Label for ${entry.label}`}
                            value={entry.label}
                            onChange={(e) =>
                              handleUpdatePoolEntry(entry.id, { label: e.target.value })
                            }
                            className="min-w-0 flex-1 h-6 px-1.5 rounded-md bg-transparent hover:bg-slate-50 focus:bg-white border border-transparent focus:border-slate-200 text-[11.5px] font-bold text-[#0F172A] focus:outline-none truncate"
                          />
                        </div>
                        <div className="flex items-center gap-1 shrink-0">
                          {renderEntryStatusBadge(entry)}
                        </div>
                      </div>

                      {/* Key Input Row + Enable Toggle + Save + Delete */}
                      <div className="flex items-center gap-1.5 min-w-0">
                        <div className="relative flex-1 min-w-0 flex items-center">
                          <input
                            type={isVisible ? 'text' : 'password'}
                            aria-label={`${entry.label} API Key`}
                            value={entry.apiKey}
                            onChange={(e) =>
                              handleUpdatePoolEntry(entry.id, { apiKey: e.target.value })
                            }
                            autoComplete="off"
                            className="w-full min-w-0 h-9 pl-2.5 pr-9 rounded-xl bg-[#F8FAFE] border border-slate-200/90 font-mono text-[11px] text-[#0F172A] focus:outline-none focus:border-[#007AFF]"
                          />
                          <button
                            type="button"
                            onClick={() => toggleEntryVisible(entry.id)}
                            aria-label={isVisible ? 'Hide key' : 'Show key'}
                            className="absolute right-1 w-7 h-7 rounded-lg text-[#64748B] hover:text-[#0F172A] flex items-center justify-center cursor-pointer"
                          >
                            {isVisible ? (
                              <EyeOff className="w-3.5 h-3.5" />
                            ) : (
                              <Eye className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </div>

                        <button
                          type="button"
                          onClick={() =>
                            handleUpdatePoolEntry(
                              entry.id,
                              { enabled: !entry.enabled },
                              true
                            )
                          }
                          aria-pressed={entry.enabled}
                          title={entry.enabled ? 'Disable key' : 'Enable key'}
                          className={`w-9 h-9 rounded-xl border flex items-center justify-center shrink-0 transition-all cursor-pointer active:scale-95 ${
                            entry.enabled
                              ? 'bg-[#10B981]/12 text-[#047857] border-[#10B981]/30'
                              : 'bg-slate-100 text-[#94A3B8] border-slate-200'
                          }`}
                        >
                          <Power className="w-3.5 h-3.5" aria-hidden="true" />
                        </button>

                        <button
                          type="button"
                          onClick={() => savePartialSecrets(slotKey)}
                          aria-label={`Save ${entry.label}`}
                          className={`h-9 px-2.5 rounded-xl border text-[11px] font-bold inline-flex items-center justify-center gap-1 transition-all whitespace-nowrap shrink-0 cursor-pointer active:scale-95 ${
                            isSaved
                              ? 'bg-[#10B981] text-white border-[#10B981] shadow-xs'
                              : 'bg-[#007AFF]/10 hover:bg-[#007AFF]/18 text-[#007AFF] border-[#007AFF]/25'
                          }`}
                        >
                          {isSaved ? (
                            <span>Saved ✓</span>
                          ) : (
                            <>
                              <Save className="w-3 h-3 shrink-0" aria-hidden="true" />
                              <span>Save</span>
                            </>
                          )}
                        </button>

                        <button
                          type="button"
                          onClick={() => handleDeletePoolEntry(entry.id)}
                          aria-label={`Delete ${entry.label}`}
                          className="w-9 h-9 rounded-xl border bg-[#FF3B30]/8 hover:bg-[#FF3B30]/16 text-[#DC2626] border-[#FF3B30]/25 flex items-center justify-center shrink-0 transition-all cursor-pointer active:scale-95"
                        >
                          <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                        </button>
                      </div>

                      {/* Provider-Specific Model / URL Controls */}
                      {entry.provider === 'nvidia' ? (
                        <div className="flex items-center gap-1.5 min-w-0">
                          <label
                            htmlFor={`nvidia-model-${entry.id}`}
                            className="text-[10.5px] font-semibold text-[#047857] whitespace-nowrap shrink-0"
                          >
                            Model ({nvidiaDropdownOptions.length}):
                          </label>
                          <select
                            id={`nvidia-model-${entry.id}`}
                            value={selectedNvidiaModel}
                            onChange={(e) =>
                              handleUpdatePoolEntry(
                                entry.id,
                                { model: e.target.value },
                                true
                              )
                            }
                            className="flex-1 min-w-0 h-8 px-2 rounded-lg bg-[#F0FDF4] border border-[#10B981]/30 font-mono text-[10.5px] font-semibold text-[#047857] focus:outline-none focus:border-[#10B981] truncate"
                          >
                            {nvidiaDropdownOptions.map((modelId) => (
                              <option key={modelId} value={modelId}>
                                {modelId}
                              </option>
                            ))}
                          </select>
                        </div>
                      ) : entry.provider === 'cloudflare' ? (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 min-w-0">
                          <input
                            type="text"
                            aria-label="Cloudflare Account ID"
                            value={
                              entry.secondaryId ??
                              parseCloudflareCredential(entry.apiKey).accountId
                            }
                            onChange={(e) =>
                              handleUpdatePoolEntry(entry.id, {
                                secondaryId: e.target.value,
                              })
                            }
                            placeholder="Cloudflare Account ID"
                            className="w-full min-w-0 h-8 px-2.5 rounded-lg bg-[#FFF7ED] border border-[#F97316]/30 font-mono text-[10.5px] text-[#C2410C] focus:outline-none focus:border-[#F97316]"
                          />
                          <input
                            type="text"
                            aria-label="Cloudflare Model"
                            value={entry.model ?? DEFAULT_2026_MODELS.cloudflare}
                            onChange={(e) =>
                              handleUpdatePoolEntry(entry.id, { model: e.target.value })
                            }
                            className="w-full min-w-0 h-8 px-2.5 rounded-lg bg-[#F6F9FE] border border-slate-200/80 font-mono text-[10.5px] text-[#0F172A] focus:outline-none focus:border-[#007AFF]"
                          />
                        </div>
                      ) : entry.provider === 'custom' ? (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 min-w-0">
                          <input
                            type="url"
                            aria-label="Custom Base URL"
                            value={entry.baseUrl ?? ''}
                            onChange={(e) =>
                              handleUpdatePoolEntry(entry.id, { baseUrl: e.target.value })
                            }
                            placeholder="https://api.example.com/v1"
                            className="w-full min-w-0 h-8 px-2.5 rounded-lg bg-[#F6F9FE] border border-slate-200/80 font-mono text-[10.5px] text-[#0F172A] focus:outline-none focus:border-[#007AFF]"
                          />
                          <input
                            type="text"
                            aria-label="Custom Model"
                            value={entry.model ?? DEFAULT_2026_MODELS.custom}
                            onChange={(e) =>
                              handleUpdatePoolEntry(entry.id, { model: e.target.value })
                            }
                            placeholder="Model ID"
                            className="w-full min-w-0 h-8 px-2.5 rounded-lg bg-[#F6F9FE] border border-slate-200/80 font-mono text-[10.5px] text-[#0F172A] focus:outline-none focus:border-[#007AFF]"
                          />
                        </div>
                      ) : (
                        <div className="flex items-center gap-1.5 min-w-0">
                          <span className="text-[10.5px] font-semibold text-[#64748B] shrink-0">
                            Model:
                          </span>
                          <input
                            type="text"
                            aria-label={`${entry.label} model`}
                            value={
                              entry.model ?? getDefaultModelForProvider(entry.provider)
                            }
                            onChange={(e) =>
                              handleUpdatePoolEntry(entry.id, { model: e.target.value })
                            }
                            className="flex-1 min-w-0 h-8 px-2.5 rounded-lg bg-[#F6F9FE] border border-slate-200/80 font-mono text-[10.5px] font-semibold text-[#0F172A] focus:outline-none focus:border-[#007AFF]"
                          />
                          {entry.provider === 'gemini' && (
                            <span
                              title="Automatic 429 fallback model"
                              className="hidden sm:inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-md bg-[#007AFF]/8 text-[#007AFF] font-mono text-[9.5px] font-semibold whitespace-nowrap shrink-0"
                            >
                              <RefreshCw className="w-2.5 h-2.5" aria-hidden="true" />
                              3.5-lite
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </section>

          {/* SECTION B: GitHub & 3D Asset Vault */}
          <section className="bg-white/85 backdrop-blur-xl border border-slate-200/80 shadow-[0_6px_22px_rgba(15,23,42,0.04)] rounded-2xl p-3 flex flex-col gap-3">
            <div className="flex items-center gap-2 min-w-0">
              <span className="w-6 h-6 rounded-lg bg-[#10B981]/12 text-[#10B981] flex items-center justify-center shrink-0">
                <Github className="w-3.5 h-3.5" aria-hidden="true" />
              </span>
              <h3 className="text-[12.5px] font-bold text-[#0F172A] truncate">
                Section B · GitHub &amp; 3D Asset Vault
              </h3>
            </div>

            {/* GitHub PAT */}
            <div className="flex flex-col gap-1">
              <label
                htmlFor="secret-github-pat"
                className="text-[11.5px] font-bold text-[#0F172A]"
              >
                GitHub PAT
              </label>
              <div className="relative flex items-center">
                <input
                  id="secret-github-pat"
                  type={visible.github ? 'text' : 'password'}
                  value={draft.githubToken}
                  onChange={(e) => updateField('githubToken', e.target.value)}
                  placeholder="github_pat_... or ghp_..."
                  autoComplete="off"
                  className={`${inputBaseClass} pr-10 font-mono`}
                />
                <button
                  type="button"
                  onClick={() => toggleShow('github')}
                  aria-label={visible.github ? 'Hide GitHub PAT' : 'Show GitHub PAT'}
                  className="absolute right-1.5 w-8 h-8 rounded-lg text-[#64748B] hover:text-[#0F172A] flex items-center justify-center cursor-pointer"
                >
                  {visible.github ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Target GitHub Repo */}
            <div className="flex flex-col gap-1">
              <label
                htmlFor="secret-github-repo"
                className="text-[11.5px] font-bold text-[#0F172A]"
              >
                Target GitHub Repo (owner/repo)
              </label>
              <input
                id="secret-github-repo"
                type="text"
                value={draft.targetRepo ?? DEFAULT_TARGET_REPO}
                onChange={(e) => updateField('targetRepo', e.target.value)}
                placeholder={DEFAULT_TARGET_REPO}
                className={`${inputBaseClass} font-mono`}
              />
            </div>

            {/* 3D Asset Vault catalog.json URL + Verify Vault */}
            <div className="flex flex-col gap-1.5">
              <label
                htmlFor="secret-vault-url"
                className="text-[11.5px] font-bold text-[#0F172A] flex items-center gap-1.5"
              >
                <Box className="w-3.5 h-3.5 text-[#5856D6] shrink-0" aria-hidden="true" />
                <span>3D Asset Vault catalog.json URL</span>
              </label>
              <input
                id="secret-vault-url"
                type="url"
                value={draft.assetVaultUrl ?? DEFAULT_ASSET_VAULT_URL}
                onChange={(e) => {
                  updateField('assetVaultUrl', e.target.value);
                  if (verifyResult) setVerifyResult(null);
                }}
                placeholder={DEFAULT_ASSET_VAULT_URL}
                className={`${inputBaseClass} font-mono text-[11px]`}
              />

              <div className="flex flex-wrap items-center justify-between gap-2 pt-0.5">
                <div className="flex flex-wrap items-center gap-1.5">
                  <button
                    type="button"
                    onClick={handleVerifyVault}
                    disabled={verifying}
                    className="h-9 px-3 rounded-xl bg-gradient-to-r from-[#10B981] to-[#007AFF] hover:brightness-105 disabled:opacity-60 text-white text-[11.5px] font-semibold inline-flex items-center gap-1.5 shadow-xs transition-all whitespace-nowrap cursor-pointer active:scale-[0.98]"
                  >
                    {verifying ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin shrink-0" aria-hidden="true" />
                    ) : (
                      <CheckCircle2 className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                    )}
                    <span>{verifying ? 'Verifying...' : 'Verify Vault'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => savePartialSecrets('githubVault')}
                    className={`h-9 px-3 rounded-xl border text-[11.5px] font-bold inline-flex items-center gap-1.5 transition-all whitespace-nowrap cursor-pointer active:scale-[0.98] ${
                      savedSlots.githubVault
                        ? 'bg-[#10B981] text-white border-[#10B981] shadow-xs'
                        : 'bg-[#007AFF]/10 hover:bg-[#007AFF]/18 text-[#007AFF] border-[#007AFF]/25'
                    }`}
                  >
                    {savedSlots.githubVault ? (
                      <span>Saved ✓</span>
                    ) : (
                      <>
                        <Save className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                        <span>Save GitHub &amp; Vault</span>
                      </>
                    )}
                  </button>
                </div>

                {verifyResult && (
                  <div
                    className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold max-w-full ${
                      verifyResult.ok
                        ? 'bg-[#10B981]/12 text-[#047857]'
                        : 'bg-[#FF3B30]/10 text-[#DC2626]'
                    }`}
                  >
                    {verifyResult.ok ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                        <span className="font-mono tabular-nums truncate">
                          Verified · {verifyResult.count} assets
                        </span>
                      </>
                    ) : (
                      <>
                        <AlertCircle className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                        <span className="truncate">{verifyResult.error}</span>
                      </>
                    )}
                  </div>
                )}
              </div>
            </div>
          </section>

          {/* SECTION C: Dual Isolated Supabase */}
          <section className="bg-white/85 backdrop-blur-xl border border-slate-200/80 shadow-[0_6px_22px_rgba(15,23,42,0.04)] rounded-2xl p-3 flex flex-col gap-3">
            <div className="flex items-center gap-2 min-w-0">
              <span className="w-6 h-6 rounded-lg bg-[#5856D6]/12 text-[#5856D6] flex items-center justify-center shrink-0">
                <Database className="w-3.5 h-3.5" aria-hidden="true" />
              </span>
              <h3 className="text-[12.5px] font-bold text-[#0F172A] truncate">
                Section C · Dual Isolated Supabase
              </h3>
            </div>

            {/* 1. Studio Supabase (Memory & Skills Only) */}
            <div className="rounded-xl bg-[#F6F9FE] border border-[#5856D6]/20 p-2.5 flex flex-col gap-2">
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <span className="text-[11.5px] font-bold text-[#0F172A]">
                  Studio Supabase (Memory &amp; Skills Only)
                </span>
                <div className="flex items-center gap-1.5 flex-wrap">
                  <button
                    type="button"
                    onClick={handleCopySql}
                    className={`h-7 px-2.5 rounded-lg text-[11px] font-semibold inline-flex items-center gap-1 transition-all whitespace-nowrap cursor-pointer ${
                      sqlCopied
                        ? 'bg-[#10B981] text-white'
                        : 'bg-[#5856D6] hover:bg-[#4947C2] text-white'
                    }`}
                  >
                    {sqlCopied ? (
                      <Check className="w-3 h-3 shrink-0" aria-hidden="true" />
                    ) : (
                      <Copy className="w-3 h-3 shrink-0" aria-hidden="true" />
                    )}
                    <span>{sqlCopied ? 'Copied!' : 'Copy Studio SQL'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => savePartialSecrets('studioDb')}
                    className={`h-7 px-2.5 rounded-lg border text-[11px] font-bold inline-flex items-center gap-1 transition-all whitespace-nowrap cursor-pointer active:scale-95 ${
                      savedSlots.studioDb
                        ? 'bg-[#10B981] text-white border-[#10B981] shadow-xs'
                        : 'bg-[#007AFF]/10 hover:bg-[#007AFF]/18 text-[#007AFF] border-[#007AFF]/25'
                    }`}
                  >
                    {savedSlots.studioDb ? (
                      <span>Saved ✓</span>
                    ) : (
                      <>
                        <Save className="w-3 h-3 shrink-0" aria-hidden="true" />
                        <span>Save Studio DB</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              <div className="flex flex-col gap-1.5">
                <input
                  aria-label="Studio Supabase URL"
                  type="url"
                  value={draft.studioSupabaseUrl ?? ''}
                  onChange={(e) => updateField('studioSupabaseUrl', e.target.value)}
                  placeholder="https://your-studio-project.supabase.co"
                  className={`${inputBaseClass} font-mono text-[11px]`}
                />
                <div className="relative flex items-center">
                  <input
                    aria-label="Studio Supabase Anon Key"
                    type={visible.studioSupabase ? 'text' : 'password'}
                    value={draft.studioSupabaseAnonKey ?? ''}
                    onChange={(e) =>
                      updateField('studioSupabaseAnonKey', e.target.value)
                    }
                    placeholder="Studio Supabase Anon Key (eyJ...)"
                    autoComplete="off"
                    className={`${inputBaseClass} pr-10 font-mono text-[11px]`}
                  />
                  <button
                    type="button"
                    onClick={() => toggleShow('studioSupabase')}
                    aria-label={
                      visible.studioSupabase
                        ? 'Hide Studio Supabase key'
                        : 'Show Studio Supabase key'
                    }
                    className="absolute right-1.5 w-8 h-8 rounded-lg text-[#64748B] hover:text-[#0F172A] flex items-center justify-center cursor-pointer"
                  >
                    {visible.studioSupabase ? (
                      <EyeOff className="w-4 h-4" />
                    ) : (
                      <Eye className="w-4 h-4" />
                    )}
                  </button>
                </div>
              </div>
            </div>

            {/* 2. Generated Apps Supabase (Exported Games/Apps Only) */}
            <div className="rounded-xl bg-[#F6FBF9] border border-[#10B981]/25 p-2.5 flex flex-col gap-2">
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <span className="text-[11.5px] font-bold text-[#0F172A]">
                  Generated Apps Supabase (Exported Games/Apps Only)
                </span>
                <button
                  type="button"
                  onClick={() => savePartialSecrets('appsDb')}
                  className={`h-7 px-2.5 rounded-lg border text-[11px] font-bold inline-flex items-center gap-1 transition-all whitespace-nowrap cursor-pointer active:scale-95 ${
                    savedSlots.appsDb
                      ? 'bg-[#10B981] text-white border-[#10B981] shadow-xs'
                      : 'bg-[#10B981]/12 hover:bg-[#10B981]/20 text-[#047857] border-[#10B981]/30'
                  }`}
                >
                  {savedSlots.appsDb ? (
                    <span>Saved ✓</span>
                  ) : (
                    <>
                      <Save className="w-3 h-3 shrink-0" aria-hidden="true" />
                      <span>Save Apps DB</span>
                    </>
                  )}
                </button>
              </div>

              <div className="flex flex-col gap-1.5">
                <input
                  aria-label="Generated Apps Supabase URL"
                  type="url"
                  value={draft.appsSupabaseUrl ?? ''}
                  onChange={(e) => updateField('appsSupabaseUrl', e.target.value)}
                  placeholder="https://your-exported-apps.supabase.co"
                  className={`${inputBaseClass} font-mono text-[11px]`}
                />
                <div className="relative flex items-center">
                  <input
                    aria-label="Generated Apps Supabase Anon Key"
                    type={visible.appsSupabase ? 'text' : 'password'}
                    value={draft.appsSupabaseAnonKey ?? ''}
                    onChange={(e) =>
                      updateField('appsSupabaseAnonKey', e.target.value)
                    }
                    placeholder="Exported Apps Anon Key (eyJ...)"
                    autoComplete="off"
                    className={`${inputBaseClass} pr-10 font-mono text-[11px]`}
                  />
                  <button
                    type="button"
                    onClick={() => toggleShow('appsSupabase')}
                    aria-label={
                      visible.appsSupabase
                        ? 'Hide Generated Apps Supabase key'
                        : 'Show Generated Apps Supabase key'
                    }
                    className="absolute right-1.5 w-8 h-8 rounded-lg text-[#64748B] hover:text-[#0F172A] flex items-center justify-center cursor-pointer"
                  >
                    {visible.appsSupabase ? (
                      <EyeOff className="w-4 h-4" />
                    ) : (
                      <Eye className="w-4 h-4" />
                    )}
                  </button>
                </div>
              </div>
            </div>
          </section>
        </div>

        {/* Sticky Footer */}
        <div className="px-3.5 sm:px-5 py-3 bg-white/92 backdrop-blur-xl border-t border-slate-200/80 shrink-0 pb-[max(0.75rem,env(safe-area-inset-bottom))]">
          <button
            type="button"
            onClick={handleSaveAndLock}
            className="w-full h-11 rounded-xl bg-gradient-to-r from-[#007AFF] via-[#5856D6] to-[#10B981] hover:brightness-105 active:scale-[0.98] text-white text-[13px] font-bold inline-flex items-center justify-center gap-2 shadow-[0_6px_18px_rgba(0,122,255,0.28)] transition-all cursor-pointer"
          >
            <Lock className="w-4 h-4 shrink-0" aria-hidden="true" />
            <span>Save &amp; Lock Secrets</span>
          </button>
        </div>
      </div>
    </div>
  );
}
