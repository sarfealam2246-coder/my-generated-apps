import { useEffect, useState, type FormEvent } from 'react';
import {
  FileCode2,
  Save,
  RotateCcw,
  Copy,
  Check,
  X,
  ChevronDown,
  Sparkles,
  Loader2,
  CheckCheck,
  AlertCircle,
  Hammer,
  Archive,
  Monitor,
  History,
  Timer,
} from 'lucide-react';
import type { BuilderStageUpdate } from '../services/studioBuilderService';
import type { ZipDownloadResult } from '../services/zipExportService';
import type {
  BuilderCheckpoint,
  Language,
  PreviewVerifyState,
  VirtualFile,
} from '../types/studio';

export interface PendingAIEditState {
  backupFiles: VirtualFile[];
  changedPaths: string[];
  summary: string;
  providerUsed: string;
}

interface CodePanelProps {
  open: boolean;
  projectName?: string;
  files: VirtualFile[];
  activeFilePath: string | null;
  language: Language;
  pendingAIEdit?: PendingAIEditState | null;
  isAIEditing?: boolean;
  aiEditError?: string | null;
  queuedBuilderPrompt?: string | null;
  isBuildingStep?: boolean;
  builderStage?: BuilderStageUpdate | null;
  builderStageTrail?: string[];
  builderResultNote?: { ok: boolean; text: string } | null;
  builderCheckpoints?: BuilderCheckpoint[];
  previewVerifyState?: PreviewVerifyState;
  onClearQueuedBuilderPrompt?: () => void;
  onRunStudioBuilder?: (prompt: string) => void;
  onRestoreCheckpoint?: (checkpointId: string) => void;
  onDownloadZip?: () => ZipDownloadResult;
  onPreviewDisplayA?: () => void;
  onSelectFile: (path: string) => void;
  onSaveFile: (path: string, content: string) => void;
  onRunAIEdit?: (instruction: string) => void;
  onKeepAllEdits?: () => void;
  onRevertAIEdit?: () => void;
  onClose: () => void;
}

function formatElapsedTime(totalSeconds: number): string {
  const mins = Math.floor(totalSeconds / 60);
  const secs = totalSeconds % 60;
  return `${mins}m ${secs < 10 ? `0${secs}` : secs}s`;
}

export function CodePanel({
  open,
  projectName = 'Sarfealam Auto-Studio',
  files,
  activeFilePath,
  language,
  pendingAIEdit = null,
  isAIEditing = false,
  aiEditError = null,
  queuedBuilderPrompt = null,
  isBuildingStep = false,
  builderStage = null,
  builderStageTrail = [],
  builderResultNote = null,
  builderCheckpoints = [],
  previewVerifyState,
  onClearQueuedBuilderPrompt,
  onRunStudioBuilder,
  onRestoreCheckpoint,
  onDownloadZip,
  onPreviewDisplayA,
  onSelectFile,
  onSaveFile,
  onRunAIEdit,
  onKeepAllEdits,
  onRevertAIEdit,
  onClose,
}: CodePanelProps) {
  const activeFile =
    files.find((f) => f.path === activeFilePath) ?? files[0] ?? null;

  const [draft, setDraft] = useState(activeFile?.content ?? '');
  const [copied, setCopied] = useState(false);
  const [justSaved, setJustSaved] = useState(false);
  const [aiInstruction, setAiInstruction] = useState('');
  const [builderPrompt, setBuilderPrompt] = useState('');
  const [elapsedSec, setElapsedSec] = useState(0);
  const [zipFeedback, setZipFeedback] = useState<string | null>(null);
  const [restoredCpId, setRestoredCpId] = useState<string | null>(null);

  // Sync draft when selected file or saved content changes
  useEffect(() => {
    setDraft(activeFile?.content ?? '');
    setJustSaved(false);
  }, [activeFile?.path, activeFile?.content]);

  // Auto-populate Built-in Studio Builder textarea when Step 2 queues a locked prompt
  useEffect(() => {
    if (queuedBuilderPrompt && queuedBuilderPrompt.trim()) {
      setBuilderPrompt(queuedBuilderPrompt.trim());
    }
  }, [queuedBuilderPrompt]);

  // Live 1-second timer while Built-in Studio Builder is running
  useEffect(() => {
    if (!isBuildingStep) {
      setElapsedSec(0);
      return;
    }
    const start = Date.now();
    setElapsedSec(0);
    const intervalId = window.setInterval(() => {
      setElapsedSec(Math.floor((Date.now() - start) / 1000));
    }, 1000);
    return () => window.clearInterval(intervalId);
  }, [isBuildingStep]);

  if (!open) return null;

  const isDirty = activeFile ? draft !== activeFile.content : false;
  const lineCount = draft ? draft.split('\n').length : 0;

  const handleSave = () => {
    if (!activeFile) return;
    onSaveFile(activeFile.path, draft);
    setJustSaved(true);
    window.setTimeout(() => setJustSaved(false), 1800);
  };

  const handleRevert = () => {
    if (!activeFile) return;
    setDraft(activeFile.content);
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(draft);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      // Fallback copy via temporary textarea if clipboard API is restricted
      const el = document.createElement('textarea');
      el.value = draft;
      el.style.position = 'fixed';
      el.style.opacity = '0';
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      document.body.removeChild(el);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    }
  };

  const handleTriggerZip = () => {
    if (!onDownloadZip) return;
    const res = onDownloadZip();
    if (res.ok) {
      setZipFeedback('ZIP Saved ✓');
      window.setTimeout(() => setZipFeedback(null), 2000);
    } else {
      setZipFeedback(res.error || 'ZIP Error');
      window.setTimeout(() => setZipFeedback(null), 2500);
    }
  };

  const handleRestoreClick = (cpId: string) => {
    if (!onRestoreCheckpoint) return;
    onRestoreCheckpoint(cpId);
    setRestoredCpId(cpId);
    window.setTimeout(() => setRestoredCpId(null), 1800);
  };

  const stageTrailText =
    builderStageTrail.length > 0
      ? builderStageTrail.join(' → ')
      : builderStage?.label || 'Reading files';

  return (
    <div
      className="fixed inset-0 z-[60] bg-slate-900/25 backdrop-blur-[2px] flex items-end sm:items-center justify-center sm:p-4"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label="Code Editor Panel"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-2xl mx-auto bg-white/95 backdrop-blur-2xl border-t sm:border border-slate-200/90 rounded-t-3xl sm:rounded-3xl shadow-[0_-12px_40px_rgba(15,23,42,0.16)] px-3.5 sm:px-5 pt-2.5 pb-8 flex flex-col gap-2.5 max-h-[90dvh] sm:max-h-[84dvh] overflow-y-auto studio-scroll"
      >
        {/* Drag Handle (mobile) */}
        <div
          className="w-10 h-1 rounded-full bg-slate-300/90 mx-auto sm:hidden"
          aria-hidden="true"
        />

        {/* Sheet Header */}
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0 flex-1">
            <div
              className="w-8 h-8 rounded-xl bg-[#007AFF]/10 text-[#007AFF] flex items-center justify-center shrink-0"
              aria-hidden="true"
            >
              <FileCode2 className="w-4 h-4" />
            </div>

            {files.length > 0 && activeFile ? (
              <div className="relative min-w-0 flex-1 max-w-[230px] sm:max-w-xs">
                <label htmlFor="code-panel-file-select" className="sr-only">
                  Select file to edit
                </label>
                <select
                  id="code-panel-file-select"
                  value={activeFile.path}
                  onChange={(e) => onSelectFile(e.target.value)}
                  className="w-full appearance-none h-8 pl-2.5 pr-7 rounded-xl bg-[#F6F9FE] border border-slate-200/90 font-mono text-[11.5px] font-semibold text-[#0F172A] truncate focus:outline-none focus:border-[#007AFF] cursor-pointer"
                >
                  {files.map((file) => (
                    <option key={file.path} value={file.path}>
                      {file.path}
                    </option>
                  ))}
                </select>
                <ChevronDown
                  className="w-3.5 h-3.5 text-[#64748B] pointer-events-none absolute right-2 top-1/2 -translate-y-1/2"
                  aria-hidden="true"
                />
              </div>
            ) : (
              <h3 className="text-[13.5px] font-bold text-[#0F172A] truncate">
                Code Editor
              </h3>
            )}
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close code editor"
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200/80 text-[#0F172A] flex items-center justify-center transition-colors shrink-0 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Built-in Studio Builder (Google-Builder-Style Paste / Timer / Checkpoints / ZIP / Preview) */}
        {onRunStudioBuilder && (
          <section
            aria-label="Built-in Studio Builder"
            className="rounded-2xl bg-gradient-to-br from-[#F3F6FB] via-white/95 to-[#EEF4FF] border border-[#007AFF]/20 p-2.5 flex flex-col gap-2 shadow-2xs"
          >
            <div className="flex items-center justify-between gap-2 min-w-0">
              <div className="flex items-center gap-1.5 min-w-0">
                <span className="w-6 h-6 rounded-lg bg-gradient-to-br from-[#007AFF] to-[#5856D6] text-white flex items-center justify-center shrink-0">
                  <Hammer className="w-3.5 h-3.5" aria-hidden="true" />
                </span>
                <div className="min-w-0">
                  <h4 className="text-[11.5px] font-bold text-[#0F172A] truncate leading-tight">
                    {language === 'hi'
                      ? 'बिल्ट-इन स्टूडियो बिल्डर'
                      : 'Built-in Studio Builder'}
                  </h4>
                  <p className="text-[10px] text-[#64748B] truncate leading-tight">
                    {projectName} · {files.length} file{files.length === 1 ? '' : 's'}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-1 shrink-0">
                {previewVerifyState?.status === 'healing' && (
                  <span className="px-1.5 py-0.5 rounded-md bg-[#5856D6]/12 border border-[#5856D6]/30 text-[#4338CA] text-[9.5px] font-bold inline-flex items-center gap-1 shrink-0">
                    <Loader2 className="w-2.5 h-2.5 animate-spin shrink-0" aria-hidden="true" />
                    <span>
                      Self-Heal {previewVerifyState.attempt}/{previewVerifyState.maxAttempts}
                    </span>
                  </span>
                )}
                {previewVerifyState?.status === 'verified' && (
                  <span className="px-1.5 py-0.5 rounded-md bg-[#10B981]/12 border border-[#10B981]/30 text-[#047857] text-[9.5px] font-bold inline-flex items-center gap-0.5 shrink-0">
                    <Check className="w-2.5 h-2.5 shrink-0" aria-hidden="true" />
                    <span>Preview Verified ✓</span>
                  </span>
                )}
                {previewVerifyState?.status === 'verifying' && !isBuildingStep && (
                  <span className="px-1.5 py-0.5 rounded-md bg-[#007AFF]/10 border border-[#007AFF]/25 text-[#007AFF] text-[9.5px] font-bold inline-flex items-center gap-1 shrink-0">
                    <Loader2 className="w-2.5 h-2.5 animate-spin shrink-0" aria-hidden="true" />
                    <span>Verifying...</span>
                  </span>
                )}
                {previewVerifyState?.status === 'failed' && (
                  <span className="px-1.5 py-0.5 rounded-md bg-[#FF3B30]/10 border border-[#FF3B30]/25 text-[#DC2626] text-[9.5px] font-bold shrink-0">
                    Self-Heal Failed
                  </span>
                )}
                {queuedBuilderPrompt && (
                  <span className="px-1.5 py-0.5 rounded-md bg-[#007AFF]/10 border border-[#007AFF]/25 text-[#007AFF] text-[9.5px] font-bold shrink-0">
                    Step Queued
                  </span>
                )}
              </div>
            </div>

            <form
              onSubmit={(e: FormEvent) => {
                e.preventDefault();
                const clean = builderPrompt.trim();
                if (!clean || isBuildingStep) return;
                onRunStudioBuilder(clean);
              }}
              className="flex flex-col gap-1.5"
            >
              <label htmlFor="studio-builder-prompt" className="sr-only">
                Paste or edit build step prompt
              </label>
              <textarea
                id="studio-builder-prompt"
                rows={3}
                value={builderPrompt}
                onChange={(e) => setBuilderPrompt(e.target.value)}
                disabled={isBuildingStep}
                placeholder={
                  language === 'hi'
                    ? 'JARVIS Step Prompt पेस्ट करें या खुद लिखें (जैसे: "3D space shooter बनाओ touch joystick और score HUD के साथ")...'
                    : 'Paste a locked JARVIS Step Prompt or describe any custom app/3D game step to build...'
                }
                className="w-full min-w-0 p-2.5 rounded-xl bg-white/95 border border-slate-200/90 text-[11.5px] leading-[1.45] text-[#0F172A] placeholder:text-[#94A3B8] resize-y min-h-[68px] max-h-[150px] focus:outline-none focus:border-[#007AFF] focus:ring-2 focus:ring-[#007AFF]/15 studio-scroll"
              />

              <div className="grid grid-cols-[1fr_auto] gap-1.5">
                <button
                  type="submit"
                  disabled={isBuildingStep || !builderPrompt.trim()}
                  className="h-9 px-3 rounded-xl bg-gradient-to-r from-[#007AFF] to-[#5856D6] hover:brightness-105 disabled:opacity-50 text-white text-[11.5px] font-bold inline-flex items-center justify-center gap-1.5 shadow-[0_3px_10px_rgba(0,122,255,0.22)] transition-all whitespace-nowrap cursor-pointer active:scale-[0.98]"
                >
                  {isBuildingStep ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin shrink-0" aria-hidden="true" />
                  ) : (
                    <Hammer className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                  )}
                  <span>
                    {isBuildingStep
                      ? language === 'hi'
                        ? 'बिल्ड चल रहा है...'
                        : 'Building Step...'
                      : language === 'hi'
                        ? 'बिल्ड स्टेप'
                        : 'Build Step'}
                  </span>
                </button>

                {builderPrompt.trim() && !isBuildingStep && (
                  <button
                    type="button"
                    onClick={() => {
                      setBuilderPrompt('');
                      onClearQueuedBuilderPrompt?.();
                    }}
                    className="h-9 px-2.5 rounded-xl bg-white border border-slate-200/90 hover:bg-slate-50 text-[#64748B] text-[11px] font-semibold whitespace-nowrap cursor-pointer"
                  >
                    Clear
                  </button>
                )}
              </div>
            </form>

            {/* Live Timer & Stage Log while running */}
            {isBuildingStep && (
              <div className="rounded-xl bg-white/95 border border-[#007AFF]/25 px-2.5 py-2 flex flex-col gap-1">
                <div className="flex items-center gap-1.5 text-[11px] font-semibold text-[#007AFF] min-w-0">
                  <Timer className="w-3.5 h-3.5 shrink-0 animate-pulse" aria-hidden="true" />
                  <span className="truncate font-mono">
                    Running for {formatElapsedTime(elapsedSec)} · {stageTrailText}...
                  </span>
                </div>
                {builderStage?.detail && (
                  <p className="text-[10px] text-[#64748B] truncate pl-5">
                    {builderStage.detail}
                  </p>
                )}
              </div>
            )}

            {/* Build Result Status Banner */}
            {!isBuildingStep && builderResultNote && (
              <div
                className={
                  builderResultNote.ok
                    ? 'rounded-xl bg-[#10B981]/10 border border-[#10B981]/30 px-2.5 py-1.5 flex items-center gap-1.5 text-[11px] font-medium text-[#047857]'
                    : 'rounded-xl bg-[#FF3B30]/10 border border-[#FF3B30]/25 px-2.5 py-1.5 flex items-center gap-1.5 text-[11px] font-medium text-[#DC2626]'
                }
              >
                {builderResultNote.ok ? (
                  <Check className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                ) : (
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                )}
                <span className="line-clamp-2">{builderResultNote.text}</span>
              </div>
            )}

            {/* Quick Export & Display A Preview Row (360px clean 2-col fit) */}
            <div className="grid grid-cols-2 gap-1.5">
              {onDownloadZip && (
                <button
                  type="button"
                  onClick={handleTriggerZip}
                  disabled={files.length === 0}
                  className="h-8 px-2.5 rounded-xl bg-white hover:bg-slate-50 disabled:opacity-45 border border-slate-200/90 text-[#0F172A] text-[11px] font-semibold inline-flex items-center justify-center gap-1 transition-all whitespace-nowrap cursor-pointer active:scale-[0.98]"
                >
                  {zipFeedback === 'ZIP Saved ✓' ? (
                    <Check className="w-3.5 h-3.5 text-[#10B981] shrink-0" aria-hidden="true" />
                  ) : (
                    <Archive className="w-3.5 h-3.5 text-[#007AFF] shrink-0" aria-hidden="true" />
                  )}
                  <span className="truncate">
                    {zipFeedback ?? (language === 'hi' ? '.ZIP डाउनलोड' : 'Download .ZIP')}
                  </span>
                </button>
              )}

              {onPreviewDisplayA && (
                <button
                  type="button"
                  onClick={onPreviewDisplayA}
                  className="h-8 px-2.5 rounded-xl bg-[#10B981]/12 hover:bg-[#10B981]/20 border border-[#10B981]/30 text-[#047857] text-[11px] font-semibold inline-flex items-center justify-center gap-1 transition-all whitespace-nowrap cursor-pointer active:scale-[0.98]"
                >
                  <Monitor className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                  <span className="truncate">
                    {language === 'hi' ? 'Display A देखें' : 'Preview Display A'}
                  </span>
                </button>
              )}
            </div>

            {/* Checkpoints (Restore) Strip */}
            {builderCheckpoints.length > 0 && onRestoreCheckpoint && (
              <div className="pt-1 border-t border-slate-200/70 flex flex-col gap-1">
                <div className="flex items-center justify-between text-[10px] font-semibold text-[#64748B] px-0.5">
                  <span className="inline-flex items-center gap-1">
                    <History className="w-3 h-3 text-[#5856D6]" aria-hidden="true" />
                    <span>
                      Checkpoints ({builderCheckpoints.length})
                    </span>
                  </span>
                  <span className="text-[9.5px] font-normal">1-tap Restore</span>
                </div>
                <div className="flex gap-1.5 overflow-x-auto pb-0.5 studio-scroll">
                  {builderCheckpoints.slice(0, 5).map((cp) => (
                    <div
                      key={cp.id}
                      className="shrink-0 max-w-[205px] rounded-xl bg-white/95 border border-slate-200/90 px-2 py-1 flex items-center gap-1.5"
                    >
                      <div className="min-w-0">
                        <p className="text-[10.5px] font-semibold text-[#0F172A] truncate">
                          {cp.label}
                        </p>
                        <p className="text-[9.5px] font-mono text-[#64748B] truncate">
                          {cp.files.length} files ·{' '}
                          {new Date(cp.createdAt).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleRestoreClick(cp.id)}
                        disabled={isBuildingStep}
                        className="h-6 px-2 rounded-lg bg-[#F59E0B]/15 hover:bg-[#F59E0B]/25 border border-[#F59E0B]/30 text-[#B45309] text-[10px] font-bold inline-flex items-center gap-0.5 shrink-0 cursor-pointer disabled:opacity-50"
                      >
                        {restoredCpId === cp.id ? (
                          <Check className="w-3 h-3 shrink-0" aria-hidden="true" />
                        ) : (
                          <RotateCcw className="w-3 h-3 shrink-0" aria-hidden="true" />
                        )}
                        <span>{restoredCpId === cp.id ? 'Restored' : 'Restore'}</span>
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </section>
        )}

        {/* Live AI File Edit Instruction Bar */}
        {onRunAIEdit && (
          <form
            onSubmit={(e: FormEvent) => {
              e.preventDefault();
              const clean = aiInstruction.trim();
              if (!clean || isAIEditing) return;
              onRunAIEdit(clean);
              setAiInstruction('');
              onClearQueuedBuilderPrompt?.();
            }}
            className="flex items-center gap-1.5 w-full min-w-0"
          >
            <div className="relative flex-1 min-w-0">
              <Sparkles
                className="w-3.5 h-3.5 text-[#5856D6] absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none"
                aria-hidden="true"
              />
              <input
                type="text"
                value={aiInstruction}
                onChange={(e) => setAiInstruction(e.target.value)}
                disabled={isAIEditing}
                placeholder={
                  language === 'hi'
                    ? 'AI एडिट: जैसे "हीरो कार्ड और बटन जोड़ो"...'
                    : 'AI Edit: e.g. "add an interactive score counter"...'
                }
                aria-label="AI file edit instruction"
                className="w-full min-w-0 h-9 pl-8 pr-2.5 rounded-xl bg-[#F6F9FE] border border-[#5856D6]/25 text-[11.5px] text-[#0F172A] placeholder:text-[#94A3B8] focus:outline-none focus:border-[#5856D6] focus:ring-2 focus:ring-[#5856D6]/15"
              />
            </div>
            <button
              type="submit"
              disabled={isAIEditing || !aiInstruction.trim()}
              className="h-9 px-3 rounded-xl bg-gradient-to-r from-[#5856D6] to-[#007AFF] hover:brightness-105 disabled:opacity-50 text-white text-[11.5px] font-bold inline-flex items-center gap-1 shadow-xs transition-all whitespace-nowrap shrink-0 cursor-pointer active:scale-[0.98]"
            >
              {isAIEditing ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin shrink-0" aria-hidden="true" />
              ) : (
                <Sparkles className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
              )}
              <span>{isAIEditing ? 'Editing...' : 'AI Edit'}</span>
            </button>
          </form>
        )}

        {/* AI Edit Error Banner */}
        {aiEditError && !isAIEditing && (
          <div className="rounded-xl bg-[#FF3B30]/10 border border-[#FF3B30]/25 px-2.5 py-1.5 flex items-center gap-1.5 text-[11px] font-medium text-[#DC2626]">
            <AlertCircle className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
            <span className="truncate">{aiEditError}</span>
          </div>
        )}

        {/* Frosted Staging Banner: Keep All (Apple-emerald) | Revert (coral) */}
        {pendingAIEdit && onKeepAllEdits && onRevertAIEdit && (
          <div className="rounded-2xl bg-gradient-to-r from-[#10B981]/10 via-white/95 to-[#007AFF]/10 backdrop-blur-xl border border-[#10B981]/35 px-3 py-2 flex flex-col gap-2 shadow-2xs">
            <div className="flex items-start justify-between gap-2 min-w-0">
              <div className="min-w-0">
                <p className="text-[11.5px] font-bold text-[#0F172A] line-clamp-1">
                  {pendingAIEdit.summary}
                </p>
                <p className="text-[10px] font-mono text-[#64748B] truncate mt-0.5">
                  {pendingAIEdit.changedPaths.length} file
                  {pendingAIEdit.changedPaths.length === 1 ? '' : 's'} ·{' '}
                  {pendingAIEdit.changedPaths.join(', ')} · {pendingAIEdit.providerUsed}
                </p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-1.5">
              <button
                type="button"
                onClick={onKeepAllEdits}
                className="h-8 px-2.5 rounded-xl bg-gradient-to-r from-[#10B981] to-[#059669] hover:brightness-105 text-white text-[11.5px] font-bold inline-flex items-center justify-center gap-1 shadow-xs transition-all cursor-pointer active:scale-[0.98] whitespace-nowrap"
              >
                <CheckCheck className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                <span>Keep All</span>
              </button>
              <button
                type="button"
                onClick={onRevertAIEdit}
                className="h-8 px-2.5 rounded-xl bg-[#FF3B30]/12 hover:bg-[#FF3B30]/20 border border-[#FF3B30]/30 text-[#DC2626] text-[11.5px] font-bold inline-flex items-center justify-center gap-1 transition-all cursor-pointer active:scale-[0.98] whitespace-nowrap"
              >
                <RotateCcw className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                <span>Revert</span>
              </button>
            </div>
          </div>
        )}

        {/* File Path & Line Count Metadata Strip */}
        {activeFile && (
          <div className="flex items-center justify-between gap-2 px-1 text-[11px] text-[#64748B]">
            <div className="flex items-center gap-1.5 min-w-0">
              <span className="font-mono font-semibold text-[#0F172A] truncate">
                {activeFile.path}
              </span>
              <span aria-hidden="true">·</span>
              <span className="font-mono uppercase text-[10px] shrink-0">
                {activeFile.language}
              </span>
            </div>
            <div className="flex items-center gap-2 font-mono tabular-nums shrink-0">
              <span>{lineCount} lines</span>
              <span aria-hidden="true">·</span>
              <span
                className={
                  isDirty
                    ? 'text-[#F59E0B] font-semibold'
                    : justSaved
                      ? 'text-[#10B981] font-semibold'
                      : 'text-[#64748B]'
                }
              >
                {isDirty ? 'Modified' : justSaved ? 'Saved' : 'Synced'}
              </span>
            </div>
          </div>
        )}

        {/* Editable Monospace Textarea */}
        {activeFile ? (
          <div className="flex-1 min-h-0 flex flex-col">
            <label htmlFor="studio-code-textarea" className="sr-only">
              Code editor for {activeFile.path}
            </label>
            <textarea
              id="studio-code-textarea"
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              spellCheck={false}
              autoCapitalize="off"
              autoCorrect="off"
              className="w-full flex-1 min-h-[200px] sm:min-h-[280px] p-3 rounded-2xl bg-[#F8FAFD] border border-slate-200/90 font-mono text-[12px] leading-[1.55] text-[#0F172A] resize-none focus:outline-none focus:border-[#007AFF] focus:ring-2 focus:ring-[#007AFF]/15 studio-scroll"
            />
          </div>
        ) : (
          <div className="rounded-2xl bg-[#F8FAFD] border border-dashed border-slate-300 p-6 text-center text-[12.5px] text-[#64748B]">
            {language === 'hi'
              ? 'संपादित करने के लिए कोई फ़ाइल नहीं है। फ़ाइल ड्रॉअर से नई फ़ाइल जोड़ें।'
              : 'No files available. Create a file in the File Drawer to start editing.'}
          </div>
        )}

        {/* Action Buttons Row fitting 360px cleanly */}
        <div className="grid grid-cols-[1fr_auto_auto] gap-1.5 pt-0.5">
          <button
            type="button"
            onClick={handleSave}
            disabled={!activeFile || !isDirty}
            className="h-10 px-3 rounded-xl bg-gradient-to-r from-[#007AFF] to-[#5856D6] hover:brightness-105 disabled:opacity-45 text-white text-[12px] font-semibold inline-flex items-center justify-center gap-1.5 shadow-[0_3px_12px_rgba(0,122,255,0.25)] transition-all whitespace-nowrap cursor-pointer active:scale-[0.98]"
          >
            {justSaved ? (
              <Check className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
            ) : (
              <Save className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
            )}
            <span>
              {justSaved
                ? language === 'hi'
                  ? 'सहेजा गया'
                  : 'Saved'
                : language === 'hi'
                  ? 'बदलाव सहेजें'
                  : 'Save Changes'}
            </span>
          </button>

          <button
            type="button"
            onClick={handleRevert}
            disabled={!activeFile || !isDirty}
            className="h-10 px-3 rounded-xl bg-white border border-slate-200/90 hover:bg-slate-50 disabled:opacity-45 text-[#0F172A] text-[12px] font-semibold inline-flex items-center justify-center gap-1 transition-all whitespace-nowrap cursor-pointer active:scale-[0.98]"
          >
            <RotateCcw className="w-3.5 h-3.5 shrink-0 text-[#F59E0B]" aria-hidden="true" />
            <span>{language === 'hi' ? 'रीवर्ट' : 'Revert'}</span>
          </button>

          <button
            type="button"
            onClick={handleCopy}
            disabled={!activeFile}
            className="h-10 px-3 rounded-xl bg-white border border-slate-200/90 hover:bg-slate-50 disabled:opacity-45 text-[#0F172A] text-[12px] font-semibold inline-flex items-center justify-center gap-1 transition-all whitespace-nowrap cursor-pointer active:scale-[0.98]"
          >
            {copied ? (
              <Check className="w-3.5 h-3.5 shrink-0 text-[#10B981]" aria-hidden="true" />
            ) : (
              <Copy className="w-3.5 h-3.5 shrink-0 text-[#007AFF]" aria-hidden="true" />
            )}
            <span>{copied ? 'Copied' : 'Copy'}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
