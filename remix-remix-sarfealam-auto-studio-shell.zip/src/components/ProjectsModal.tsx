import { useState, type FormEvent } from 'react';
import {
  FolderKanban,
  Trash2,
  X,
  CheckCircle2,
  ArrowRightLeft,
  FileCode2,
  Archive,
  HardDrive,
} from 'lucide-react';
import {
  TARGET_ENGINES,
  type Language,
} from '../types/studio';
import type { StudioProjectRecord } from '../services/projectStoreService';

interface ProjectsModalProps {
  open: boolean;
  projects: StudioProjectRecord[];
  activeProjectId: string;
  language: Language;
  onCreateProject: (name?: string) => void;
  onSwitchProject: (id: string) => void;
  onDeleteProject: (id: string) => void;
  onClose: () => void;
}

function formatUpdatedAt(ts: number): string {
  try {
    const diffMs = Date.now() - ts;
    if (diffMs < 60_000) return 'Just now';
    if (diffMs < 3_600_000) return `${Math.floor(diffMs / 60_000)}m ago`;
    if (diffMs < 86_400_000) return `${Math.floor(diffMs / 3_600_000)}h ago`;
    return new Date(ts).toLocaleDateString(undefined, {
      month: 'short',
      day: 'numeric',
    });
  } catch {
    return '';
  }
}

export function ProjectsModal({
  open,
  projects,
  activeProjectId,
  language,
  onCreateProject,
  onSwitchProject,
  onDeleteProject,
  onClose,
}: ProjectsModalProps) {
  const [newProjectName, setNewProjectName] = useState('');

  if (!open) return null;

  const canDelete = projects.length > 1;

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const cleaned = newProjectName.trim();
    onCreateProject(cleaned || undefined);
    setNewProjectName('');
  };

  return (
    <div
      className="fixed inset-0 z-[60] bg-slate-900/25 backdrop-blur-[3px] flex items-end sm:items-center justify-center sm:p-4"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label="Workspace Projects"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-full sm:max-w-lg mx-auto bg-[#F8FAFE]/95 backdrop-blur-2xl border-t sm:border border-slate-200/90 rounded-t-3xl sm:rounded-3xl shadow-[0_-14px_48px_rgba(15,23,42,0.18)] flex flex-col max-h-[88dvh] sm:max-h-[84dvh] overflow-hidden"
      >
        {/* Drag Handle (mobile) */}
        <div className="pt-2.5 pb-1 flex justify-center sm:hidden shrink-0">
          <div className="w-10 h-1 rounded-full bg-slate-300/90" aria-hidden="true" />
        </div>

        {/* Sticky Sheet Header */}
        <div className="px-3.5 sm:px-5 py-2.5 bg-white/85 backdrop-blur-xl border-b border-slate-200/80 flex items-center justify-between gap-2 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div
              className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#007AFF] via-[#5856D6] to-[#10B981] text-white flex items-center justify-center shadow-xs shrink-0"
              aria-hidden="true"
            >
              <FolderKanban className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <h2 className="text-[14px] sm:text-[15px] font-bold text-[#0F172A] tracking-tight truncate">
                {language === 'hi' ? 'प्रोजेक्ट्स वर्कस्पेस' : 'Workspace Projects'}
              </h2>
              <p className="text-[11px] font-medium text-[#64748B] truncate tabular-nums">
                {projects.length} {projects.length === 1 ? 'project' : 'projects'} · IndexedDB Offline VFS
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close Projects"
            className="w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200/80 text-[#0F172A] flex items-center justify-center transition-colors shrink-0 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Create New Project Form */}
        <form
          onSubmit={handleSubmit}
          className="px-3.5 sm:px-5 py-3 bg-white/75 border-b border-slate-200/75 flex flex-col gap-2 shrink-0"
        >
          <div className="flex items-center gap-1.5">
            <label htmlFor="new-project-name-input" className="sr-only">
              New project name
            </label>
            <input
              id="new-project-name-input"
              type="text"
              value={newProjectName}
              onChange={(e) => setNewProjectName(e.target.value)}
              placeholder={
                language === 'hi'
                  ? 'नया प्रोजेक्ट नाम (वैकल्पिक)...'
                  : 'New project name (optional)...'
              }
              className="flex-1 min-w-0 h-10 px-3 rounded-xl bg-white border border-slate-200/90 text-[12.5px] text-[#0F172A] placeholder:text-[#94A3B8] focus:outline-none focus:border-[#007AFF] focus:ring-2 focus:ring-[#007AFF]/15"
            />
            <button
              type="submit"
              className="h-10 px-3 rounded-xl bg-gradient-to-r from-[#007AFF] to-[#5856D6] hover:brightness-105 text-white text-[12px] font-semibold inline-flex items-center gap-1 shadow-xs transition-all whitespace-nowrap shrink-0 cursor-pointer active:scale-[0.98]"
            >
              <span>+ New Project</span>
            </button>
          </div>
          <p className="text-[10.5px] text-[#64748B] flex items-center gap-1">
            <HardDrive className="w-3 h-3 text-[#10B981] shrink-0" aria-hidden="true" />
            <span>
              {language === 'hi'
                ? 'मौजूदा प्रोजेक्ट सुरक्षित रहेगा। API Keys, Memory Rules और Skills सभी प्रोजेक्ट्स में ग्लोबल रहते हैं।'
                : 'Current project stays saved offline. API Keys, Memory Rules & Skills stay global across all projects.'}
            </span>
          </p>
        </form>

        {/* Scrollable Saved Projects List */}
        <div className="flex-1 min-h-0 overflow-y-auto studio-scroll px-3.5 sm:px-5 pt-3 pb-8 flex flex-col gap-2">
          {projects.map((project) => {
            const isActive = project.id === activeProjectId;
            const engineLabel =
              TARGET_ENGINES.find((e) => e.value === project.targetEngine)?.label ?? 'Auto';

            return (
              <div
                key={project.id}
                className={`rounded-2xl bg-white/92 border p-3 flex items-center justify-between gap-2.5 transition-all ${
                  isActive
                    ? 'border-[#007AFF]/50 shadow-[0_4px_16px_rgba(0,122,255,0.12)] ring-1 ring-[#007AFF]/15'
                    : 'border-slate-200/85 hover:border-slate-300 shadow-[0_2px_10px_rgba(15,23,42,0.04)]'
                }`}
              >
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5 min-w-0">
                    <p className="text-[13px] font-bold text-[#0F172A] truncate">
                      {project.name}
                    </p>
                    {isActive && (
                      <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-full bg-[#10B981]/15 text-[#047857] text-[10px] font-bold whitespace-nowrap shrink-0">
                        <CheckCircle2 className="w-2.5 h-2.5 shrink-0" aria-hidden="true" />
                        <span>Active</span>
                      </span>
                    )}
                  </div>

                  <div className="mt-1 flex items-center flex-wrap gap-x-2 gap-y-1 text-[10.5px] text-[#64748B] tabular-nums">
                    <span className="px-1.5 py-0.5 rounded-md bg-[#5856D6]/10 text-[#5856D6] font-semibold">
                      {engineLabel}
                    </span>
                    <span className="px-1.5 py-0.5 rounded-md bg-slate-100 text-[#475569] font-semibold">
                      {project.currentStage}
                    </span>
                    <span className="inline-flex items-center gap-0.5">
                      <FileCode2 className="w-3 h-3 text-[#007AFF]" aria-hidden="true" />
                      {project.files.length}
                    </span>
                    <span className="inline-flex items-center gap-0.5">
                      <Archive className="w-3 h-3 text-[#10B981]" aria-hidden="true" />
                      {project.selectedAssets.length}
                    </span>
                    <span>· {formatUpdatedAt(project.updatedAt)}</span>
                  </div>
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  {!isActive && (
                    <button
                      type="button"
                      onClick={() => onSwitchProject(project.id)}
                      className="h-8 px-2.5 rounded-xl bg-[#007AFF] hover:bg-[#0066D6] text-white text-[11px] font-semibold inline-flex items-center gap-1 shadow-2xs transition-all cursor-pointer active:scale-95 whitespace-nowrap"
                    >
                      <ArrowRightLeft className="w-3 h-3 shrink-0" aria-hidden="true" />
                      <span>Switch</span>
                    </button>
                  )}

                  {canDelete && (
                    <button
                      type="button"
                      onClick={() => onDeleteProject(project.id)}
                      aria-label={`Delete project ${project.name}`}
                      title="Delete project"
                      className="w-8 h-8 rounded-xl text-[#64748B] hover:text-[#FF3B30] hover:bg-[#FF3B30]/10 flex items-center justify-center transition-colors shrink-0 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
