import { studioBus } from './eventBus';
import { DEFAULT_2026_MODELS } from './secretsService';
import type {
  Language,
  StudioApiKeyEntry,
  VoicePersona,
} from '../types/studio';

export interface SpeakStudioReplyOptions {
  geminiKey?: string;
  geminiKeys?: string[];
  keyPool?: StudioApiKeyEntry[];
  ttsModel?: string;
  voicePersona: VoicePersona;
  voiceSpeed: number;
  language: Language;
}

export type TtsEngineUsed =
  | 'cloud-tts'
  | 'capacitor-tts'
  | 'speech-synthesis'
  | 'none';

interface CapacitorTtsPlugin {
  speak: (opts: {
    text: string;
    lang?: string;
    rate?: number;
    pitch?: number;
    volume?: number;
    category?: string;
  }) => Promise<unknown>;
  stop?: () => Promise<unknown>;
}

const CLOUD_TTS_TIMEOUT_MS = 8000;
const TTS_KEY_COOLDOWN_MS = 45_000;
const OUTPUT_SAMPLE_RATE = 24000;

// STRICT INDEPENDENT COOLDOWN: NEVER shared with Chat aiRouter cooldowns!
const ttsKeyCooldownUntil = new Map<string, number>();
let ttsKeyRotationCursor = 0;

let activeSessionToken = 0;
let activeAbortController: AbortController | null = null;
let ttsAudioCtx: AudioContext | null = null;
let activeSourceNode: AudioBufferSourceNode | null = null;
let speakingFlag = false;
let currentPersona: VoicePersona = 'Aoede';
let currentSpeed = 1.0;

function getCapacitorTtsPlugin(): CapacitorTtsPlugin | null {
  if (typeof window === 'undefined') return null;
  const cap = (
    window as unknown as {
      Capacitor?: { Plugins?: { TextToSpeech?: CapacitorTtsPlugin } };
    }
  ).Capacitor;
  const plugin = cap?.Plugins?.TextToSpeech;
  return plugin && typeof plugin.speak === 'function' ? plugin : null;
}

function isTtsKeyCoolingDown(apiKey: string): boolean {
  const until = ttsKeyCooldownUntil.get(apiKey);
  if (!until) return false;
  if (Date.now() >= until) {
    ttsKeyCooldownUntil.delete(apiKey);
    return false;
  }
  return true;
}

function markTtsKeyCooldown(apiKey: string): void {
  ttsKeyCooldownUntil.set(apiKey, Date.now() + TTS_KEY_COOLDOWN_MS);
}

function clearTtsKeyCooldown(apiKey: string): void {
  ttsKeyCooldownUntil.delete(apiKey);
}

function collectOrderedGeminiTtsKeys(options: SpeakStudioReplyOptions): string[] {
  const unique: string[] = [];
  const pushUnique = (raw?: string) => {
    const cleaned = raw?.trim();
    if (cleaned && !unique.includes(cleaned)) {
      unique.push(cleaned);
    }
  };

  if (Array.isArray(options.keyPool)) {
    for (const entry of options.keyPool) {
      if (entry.enabled && entry.provider === 'gemini') {
        pushUnique(entry.apiKey);
      }
    }
  }
  if (Array.isArray(options.geminiKeys)) {
    for (const k of options.geminiKeys) {
      pushUnique(k);
    }
  }
  pushUnique(options.geminiKey);

  if (unique.length <= 1) return unique;

  // Rotate starting index across available Gemini keys for smooth load distribution
  const start = ttsKeyRotationCursor % unique.length;
  const rotated = [...unique.slice(start), ...unique.slice(0, start)];

  const healthy = rotated.filter((k) => !isTtsKeyCoolingDown(k));
  const cooled = rotated
    .filter((k) => isTtsKeyCoolingDown(k))
    .sort(
      (a, b) =>
        (ttsKeyCooldownUntil.get(a) ?? 0) - (ttsKeyCooldownUntil.get(b) ?? 0)
    );

  // Try all healthy keys first; if every key is cooling down, still try the soonest-expiring key once
  return healthy.length > 0 ? healthy : cooled.slice(0, 1);
}

function sanitizeForSpeech(raw: string): string {
  return raw
    .replace(/```[\s\S]*?```/g, ' ')
    .replace(/[`*_#>~]/g, '')
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 900);
}

function normalizeTtsModel(model?: string): string {
  const cleaned = (model || DEFAULT_2026_MODELS.geminiTts)
    .trim()
    .replace(/^models\//i, '');
  if (/gemini-(1\.5|2\.0|2\.5)/i.test(cleaned)) {
    return DEFAULT_2026_MODELS.geminiTts;
  }
  return cleaned || DEFAULT_2026_MODELS.geminiTts;
}

function base64ToUint8Array(base64: string): Uint8Array {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

function pcm16BytesToFloat32(bytes: Uint8Array): Float32Array {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const sampleCount = Math.floor(bytes.byteLength / 2);
  const float32 = new Float32Array(sampleCount);
  for (let i = 0; i < sampleCount; i++) {
    float32[i] = view.getInt16(i * 2, true) / 32768;
  }
  return float32;
}

function emitTtsPhase(phase: 'speaking' | 'idle'): void {
  speakingFlag = phase === 'speaking';
  studioBus.emit('voice:state', {
    active: false,
    phase,
    persona: currentPersona,
    speed: currentSpeed,
    listening: false,
    speaking: phase === 'speaking',
  });
}

function cleanupAudioOnly(): void {
  if (activeAbortController) {
    try {
      activeAbortController.abort();
    } catch {
      // ignore
    }
    activeAbortController = null;
  }

  if (activeSourceNode) {
    try {
      activeSourceNode.onended = null;
      activeSourceNode.stop();
      activeSourceNode.disconnect();
    } catch {
      // ignore
    }
    activeSourceNode = null;
  }

  const capTts = getCapacitorTtsPlugin();
  if (capTts?.stop) {
    try {
      void capTts.stop();
    } catch {
      // ignore
    }
  }

  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    try {
      window.speechSynthesis.cancel();
    } catch {
      // ignore
    }
  }
}

export function isStudioSpeaking(): boolean {
  return speakingFlag;
}

export function setCloudTtsSpeed(speed: number): void {
  const clamped = Math.max(1.0, Math.min(1.5, speed));
  currentSpeed = clamped;
  if (activeSourceNode) {
    try {
      activeSourceNode.playbackRate.value = clamped;
    } catch {
      // ignore
    }
  }
}

export function stopStudioSpeech(): void {
  activeSessionToken += 1;
  cleanupAudioOnly();
  if (speakingFlag) {
    emitTtsPhase('idle');
  } else {
    studioBus.emit('voice:state', {
      active: false,
      phase: 'idle',
      listening: false,
      speaking: false,
    });
  }
}

async function playAudioBase64(
  base64Data: string,
  mimeType: string | undefined,
  speed: number,
  token: number
): Promise<boolean> {
  const AudioCtx =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext: typeof AudioContext })
      .webkitAudioContext;

  if (!ttsAudioCtx || ttsAudioCtx.state === 'closed') {
    ttsAudioCtx = new AudioCtx();
  }
  if (ttsAudioCtx.state === 'suspended') {
    await ttsAudioCtx.resume();
  }

  if (token !== activeSessionToken) return false;

  const bytes = base64ToUint8Array(base64Data);
  if (bytes.byteLength < 2) return false;

  let audioBuffer: AudioBuffer;
  const lowerMime = (mimeType || '').toLowerCase();

  if (
    lowerMime.includes('wav') ||
    lowerMime.includes('mpeg') ||
    lowerMime.includes('mp3') ||
    lowerMime.includes('ogg') ||
    lowerMime.includes('webm')
  ) {
    const arrayBuffer = new ArrayBuffer(bytes.byteLength);
    new Uint8Array(arrayBuffer).set(bytes);
    audioBuffer = await ttsAudioCtx.decodeAudioData(arrayBuffer);
  } else {
    const floatSamples = pcm16BytesToFloat32(bytes);
    if (floatSamples.length === 0) return false;
    audioBuffer = ttsAudioCtx.createBuffer(
      1,
      floatSamples.length,
      OUTPUT_SAMPLE_RATE
    );
    audioBuffer.getChannelData(0).set(floatSamples);
  }

  if (token !== activeSessionToken) return false;

  return new Promise<boolean>((resolve) => {
    if (!ttsAudioCtx || token !== activeSessionToken) {
      resolve(false);
      return;
    }

    const source = ttsAudioCtx.createBufferSource();
    source.buffer = audioBuffer;
    source.playbackRate.value = speed;
    source.connect(ttsAudioCtx.destination);
    activeSourceNode = source;

    emitTtsPhase('speaking');

    source.onended = () => {
      try {
        source.disconnect();
      } catch {
        // ignore
      }
      if (activeSourceNode === source) {
        activeSourceNode = null;
      }
      if (token === activeSessionToken) {
        emitTtsPhase('idle');
      }
      resolve(true);
    };

    source.start(0);
  });
}

async function speakWithCapacitorTts(
  text: string,
  language: Language,
  speed: number,
  token: number
): Promise<boolean> {
  const plugin = getCapacitorTtsPlugin();
  if (!plugin || token !== activeSessionToken) return false;

  try {
    emitTtsPhase('speaking');
    await plugin.speak({
      text,
      lang: language === 'hi' ? 'hi-IN' : 'en-US',
      rate: speed,
      pitch: 1.0,
      volume: 1.0,
      category: 'ambient',
    });
    if (token === activeSessionToken) {
      emitTtsPhase('idle');
    }
    return token === activeSessionToken;
  } catch {
    if (token === activeSessionToken) {
      emitTtsPhase('idle');
    }
    return false;
  }
}

function speakWithBrowserSynthesis(
  text: string,
  language: Language,
  speed: number,
  token: number
): Promise<boolean> {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    return Promise.resolve(false);
  }

  return new Promise<boolean>((resolve) => {
    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      const targetLang = language === 'hi' ? 'hi-IN' : 'en-US';
      utterance.lang = targetLang;
      utterance.rate = speed;

      const voices = window.speechSynthesis.getVoices();
      const matchedVoice =
        voices.find((v) => v.lang.toLowerCase() === targetLang.toLowerCase()) ??
        voices.find((v) =>
          v.lang.toLowerCase().startsWith(language === 'hi' ? 'hi' : 'en')
        );
      if (matchedVoice) {
        utterance.voice = matchedVoice;
      }

      utterance.onstart = () => {
        if (token === activeSessionToken) {
          emitTtsPhase('speaking');
        }
      };

      utterance.onend = () => {
        if (token === activeSessionToken) {
          emitTtsPhase('idle');
        }
        resolve(true);
      };

      utterance.onerror = () => {
        if (token === activeSessionToken) {
          emitTtsPhase('idle');
        }
        resolve(false);
      };

      emitTtsPhase('speaking');
      window.speechSynthesis.speak(utterance);
    } catch {
      if (token === activeSessionToken) {
        emitTtsPhase('idle');
      }
      resolve(false);
    }
  });
}

export async function speakStudioReply(
  text: string,
  options: SpeakStudioReplyOptions
): Promise<TtsEngineUsed> {
  const cleaned = sanitizeForSpeech(text);
  if (!cleaned) return 'none';

  const token = ++activeSessionToken;
  cleanupAudioOnly();

  const speed = Math.max(1.0, Math.min(1.5, options.voiceSpeed || 1.0));
  currentPersona = options.voicePersona;
  currentSpeed = speed;

  const geminiKeys = collectOrderedGeminiTtsKeys(options);
  const model = normalizeTtsModel(options.ttsModel);

  // Independent key-rotating Gemini Studio Voice (Aoede / Kore / Puck / Charon)
  // Works even when Chat is running on Groq, NVIDIA, Cloudflare, OpenRouter, or Cohere
  for (const apiKey of geminiKeys) {
    if (token !== activeSessionToken) return 'none';

    const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(
      model
    )}:generateContent?key=${encodeURIComponent(apiKey)}`;

    const controller = new AbortController();
    activeAbortController = controller;
    const timeoutId = window.setTimeout(
      () => controller.abort(),
      CLOUD_TTS_TIMEOUT_MS
    );

    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: controller.signal,
        body: JSON.stringify({
          contents: [
            {
              parts: [{ text: cleaned }],
            },
          ],
          generationConfig: {
            responseModalities: ['AUDIO'],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: {
                  voiceName: options.voicePersona,
                },
              },
            },
          },
        }),
      });

      if (response.status === 503 || response.status === 429) {
        markTtsKeyCooldown(apiKey);
        continue;
      }

      if (response.ok && token === activeSessionToken) {
        const data = (await response.json()) as {
          candidates?: {
            content?: {
              parts?: {
                inlineData?: {
                  mimeType?: string;
                  data?: string;
                };
              }[];
            };
          }[];
        };

        const audioPart = data.candidates?.[0]?.content?.parts?.find(
          (p) =>
            typeof p.inlineData?.data === 'string' &&
            p.inlineData.data.length > 0
        );

        if (audioPart?.inlineData?.data && token === activeSessionToken) {
          clearTtsKeyCooldown(apiKey);
          ttsKeyRotationCursor += 1;
          const played = await playAudioBase64(
            audioPart.inlineData.data,
            audioPart.inlineData.mimeType,
            speed,
            token
          );
          if (played) {
            return 'cloud-tts';
          }
        }
      } else if (!response.ok) {
        markTtsKeyCooldown(apiKey);
      }
    } catch {
      markTtsKeyCooldown(apiKey);
      // Rotate cleanly to next Gemini key in pool
    } finally {
      window.clearTimeout(timeoutId);
      if (activeAbortController === controller) {
        activeAbortController = null;
      }
    }
  }

  if (token !== activeSessionToken) return 'none';

  // Fallback 1: Native Capacitor TextToSpeech plugin (Android APK / iOS WebView)
  const nativePlayed = await speakWithCapacitorTts(
    cleaned,
    options.language,
    speed,
    token
  );
  if (nativePlayed) {
    return 'capacitor-tts';
  }

  if (token !== activeSessionToken) return 'none';

  // Fallback 2: Browser Web Speech Synthesis
  const fallbackPlayed = await speakWithBrowserSynthesis(
    cleaned,
    options.language,
    speed,
    token
  );
  return fallbackPlayed ? 'speech-synthesis' : 'none';
}
