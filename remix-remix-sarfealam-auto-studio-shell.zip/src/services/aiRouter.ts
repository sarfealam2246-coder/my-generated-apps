import {
  DEFAULT_2026_MODELS,
  getDefaultModelForProvider,
  getProviderDisplayName,
  hydrateKeyPool,
  parseCloudflareCredential,
} from './secretsService';
import { buildMemoryContext } from './memoryService';
import {
  deduplicateActions,
  detectLocalUIActions,
  hasExplicitAssetSearchCommand,
  hasExplicitOpenPanelCommand,
  sanitizeUIActions,
  type UIAction,
} from './uiActuators';
import type {
  ApiKeyProvider,
  PreferredBrain,
  VirtualFile,
  WorldState,
} from '../types/studio';

export interface RouteCommandResult {
  reply: string;
  actions: UIAction[];
  providerUsed: string;
  errorNote?: string;
}

export type AIProviderId = ApiKeyProvider;

interface ProviderAttemptConfig {
  entryId: string;
  id: AIProviderId;
  label: string;
  apiKey: string;
  secondaryId?: string;
  baseUrl?: string;
  model: string;
}

const REQUEST_TIMEOUT_MS = 8_000;
const PROVIDER_COOLDOWN_MS = 60_000;

const providerCooldownUntil = new Map<AIProviderId, number>();
const keyCooldownUntil = new Map<string, number>();

export function markKeyCooldown(
  entryId: string,
  durationMs = PROVIDER_COOLDOWN_MS
): void {
  keyCooldownUntil.set(entryId, Date.now() + durationMs);
}

export function clearKeyCooldown(entryId?: string): void {
  if (entryId) {
    keyCooldownUntil.delete(entryId);
  } else {
    keyCooldownUntil.clear();
  }
}

export function isKeyOnCooldown(entryId: string): boolean {
  const until = keyCooldownUntil.get(entryId);
  if (!until) return false;
  if (Date.now() >= until) {
    keyCooldownUntil.delete(entryId);
    return false;
  }
  return true;
}

export function getKeyCooldownRemainingMs(entryId: string): number {
  const until = keyCooldownUntil.get(entryId);
  if (!until) return 0;
  const remaining = until - Date.now();
  if (remaining <= 0) {
    keyCooldownUntil.delete(entryId);
    return 0;
  }
  return remaining;
}

export function markProviderCooldown(
  providerId: AIProviderId,
  durationMs = PROVIDER_COOLDOWN_MS
): void {
  providerCooldownUntil.set(providerId, Date.now() + durationMs);
}

export function clearProviderCooldown(providerId?: AIProviderId): void {
  if (providerId) {
    providerCooldownUntil.delete(providerId);
  } else {
    providerCooldownUntil.clear();
    keyCooldownUntil.clear();
  }
}

export function isProviderOnCooldown(providerId: AIProviderId): boolean {
  const until = providerCooldownUntil.get(providerId);
  if (!until) return false;
  if (Date.now() >= until) {
    providerCooldownUntil.delete(providerId);
    return false;
  }
  return true;
}

export function getProviderCooldownRemainingMs(providerId: AIProviderId): number {
  const until = providerCooldownUntil.get(providerId);
  if (!until) return 0;
  const remaining = until - Date.now();
  if (remaining <= 0) {
    providerCooldownUntil.delete(providerId);
    return 0;
  }
  return remaining;
}

function shouldTriggerCooldown(err: unknown): boolean {
  if (err instanceof DOMException && err.name === 'AbortError') {
    return true;
  }
  if (err instanceof Error) {
    const msg = err.message;
    return /\bHTTP\s*(503|429)\b/i.test(msg) || /timeout|aborted/i.test(msg);
  }
  return false;
}

function getEffectiveEntryCooldownMs(
  provider: ProviderAttemptConfig,
  hasMultipleForProvider: boolean
): number {
  const keyRemaining = getKeyCooldownRemainingMs(provider.entryId);
  if (keyRemaining > 0) return keyRemaining;
  // When only a single key exists for a provider, also honor provider-level cooldown (e.g. from Cloud TTS)
  if (!hasMultipleForProvider) {
    return getProviderCooldownRemainingMs(provider.id);
  }
  return 0;
}

function prioritizeAvailableProviders(
  providers: ProviderAttemptConfig[]
): { active: ProviderAttemptConfig[]; skippedLabels: string[] } {
  const active: ProviderAttemptConfig[] = [];
  const skippedLabels: string[] = [];

  const countsByProvider = new Map<AIProviderId, number>();
  for (const p of providers) {
    countsByProvider.set(p.id, (countsByProvider.get(p.id) ?? 0) + 1);
  }

  for (const provider of providers) {
    const hasMultiple = (countsByProvider.get(provider.id) ?? 0) > 1;
    const remaining = getEffectiveEntryCooldownMs(provider, hasMultiple);
    if (remaining > 0) {
      const secs = Math.max(1, Math.ceil(remaining / 1000));
      skippedLabels.push(`${provider.label} (cooldown ${secs}s)`);
    } else {
      active.push(provider);
    }
  }

  // If every configured key is on cooldown, try the one expiring soonest so user is not blocked
  if (active.length === 0 && providers.length > 0) {
    const sorted = [...providers].sort((a, b) => {
      const aMulti = (countsByProvider.get(a.id) ?? 0) > 1;
      const bMulti = (countsByProvider.get(b.id) ?? 0) > 1;
      return (
        getEffectiveEntryCooldownMs(a, aMulti) -
        getEffectiveEntryCooldownMs(b, bMulti)
      );
    });
    return { active: [sorted[0]], skippedLabels };
  }

  return { active, skippedLabels };
}

function buildSystemPrompt(state: WorldState): string {
  const fileList = state.files.map((f) => f.path).join(', ') || 'none';
  const langInstruction =
    state.language === 'hi'
      ? 'Respond in natural, friendly Hindi / Hinglish (Devanagari or crisp Hinglish).'
      : 'Respond in crisp, concise, helpful English.';
  const memoryBlock = buildMemoryContext(state.memoryRules);

  return [
    'You are Sarfealam Auto-Studio JARVIS, an on-device mobile studio copilot.',
    langInstruction,
    "The user uses mobile Hindi/Hinglish voice-to-text which often transcribes English tech words phonetically or brokenly (e.g., 'इन मीडिया/in media' = NVIDIA, 'ग्रो/ग्रोक' = Groq, 'सिगरेट' = Secrets, 'एपी की/पीआई' = API Key, 'वॉल्ट/बोल्ट' = Vault, 'अमल' = YAML, 'कोड खोलो' = open code). Always infer the user's real technical intent from conversation context instead of taking misheard words literally.",
    'STRICT NO-AUTO-POPUP LOCK: NEVER return open_panel (secrets, vault, code, admin, camera) or search_assets during normal chat, brainstorming, Q&A, or market/project planning. ONLY trigger open_panel or search_assets when the user gives an explicit direct UI command (e.g., "open secrets", "vault kholo", "find truck assets").',
    'IMPORTANT GUARD: When the user asks to check, test, or verify API keys or providers (Gemini, NVIDIA, Groq, OpenRouter, Cohere, Cloudflare), return {"type":"test_apis"} ONLY — do NOT auto-open Secrets and do NOT auto-spawn a Sub-Bot.',
    `Current Studio State: mode=${state.mode}, language=${state.language}, engine=${state.targetEngine}, displayMode=${state.displayMode}, stage="${state.currentStage}", paused=${state.paused}, activePanel=${state.activePanel}, files=[${fileList}].`,
    ...(memoryBlock ? [memoryBlock] : []),
    'ALWAYS return strict JSON ONLY (no markdown fences) with this exact schema:',
    '{"reply":"short helpful response","actions":[]}',
    'Valid actions array items (only include actions explicitly requested by the user):',
    '- {"type":"open_panel","panel":"none"|"secrets"|"code"|"vault"|"admin"|"camera"}',
    '- {"type":"set_display_mode","mode":"expanded"|"floating"|"collapsed"}',
    '- {"type":"set_language","language":"en"|"hi"}',
    '- {"type":"set_mode","mode":"jarvis"|"manual"}',
    '- {"type":"set_engine","engine":"auto"|"capacitor"|"godot4"|"flutter"|"unity"}',
    '- {"type":"select_file","path":"exact path from files list"}',
    '- {"type":"set_stage","stage":1|2|3|4|5}',
    '- {"type":"save_memory","rule":"concise permanent preference or rule to remember"}',
    '- {"type":"set_paused","paused":true|false}',
    '- {"type":"search_assets","query":"keywords","categories":["vehicles"|"characters"|"weapons_gear"|"village_world"|"textures_pbr"|"hdri_sky"|"audio_sfx"|"app_audio"|"wikimedia_photos"|"iconify_icons"]}',
    '- {"type":"select_asset","target":"1|2|first|second|last|all|asset name","decision":"keep"|"reject"}',
    '- {"type":"clone_repo","repoUrl":"owner/repo or https://github.com/owner/repo"}',
    '- {"type":"build_3d_game","theme":"optional theme e.g. Village Cargo Truck or Village 3D Car Drive"}',
    '- {"type":"build_commercial_app","category":"fintech"|"fantasy"|"ecommerce"|"booking","prompt":"optional app details"}',
    '- {"type":"create_broadcast","topic":"topic for 2-voice 9:16 broadcast short video"}',
    '- {"type":"spawn_sub_bot","role":"specialist role e.g. QA Reviewer or Physics Tuner","task":"focused inspection or tuning task"}',
    '- {"type":"fetch_any_api","name":"short skill name","url":"https://..."}',
    '- {"type":"test_apis"}',
    '- {"type":"run_builder","prompt":"custom build step instruction, or empty string to build the queued step"}',
  ].join('\n');
}

function parseRouterResponse(
  rawText: string,
  files: VirtualFile[]
): { reply: string; actions: UIAction[] } {
  const trimmed = rawText.trim();
  if (!trimmed) {
    return { reply: 'Done.', actions: [] };
  }

  // Strip markdown code fences if model wrapped JSON
  const fenceMatch = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const candidate = fenceMatch ? fenceMatch[1].trim() : trimmed;

  const tryParse = (input: string): { reply: string; actions: UIAction[] } | null => {
    try {
      const parsed: unknown = JSON.parse(input);
      if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
        const obj = parsed as Record<string, unknown>;
        const reply =
          typeof obj.reply === 'string' && obj.reply.trim()
            ? obj.reply.trim()
            : '';
        const actions = sanitizeUIActions(obj.actions, files);
        if (reply || actions.length > 0) {
          return {
            reply: reply || 'Action executed.',
            actions,
          };
        }
      }
    } catch {
      return null;
    }
    return null;
  };

  const direct = tryParse(candidate);
  if (direct) return direct;

  // Try extracting first balanced JSON object substring
  const firstBrace = candidate.indexOf('{');
  const lastBrace = candidate.lastIndexOf('}');
  if (firstBrace !== -1 && lastBrace > firstBrace) {
    const sliced = tryParse(candidate.slice(firstBrace, lastBrace + 1));
    if (sliced) return sliced;
  }

  // Safe fallback to plain text reply
  return {
    reply: trimmed,
    actions: [],
  };
}

async function fetchWithTimeout(
  url: string,
  init: RequestInit,
  timeoutMs = REQUEST_TIMEOUT_MS
): Promise<Response> {
  const controller = new AbortController();
  const timerId = window.setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, {
      ...init,
      signal: controller.signal,
    });
  } finally {
    window.clearTimeout(timerId);
  }
}

function buildRecentChatHistory(
  state: WorldState,
  currentUserInput?: string
): {
  role: 'user' | 'assistant';
  content: string;
}[] {
  const nonSystem = state.messages.filter(
    (m) => m.role === 'user' || m.role === 'jarvis'
  );

  // Avoid duplicating the just-appended user message when it is already at the tail
  const trimmedInput = currentUserInput?.trim() ?? '';
  const withoutTrailingCurrent =
    trimmedInput &&
    nonSystem.length > 0 &&
    nonSystem[nonSystem.length - 1].role === 'user' &&
    nonSystem[nonSystem.length - 1].text.trim() === trimmedInput
      ? nonSystem.slice(0, -1)
      : nonSystem;

  return withoutTrailingCurrent.slice(-6).map((m) => ({
    role: m.role === 'user' ? 'user' : 'assistant',
    content: m.text.slice(0, 600),
  }));
}

async function callGeminiModel(
  apiKey: string,
  model: string,
  systemPrompt: string,
  userInput: string,
  state: WorldState,
  timeoutMs = REQUEST_TIMEOUT_MS
): Promise<string> {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(
    model
  )}:generateContent?key=${encodeURIComponent(apiKey)}`;

  const history = buildRecentChatHistory(state, userInput).map((msg) => ({
    role: msg.role === 'user' ? 'user' : 'model',
    parts: [{ text: msg.content }],
  }));

  const response = await fetchWithTimeout(
    url,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        systemInstruction: {
          parts: [{ text: systemPrompt }],
        },
        contents: [
          ...history,
          {
            role: 'user',
            parts: [{ text: userInput }],
          },
        ],
        generationConfig: {
          temperature: 0.35,
          responseMimeType: 'application/json',
        },
      }),
    },
    timeoutMs
  );

  if (!response.ok) {
    throw new Error(`HTTP ${response.status}`);
  }

  const data = (await response.json()) as {
    candidates?: {
      content?: {
        parts?: { text?: string }[];
      };
    }[];
  };

  const text = data.candidates?.[0]?.content?.parts
    ?.map((p) => p.text ?? '')
    .join('')
    .trim();

  if (!text) {
    throw new Error('Empty Gemini response');
  }
  return text;
}

async function callGemini(
  provider: ProviderAttemptConfig,
  systemPrompt: string,
  userInput: string,
  state: WorldState,
  timeoutMs = REQUEST_TIMEOUT_MS
): Promise<{ text: string; usedModel: string }> {
  try {
    const text = await callGeminiModel(
      provider.apiKey,
      provider.model,
      systemPrompt,
      userInput,
      state,
      timeoutMs
    );
    return { text, usedModel: provider.model };
  } catch (err) {
    const isRateLimited =
      err instanceof Error && /\bHTTP\s*(429|503)\b/i.test(err.message);
    const fallbackModel = DEFAULT_2026_MODELS.geminiFallback;
    if (isRateLimited && provider.model !== fallbackModel) {
      const text = await callGeminiModel(
        provider.apiKey,
        fallbackModel,
        systemPrompt,
        userInput,
        state,
        timeoutMs
      );
      return { text, usedModel: fallbackModel };
    }
    throw err;
  }
}

async function callOpenAICompatible(
  endpoint: string,
  provider: ProviderAttemptConfig,
  systemPrompt: string,
  userInput: string,
  state: WorldState,
  extraHeaders?: Record<string, string>,
  timeoutMs = REQUEST_TIMEOUT_MS
): Promise<string> {
  const history = buildRecentChatHistory(state, userInput);

  const response = await fetchWithTimeout(
    endpoint,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${provider.apiKey}`,
        ...(extraHeaders ?? {}),
      },
      body: JSON.stringify({
        model: provider.model,
        temperature: 0.35,
        messages: [
          { role: 'system', content: systemPrompt },
          ...history,
          { role: 'user', content: userInput },
        ],
      }),
    },
    timeoutMs
  );

  if (!response.ok) {
    throw new Error(`HTTP ${response.status}`);
  }

  const data = (await response.json()) as {
    choices?: {
      message?: {
        content?: string;
      };
    }[];
  };

  const text = data.choices?.[0]?.message?.content?.trim();
  if (!text) {
    throw new Error(`Empty ${provider.label} response`);
  }
  return text;
}

async function callCohere(
  provider: ProviderAttemptConfig,
  systemPrompt: string,
  userInput: string,
  state: WorldState,
  timeoutMs = REQUEST_TIMEOUT_MS
): Promise<string> {
  const history = buildRecentChatHistory(state, userInput);

  const response = await fetchWithTimeout(
    'https://api.cohere.com/v2/chat',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${provider.apiKey}`,
      },
      body: JSON.stringify({
        model: provider.model,
        temperature: 0.35,
        messages: [
          { role: 'system', content: systemPrompt },
          ...history,
          { role: 'user', content: userInput },
        ],
      }),
    },
    timeoutMs
  );

  if (!response.ok) {
    throw new Error(`HTTP ${response.status}`);
  }

  const data = (await response.json()) as {
    message?: {
      content?: { type?: string; text?: string }[];
    };
  };

  const text = data.message?.content
    ?.map((chunk) => (typeof chunk.text === 'string' ? chunk.text : ''))
    .join('')
    .trim();

  if (!text) {
    throw new Error('Empty Cohere response');
  }
  return text;
}

function normalizeCustomChatEndpoint(baseUrl?: string): string {
  const trimmed = baseUrl?.trim() ?? '';
  if (!trimmed) {
    throw new Error('Missing Custom Base URL');
  }
  const clean = trimmed.replace(/\/+$/, '');
  if (/\/chat\/completions$/i.test(clean)) {
    return clean;
  }
  if (/\/v\d+$/i.test(clean)) {
    return `${clean}/chat/completions`;
  }
  return `${clean}/v1/chat/completions`;
}

async function callCloudflare(
  provider: ProviderAttemptConfig,
  systemPrompt: string,
  userInput: string,
  state: WorldState,
  timeoutMs = REQUEST_TIMEOUT_MS
): Promise<string> {
  const { accountId, apiToken } = parseCloudflareCredential(
    provider.apiKey,
    provider.secondaryId
  );
  if (!accountId || !apiToken) {
    throw new Error('Invalid Cloudflare AccountID:Token');
  }
  const endpoint = `https://api.cloudflare.com/client/v4/accounts/${encodeURIComponent(
    accountId
  )}/ai/v1/chat/completions`;

  return callOpenAICompatible(
    endpoint,
    {
      ...provider,
      apiKey: apiToken,
      model: provider.model || DEFAULT_2026_MODELS.cloudflare,
    },
    systemPrompt,
    userInput,
    state,
    undefined,
    timeoutMs
  );
}

async function invokeProviderAttempt(
  provider: ProviderAttemptConfig,
  systemPrompt: string,
  userInput: string,
  state: WorldState,
  timeoutMs = REQUEST_TIMEOUT_MS
): Promise<{ rawText: string; usedLabel: string }> {
  switch (provider.id) {
    case 'gemini': {
      const res = await callGemini(
        provider,
        systemPrompt,
        userInput,
        state,
        timeoutMs
      );
      const usedLabel =
        res.usedModel === DEFAULT_2026_MODELS.geminiFallback &&
        provider.model !== DEFAULT_2026_MODELS.geminiFallback
          ? `${provider.label} (3.5-lite)`
          : provider.label;
      return { rawText: res.text, usedLabel };
    }
    case 'groq': {
      const rawText = await callOpenAICompatible(
        'https://api.groq.com/openai/v1/chat/completions',
        provider,
        systemPrompt,
        userInput,
        state,
        undefined,
        timeoutMs
      );
      return { rawText, usedLabel: provider.label };
    }
    case 'nvidia': {
      const rawText = await callOpenAICompatible(
        'https://integrate.api.nvidia.com/v1/chat/completions',
        provider,
        systemPrompt,
        userInput,
        state,
        undefined,
        timeoutMs
      );
      return { rawText, usedLabel: provider.label };
    }
    case 'cloudflare': {
      const rawText = await callCloudflare(
        provider,
        systemPrompt,
        userInput,
        state,
        timeoutMs
      );
      return { rawText, usedLabel: provider.label };
    }
    case 'openrouter': {
      const rawText = await callOpenAICompatible(
        'https://openrouter.ai/api/v1/chat/completions',
        provider,
        systemPrompt,
        userInput,
        state,
        {
          'HTTP-Referer':
            typeof window !== 'undefined'
              ? window.location.origin
              : 'https://sarfealam.autostudio',
          'X-Title': 'Sarfealam Auto-Studio',
        },
        timeoutMs
      );
      return { rawText, usedLabel: provider.label };
    }
    case 'cohere': {
      const rawText = await callCohere(
        provider,
        systemPrompt,
        userInput,
        state,
        timeoutMs
      );
      return { rawText, usedLabel: provider.label };
    }
    case 'custom': {
      const endpoint = normalizeCustomChatEndpoint(provider.baseUrl);
      const rawText = await callOpenAICompatible(
        endpoint,
        provider,
        systemPrompt,
        userInput,
        state,
        undefined,
        timeoutMs
      );
      return { rawText, usedLabel: provider.label };
    }
  }
}

const DEFAULT_PROVIDER_PRIORITY: ApiKeyProvider[] = [
  'gemini',
  'groq',
  'nvidia',
  'cloudflare',
  'openrouter',
  'cohere',
  'custom',
];

function collectConfiguredProviders(state: WorldState): ProviderAttemptConfig[] {
  const s = state.secrets;
  const pool = hydrateKeyPool(s, Array.isArray(s.keyPool));
  const enabledEntries = pool.filter(
    (entry) => entry.enabled && entry.apiKey.trim().length > 0
  );

  const preferred: PreferredBrain = s.preferredBrain ?? 'auto';
  const orderedProviders: ApiKeyProvider[] =
    preferred !== 'auto'
      ? [preferred, ...DEFAULT_PROVIDER_PRIORITY.filter((p) => p !== preferred)]
      : DEFAULT_PROVIDER_PRIORITY;

  const list: ProviderAttemptConfig[] = [];
  for (const providerId of orderedProviders) {
    const matching = enabledEntries.filter((e) => e.provider === providerId);
    for (const entry of matching) {
      const model =
        entry.model?.trim() || getDefaultModelForProvider(entry.provider);
      list.push({
        entryId: entry.id,
        id: entry.provider,
        label: entry.label?.trim() || getProviderDisplayName(entry.provider),
        apiKey: entry.apiKey.trim(),
        secondaryId: entry.secondaryId?.trim(),
        baseUrl: entry.baseUrl?.trim(),
        model,
      });
    }
  }

  return list;
}

export async function routeStudioCommand(
  userInput: string,
  state: WorldState
): Promise<RouteCommandResult> {
  const localActions = detectLocalUIActions(userInput, state);

  // Fast-path direct API check intent so CommandCenter returns live results in 2–3s without LLM stall
  if (localActions.some((a) => a.type === 'test_apis')) {
    const safeActions = localActions.filter(
      (a) =>
        !(a.type === 'open_panel' && a.panel === 'secrets') &&
        a.type !== 'spawn_sub_bot'
    );
    return {
      reply:
        state.language === 'hi'
          ? 'आपकी कॉन्फ़िगर की गई API keys को लाइव चेक किया जा रहा है...'
          : 'Running live parallel checks on your configured API keys...',
      actions: safeActions,
      providerUsed: 'Local',
    };
  }

  const providers = collectConfiguredProviders(state);

  // Zero keys configured: still execute local actuators + prompt user clearly
  if (providers.length === 0) {
    const hasLocal = localActions.length > 0;
    const reply =
      state.language === 'hi'
        ? hasLocal
          ? 'लोकल कमांड चला दिया गया है। स्मार्ट AI उत्तर के लिए नीचे "Secrets" टैप करके कोई भी API key जोड़ें।'
          : 'अभी कोई AI API key सेव नहीं है। नीचे "Secrets" पर टैप करके Gemini, Groq, NVIDIA, OpenRouter या Cohere की key जोड़ें।'
        : hasLocal
          ? 'Executed your local studio command. Tap "Secrets" below to add an API key for full JARVIS AI responses.'
          : 'No AI API keys are saved yet. Tap "Secrets" below to add a Gemini, Groq, NVIDIA, OpenRouter, or Cohere API key.';

    return {
      reply,
      actions: localActions,
      providerUsed: 'Local',
    };
  }

  const systemPrompt = buildSystemPrompt(state);
  const { active: activeProviders, skippedLabels } =
    prioritizeAvailableProviders(providers);
  const failures: string[] = [...skippedLabels];

  for (const provider of activeProviders) {
    try {
      const { rawText, usedLabel } = await invokeProviderAttempt(
        provider,
        systemPrompt,
        userInput,
        state
      );

      clearKeyCooldown(provider.entryId);
      clearProviderCooldown(provider.id);

      const parsed = parseRouterResponse(rawText, state.files);

      // STRICT NO-AUTO-POPUP LOCK: Drop LLM-hallucinated open_panel or search_assets
      // unless the user gave an explicit direct UI command.
      const guardedParsedActions = parsed.actions.filter((action) => {
        if (action.type === 'open_panel') {
          return hasExplicitOpenPanelCommand(userInput, action.panel);
        }
        if (action.type === 'search_assets') {
          return hasExplicitAssetSearchCommand(userInput);
        }
        return true;
      });

      let mergedActions = deduplicateActions([
        ...localActions,
        ...guardedParsedActions,
      ]);

      // Guard: never auto-open Secrets or auto-spawn Sub-Bot on test_apis intent
      if (mergedActions.some((a) => a.type === 'test_apis')) {
        mergedActions = mergedActions.filter(
          (a) =>
            !(a.type === 'open_panel' && a.panel === 'secrets') &&
            a.type !== 'spawn_sub_bot'
        );
      }

      return {
        reply: parsed.reply,
        actions: mergedActions,
        providerUsed: usedLabel,
        errorNote:
          failures.length > 0
            ? `Fallback after: ${failures.join(', ')}`
            : undefined,
      };
    } catch (err) {
      if (shouldTriggerCooldown(err)) {
        markKeyCooldown(provider.entryId);
        // If all configured keys for this provider are now cooling down, also set provider-level cooldown
        const sameProviderKeys = providers.filter((p) => p.id === provider.id);
        if (sameProviderKeys.every((p) => isKeyOnCooldown(p.entryId))) {
          markProviderCooldown(provider.id);
        }
      }
      const reason =
        err instanceof DOMException && err.name === 'AbortError'
          ? '8s timeout'
          : err instanceof Error
            ? err.message
            : 'failed';
      failures.push(`${provider.label} (${reason})`);
    }
  }

  // All configured providers failed — fall back cleanly to local actuators
  const errorSummary = failures.join(' · ');
  const fallbackReply =
    state.language === 'hi'
      ? localActions.length > 0
        ? `AI प्रोवाइडर उपलब्ध नहीं हैं (${errorSummary}), लेकिन लोकल कमांड चला दिया गया है।`
        : `सभी कॉन्फ़िगर किए गए AI प्रोवाइडर विफल रहे (${errorSummary})। कृपया Secrets में अपनी API keys जाँचें।`
      : localActions.length > 0
        ? `AI providers could not be reached (${errorSummary}), but your local studio action was executed.`
        : `All configured AI providers failed (${errorSummary}). Please check your keys in Secrets.`;

  return {
    reply: fallbackReply,
    actions: localActions,
    providerUsed: 'Local',
    errorNote: errorSummary,
  };
}

export interface RawAICompletionResult {
  ok: boolean;
  rawText: string;
  providerUsed: string;
  error?: string;
}

export interface StudioAICompletionOptions {
  timeoutMs?: number;
}

export async function requestStudioAICompletion(
  systemPrompt: string,
  userPrompt: string,
  state: WorldState,
  options?: StudioAICompletionOptions
): Promise<RawAICompletionResult> {
  const timeoutMs = options?.timeoutMs ?? REQUEST_TIMEOUT_MS;
  const providers = collectConfiguredProviders(state);
  if (providers.length === 0) {
    return {
      ok: false,
      rawText: '',
      providerUsed: 'Local',
      error:
        state.language === 'hi'
          ? 'AI कोड एडिट के लिए पहले Secrets में कोई API Key जोड़ें।'
          : 'Add at least one AI API Key in Secrets to run AI File Edits.',
    };
  }

  const { active: activeProviders, skippedLabels } =
    prioritizeAvailableProviders(providers);
  const failures: string[] = [...skippedLabels];
  const emptyHistoryState: WorldState = {
    ...state,
    messages: [],
  };

  for (const provider of activeProviders) {
    try {
      const { rawText, usedLabel } = await invokeProviderAttempt(
        provider,
        systemPrompt,
        userPrompt,
        emptyHistoryState,
        timeoutMs
      );

      clearKeyCooldown(provider.entryId);
      clearProviderCooldown(provider.id);

      return {
        ok: true,
        rawText,
        providerUsed: usedLabel,
      };
    } catch (err) {
      if (shouldTriggerCooldown(err)) {
        markKeyCooldown(provider.entryId);
        const sameProviderKeys = providers.filter((p) => p.id === provider.id);
        if (sameProviderKeys.every((p) => isKeyOnCooldown(p.entryId))) {
          markProviderCooldown(provider.id);
        }
      }
      const timeoutLabel = `${Math.round(timeoutMs / 1000)}s timeout`;
      const reason =
        err instanceof DOMException && err.name === 'AbortError'
          ? timeoutLabel
          : err instanceof Error
            ? err.message
            : 'failed';
      failures.push(`${provider.label} (${reason})`);
    }
  }

  return {
    ok: false,
    rawText: '',
    providerUsed: 'Local',
    error: `All configured AI providers failed (${failures.join(' · ')}).`,
  };
}

