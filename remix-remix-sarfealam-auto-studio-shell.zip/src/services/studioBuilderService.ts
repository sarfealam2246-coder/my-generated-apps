import { requestStudioAICompletion } from './aiRouter';
import { studioBus } from './eventBus';
import { buildMemoryContext } from './memoryService';
import { hydrateKeyPool } from './secretsService';
import {
  buildErrorMemoryPromptContext,
  loadErrorMemory,
} from './selfHealingService';
import type {
  BuilderCheckpoint,
  StudioAssetItem,
  VirtualFile,
  WorldState,
} from '../types/studio';

export type { BuilderCheckpoint };

export type BuilderStageId = 'reading' | 'coding' | 'staging' | 'done' | 'error';

export interface BuilderStageUpdate {
  stage: BuilderStageId;
  label: string;
  detail?: string;
  progress: number;
}

export interface BuilderUpdatedFile {
  path: string;
  content: string;
  language: string;
}

export interface RunBuiltInStudioBuilderOptions {
  prompt: string;
  files: VirtualFile[];
  selectedAssets: StudioAssetItem[];
  state: WorldState;
  onStageUpdate?: (update: BuilderStageUpdate) => void;
}

export interface RunBuiltInStudioBuilderResult {
  ok: boolean;
  summary: string;
  updatedFiles: BuilderUpdatedFile[];
  nextFiles: VirtualFile[];
  checkpoint: BuilderCheckpoint | null;
  providerUsed: string;
  durationMs: number;
  error?: string;
}

const NVIDIA_CODER_MODEL = 'qwen/qwen3-coder-480b-a35b-instruct';
const BUILDER_TIMEOUT_MS = 48_000;
const MAX_WORKSPACE_CONTEXT_CHARS = 24_000;

interface ParsedBuilderPayload {
  summary: string;
  updatedFiles: BuilderUpdatedFile[];
}

function inferLanguage(path: string, explicit?: string): string {
  if (explicit && explicit.trim()) {
    return explicit.trim().toLowerCase();
  }
  const ext = path.split('.').pop()?.toLowerCase() ?? '';
  if (ext === 'html' || ext === 'htm') return 'html';
  if (ext === 'css') return 'css';
  if (ext === 'js' || ext === 'mjs') return 'js';
  if (ext === 'jsx') return 'jsx';
  if (ext === 'ts') return 'ts';
  if (ext === 'tsx') return 'tsx';
  if (ext === 'json') return 'json';
  if (ext === 'md') return 'markdown';
  if (ext === 'svg') return 'xml';
  if (ext === 'gd') return 'gdscript';
  if (ext === 'dart') return 'dart';
  if (ext === 'cs') return 'csharp';
  return 'text';
}

function sanitizeFilePath(rawPath: string): string {
  const cleaned = rawPath
    .trim()
    .replace(/\\/g, '/')
    .replace(/^\/+/, '')
    .split('/')
    .filter((seg) => seg.length > 0 && seg !== '.' && seg !== '..')
    .join('/');
  return cleaned;
}

function sanitizeWebViewHtml(path: string, content: string): string {
  const lower = path.toLowerCase();
  if (!lower.endsWith('.html') && !lower.endsWith('.htm')) {
    return content;
  }

  let out = content;
  // Never allow importmap inside Android WebView / srcDoc iframes
  out = out.replace(
    /<script\b[^>]*type=["']importmap["'][^>]*>[\s\S]*?<\/script>/gi,
    ''
  );
  // Replace accidental esm.sh Three.js imports with classic UMD Three.js script compatibility note
  out = out.replace(
    /https?:\/\/esm\.sh\/three(?:@[\d.]+)?/gi,
    'https://cdn.jsdelivr.net/npm/three@0.149.0/build/three.min.js'
  );
  return out;
}

function buildCheckpointLabel(prompt: string): string {
  const stepMatch = prompt.match(/\bSTEP\s*(\d+)\b/i);
  const firstLine =
    prompt
      .split('\n')
      .map((l) => l.trim())
      .find((l) => l.length > 0) ?? 'Build Step';

  if (stepMatch) {
    return `Before Step ${stepMatch[1]}`;
  }
  const compact = firstLine.replace(/^STRICT\s+/i, '').slice(0, 28).trim();
  return `Before: ${compact}${firstLine.length > 28 ? '…' : ''}`;
}

function serializeWorkspaceFiles(files: VirtualFile[]): string {
  if (files.length === 0) {
    return '(Workspace currently has 0 files — create clean entry files starting with index.html.)';
  }

  const prioritized = [...files].sort((a, b) => {
    const rank = (p: string): number => {
      const low = p.toLowerCase();
      if (low === 'index.html') return 0;
      if (low === 'docs/index.html') return 1;
      if (low.endsWith('.html')) return 2;
      if (low.endsWith('.js') || low.endsWith('.css')) return 3;
      if (low === 'assets/manifest.json') return 4;
      if (low.endsWith('.tsx') || low.endsWith('.ts')) return 5;
      return 6;
    };
    return rank(a.path) - rank(b.path);
  });

  const blocks: string[] = [];
  let used = 0;

  for (const file of prioritized) {
    const perFileLimit = 5500;
    const body =
      file.content.length > perFileLimit
        ? `${file.content.slice(0, perFileLimit)}\n/* ...truncated (${file.content.length} chars total)... */`
        : file.content;
    const block = `--- FILE: ${file.path} (${file.language}) ---\n${body}`;
    if (used + block.length > MAX_WORKSPACE_CONTEXT_CHARS && blocks.length > 0) {
      blocks.push(
        `--- FILE: ${file.path} (${file.language}, ${file.content.length} chars omitted for context budget) ---`
      );
      continue;
    }
    blocks.push(block);
    used += block.length;
  }

  return blocks.join('\n\n');
}

function serializeSelectedAssets(selectedAssets: StudioAssetItem[]): string {
  if (selectedAssets.length === 0) {
    return 'None selected yet.';
  }
  return selectedAssets
    .slice(0, 24)
    .map(
      (a, idx) =>
        `${idx + 1}. [${a.category}] ${a.name}${a.format ? ` (${a.format})` : ''} -> ${a.url}`
    )
    .join('\n');
}

function buildAppsSupabaseContext(state: WorldState): string {
  // STRICT SECURITY ISOLATION: Read ONLY user's Apps Supabase config, NEVER Studio keys or AI API keys.
  const url = state.secrets.appsSupabaseUrl?.trim() ?? '';
  const anonKey = state.secrets.appsSupabaseAnonKey?.trim() ?? '';
  if (!url && !anonKey) {
    return 'Not configured (use localStorage/IndexedDB for offline persistence if needed).';
  }
  return [
    url ? `APPS_SUPABASE_URL="${url}"` : '',
    anonKey ? `APPS_SUPABASE_ANON_KEY="${anonKey}"` : '',
    'Use ONLY these Apps Supabase values if the requested app requires cloud storage/auth. NEVER reference or request Studio secrets.',
  ]
    .filter(Boolean)
    .join('\n');
}

function prepareBuilderStateForRouter(state: WorldState): {
  routerState: WorldState;
  usedNvidiaCoderOverride: boolean;
} {
  const pool = hydrateKeyPool(state.secrets, Array.isArray(state.secrets.keyPool));
  const preferred = state.secrets.preferredBrain ?? 'auto';
  const hasEnabledNvidia = pool.some(
    (entry) => entry.enabled && entry.provider === 'nvidia' && entry.apiKey.trim().length > 0
  );

  // Prefer qwen/qwen3-coder-480b-a35b-instruct when NVIDIA is selected (or preferred)
  if (!hasEnabledNvidia || (preferred !== 'nvidia' && preferred !== 'auto')) {
    return { routerState: state, usedNvidiaCoderOverride: false };
  }

  let overridden = false;
  const nextPool = pool.map((entry) => {
    if (entry.enabled && entry.provider === 'nvidia' && entry.apiKey.trim()) {
      if (entry.model?.trim() !== NVIDIA_CODER_MODEL) {
        overridden = true;
      }
      return {
        ...entry,
        model: NVIDIA_CODER_MODEL,
      };
    }
    return entry;
  });

  if (!overridden) {
    return { routerState: state, usedNvidiaCoderOverride: false };
  }

  return {
    routerState: {
      ...state,
      secrets: {
        ...state.secrets,
        keyPool: nextPool,
        nvidiaModel: NVIDIA_CODER_MODEL,
      },
    },
    usedNvidiaCoderOverride: true,
  };
}

function parseBuilderJson(rawText: string): ParsedBuilderPayload | null {
  const trimmed = rawText.trim();
  if (!trimmed) return null;

  const fenceMatch = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const candidate = fenceMatch ? fenceMatch[1].trim() : trimmed;

  const tryParse = (input: string): ParsedBuilderPayload | null => {
    try {
      const parsed: unknown = JSON.parse(input);
      if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
        return null;
      }
      const obj = parsed as Record<string, unknown>;
      const rawFiles = Array.isArray(obj.updatedFiles)
        ? obj.updatedFiles
        : Array.isArray(obj.files)
          ? obj.files
          : null;
      if (!rawFiles) return null;

      const updatedFiles: BuilderUpdatedFile[] = [];
      for (const entry of rawFiles) {
        if (!entry || typeof entry !== 'object') continue;
        const rec = entry as Record<string, unknown>;
        const rawPath = typeof rec.path === 'string' ? rec.path : '';
        const cleanPath = sanitizeFilePath(rawPath);
        const content = typeof rec.content === 'string' ? rec.content : null;
        if (!cleanPath || content === null) continue;
        const lang = inferLanguage(
          cleanPath,
          typeof rec.language === 'string' ? rec.language : undefined
        );
        updatedFiles.push({
          path: cleanPath,
          content: sanitizeWebViewHtml(cleanPath, content),
          language: lang,
        });
      }

      if (updatedFiles.length === 0) return null;

      const summary =
        typeof obj.summary === 'string' && obj.summary.trim()
          ? obj.summary.trim()
          : `Built ${updatedFiles.length} file${updatedFiles.length === 1 ? '' : 's'}.`;

      return { summary, updatedFiles };
    } catch {
      return null;
    }
  };

  const direct = tryParse(candidate);
  if (direct) return direct;

  const firstBrace = candidate.indexOf('{');
  const lastBrace = candidate.lastIndexOf('}');
  if (firstBrace !== -1 && lastBrace > firstBrace) {
    return tryParse(candidate.slice(firstBrace, lastBrace + 1));
  }

  return null;
}

function mergeUpdatedFiles(
  existingFiles: VirtualFile[],
  updatedFiles: BuilderUpdatedFile[],
  now: number
): VirtualFile[] {
  const next = existingFiles.map((f) => ({ ...f }));

  for (const patch of updatedFiles) {
    const idx = next.findIndex(
      (f) => f.path.toLowerCase() === patch.path.toLowerCase()
    );
    const nextRecord: VirtualFile = {
      path: patch.path,
      content: patch.content,
      language: patch.language,
      updatedAt: now,
      generatedBy: 'code',
    };
    if (idx >= 0) {
      next[idx] = nextRecord;
    } else {
      // Put entry HTML near the top for convenience
      if (patch.path.toLowerCase() === 'index.html') {
        next.unshift(nextRecord);
      } else {
        next.push(nextRecord);
      }
    }
  }

  return next;
}

export async function runBuiltInStudioBuilder(
  options: RunBuiltInStudioBuilderOptions
): Promise<RunBuiltInStudioBuilderResult> {
  const startedAt = Date.now();
  const cleanPrompt = options.prompt.trim();

  if (!cleanPrompt) {
    return {
      ok: false,
      summary: 'Enter or paste a step prompt first.',
      updatedFiles: [],
      nextFiles: options.files,
      checkpoint: null,
      providerUsed: 'Local',
      durationMs: 0,
      error: 'Build prompt is empty.',
    };
  }

  let finalBotStatus: 'ready' | 'error' = 'ready';
  let finalBotProgress = 100;
  let finalBotMessage = 'Studio Builder completed';

  try {
    // STEP 1: Reading files, selectedAssets, memoryRules, and Apps-only Supabase config
    options.onStageUpdate?.({
      stage: 'reading',
      label: 'Reading files',
      detail: `${options.files.length} workspace files · ${options.selectedAssets.length} kept assets`,
      progress: 18,
    });
    studioBus.emit('bot:progress', {
      botId: 'code',
      status: 'working',
      progress: 18,
      message: 'Builder: Reading files & assets...',
    });

    const memoryBlock = buildMemoryContext(options.state.memoryRules);
    const errorMemoryBlock = buildErrorMemoryPromptContext(loadErrorMemory());
    const filesContext = serializeWorkspaceFiles(options.files);
    const assetsContext = serializeSelectedAssets(options.selectedAssets);
    const appsSupabaseContext = buildAppsSupabaseContext(options.state);

    const hasRootIndex = options.files.some(
      (f) => f.path.toLowerCase() === 'index.html'
    );
    const primaryEntryHint = hasRootIndex ? 'index.html' : 'index.html';

    const systemPrompt = [
      'You are Sarfealam Auto-Studio Built-in Studio Builder — a senior zero-template multi-file agentic software & 3D game engineer.',
      options.state.language === 'hi'
        ? 'Write the JSON "summary" in concise Hindi/Hinglish and keep all code production-grade.'
        : 'Write a crisp English "summary" and clean production-grade code.',
      ...(memoryBlock ? [memoryBlock] : []),
      ...(errorMemoryBlock ? [errorMemoryBlock] : []),
      'STRICT BUILDER RULES (NEVER VIOLATE):',
      '1. ZERO FIXED TEMPLATES: Synthesize custom, rich, fully functional HTML/CSS/JS/Three.js code tailored directly to the user prompt. Never output placeholder stubs or TODOs.',
      '2. INCREMENTAL SAFE PATCHING: Preserve all working code from earlier steps. Patch existing files or create new files cleanly without deleting or breaking prior features.',
      '3. ANDROID WEBVIEW & SRCDOC SAFETY: NEVER use <script type="importmap">, NEVER use esm.sh, and NEVER rely on ES module imports across bare specifiers. For any 3D/Three.js scene, ALWAYS load classic Three.js via <script src="https://cdn.jsdelivr.net/npm/three@0.149.0/build/three.min.js"></script> inside a standard non-module <script> tag, and unlock AudioContext on first user pointer/touch gesture.',
      `4. LIVE PREVIEW COMPATIBILITY: Keep "${primaryEntryHint}" as the runnable entry HTML (responsive 360px mobile-first layout, zero horizontal overflow). Supporting .css and .js files are automatically inlined by Display A preview AND bundled when exported to .ZIP — also link them normally in HTML (<link rel="stylesheet" href="..."> / <script src="..."></script>) so the downloaded .ZIP works standalone too.`,
      '5. SECURITY ISOLATION: Use ONLY the provided Apps Supabase config if cloud backend is requested. NEVER embed or ask for Studio API keys or GitHub tokens.',
      '6. OUTPUT FORMAT: Return STRICT JSON ONLY (no markdown prose outside JSON) matching this exact schema:',
      '{"summary":"concise description of what this step built","updatedFiles":[{"path":"index.html","content":"complete file content","language":"html"}]}',
      'Always return COMPLETE file content for every file in updatedFiles (never partial diffs).',
    ].join('\n');

    const userPrompt = [
      `Project: ${options.state.projectName}`,
      `Target Engine: ${options.state.targetEngine}`,
      `Current Stage: ${options.state.currentStage}`,
      `Existing Files: [${options.files.map((f) => f.path).join(', ')}]`,
      '',
      'Selected Assets (use these real URLs when relevant):',
      assetsContext,
      '',
      'Apps Supabase Backend Config (Apps-only, isolated from Studio):',
      appsSupabaseContext,
      '',
      'Current Workspace Files:',
      filesContext,
      '',
      'USER BUILD STEP PROMPT:',
      cleanPrompt,
    ].join('\n');

    // STEP 2: Coding via aiRouter (Fuel-independent Key Pool, preferring NVIDIA Qwen3 Coder 480B when NVIDIA is active)
    const { routerState, usedNvidiaCoderOverride } = prepareBuilderStateForRouter(
      options.state
    );

    options.onStageUpdate?.({
      stage: 'coding',
      label: 'Writing code',
      detail: usedNvidiaCoderOverride
        ? `Synthesizing multi-file build (${NVIDIA_CODER_MODEL})...`
        : 'Synthesizing custom multi-file code via active Key Pool...',
      progress: 52,
    });
    studioBus.emit('bot:progress', {
      botId: 'code',
      status: 'working',
      progress: 55,
      message: 'Builder: Writing multi-file code...',
    });

    let completion = await requestStudioAICompletion(
      systemPrompt,
      userPrompt,
      routerState,
      { timeoutMs: BUILDER_TIMEOUT_MS }
    );

    // If NVIDIA coder override failed (e.g. model unavailable on key), retry cleanly with user's configured model/pool
    if (!completion.ok && usedNvidiaCoderOverride) {
      options.onStageUpdate?.({
        stage: 'coding',
        label: 'Writing code',
        detail: 'Switching to fallback Key Pool model...',
        progress: 64,
      });
      completion = await requestStudioAICompletion(
        systemPrompt,
        userPrompt,
        options.state,
        { timeoutMs: BUILDER_TIMEOUT_MS }
      );
    }

    if (!completion.ok) {
      throw new Error(
        completion.error ||
          'No healthy AI provider key available. Add or check a key in Secrets.'
      );
    }

    const parsed = parseBuilderJson(completion.rawText);
    if (!parsed) {
      throw new Error(
        'Builder AI returned an unexpected response format instead of JSON updatedFiles. Please retry or switch Brain.'
      );
    }

    // STEP 3: Staging pre-build checkpoint, merging files, and expanding Display A live preview
    options.onStageUpdate?.({
      stage: 'staging',
      label: 'Staging checkpoint & preview',
      detail: `Saving pre-build checkpoint & merging ${parsed.updatedFiles.length} file${parsed.updatedFiles.length === 1 ? '' : 's'}...`,
      progress: 88,
    });
    studioBus.emit('bot:progress', {
      botId: 'code',
      status: 'working',
      progress: 88,
      message: `Builder: Staging ${parsed.updatedFiles.length} files...`,
    });

    const now = Date.now();
    const checkpoint: BuilderCheckpoint = {
      id: `cp-${now}-${Math.random().toString(36).slice(2, 6)}`,
      label: buildCheckpointLabel(cleanPrompt),
      files: options.files.map((f) => ({ ...f })),
      createdAt: now,
    };

    const nextFiles = mergeUpdatedFiles(options.files, parsed.updatedFiles, now);

    // Switch Display A to expanded live preview via studioBus
    studioBus.emit('world:update', {
      patch: {
        files: nextFiles,
        displayMode: 'expanded',
      },
      source: 'studio-builder',
    });

    finalBotStatus = 'ready';
    finalBotProgress = 100;
    finalBotMessage = `Built ${parsed.updatedFiles.length} file${parsed.updatedFiles.length === 1 ? '' : 's'} (${completion.providerUsed})`;

    options.onStageUpdate?.({
      stage: 'done',
      label: 'Build complete',
      detail: `${parsed.updatedFiles.length} file${parsed.updatedFiles.length === 1 ? '' : 's'} updated · ${completion.providerUsed}`,
      progress: 100,
    });

    return {
      ok: true,
      summary: parsed.summary,
      updatedFiles: parsed.updatedFiles,
      nextFiles,
      checkpoint,
      providerUsed: completion.providerUsed,
      durationMs: Date.now() - startedAt,
    };
  } catch (err) {
    const message =
      err instanceof Error ? err.message : 'Built-in Studio Builder failed.';
    finalBotStatus = 'error';
    finalBotProgress = 0;
    finalBotMessage = message;

    options.onStageUpdate?.({
      stage: 'error',
      label: 'Build failed',
      detail: message,
      progress: 0,
    });

    return {
      ok: false,
      summary: message,
      updatedFiles: [],
      nextFiles: options.files,
      checkpoint: null,
      providerUsed: 'Local',
      durationMs: Date.now() - startedAt,
      error: message,
    };
  } finally {
    studioBus.emit('bot:progress', {
      botId: 'code',
      status: finalBotStatus,
      progress: finalBotProgress,
      message: finalBotMessage,
    });
  }
}
