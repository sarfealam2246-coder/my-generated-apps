export interface PreviewTelemetryMessage {
  source: 'sarfealam-preview';
  type: 'error' | 'ok';
  message: string;
}

export function isPreviewTelemetryMessage(
  data: unknown
): data is PreviewTelemetryMessage {
  if (!data || typeof data !== 'object') return false;
  const rec = data as Record<string, unknown>;
  return (
    rec.source === 'sarfealam-preview' &&
    (rec.type === 'error' || rec.type === 'ok') &&
    typeof rec.message === 'string'
  );
}

const SPY_SCRIPT_TAG = `<script data-sarfealam-spy="1">
(function () {
  if (window.__SARFEALAM_PREVIEW_SPY__) return;
  window.__SARFEALAM_PREVIEW_SPY__ = true;

  var reportedError = false;

  function formatPart(val) {
    if (val instanceof Error) {
      return val.message || String(val);
    }
    if (typeof val === 'string') return val;
    if (val === null || val === undefined) return String(val);
    try {
      return JSON.stringify(val);
    } catch (_) {
      return String(val);
    }
  }

  function postStatus(type, message) {
    try {
      var clean = String(message || '').replace(/\\s+/g, ' ').trim().slice(0, 360);
      if (type === 'error') {
        reportedError = true;
      }
      window.parent.postMessage(
        {
          source: 'sarfealam-preview',
          type: type,
          message: clean || (type === 'error' ? 'Runtime error in preview' : 'Preview rendered'),
        },
        '*'
      );
    } catch (_) {
      // Ignore postMessage failures
    }
  }

  var prevOnError = window.onerror;
  window.onerror = function (message, source, lineno, colno, error) {
    var loc = lineno ? ' (line ' + lineno + (colno ? ':' + colno : '') + ')' : '';
    var detail = (error && error.message) ? error.message : String(message || 'Script error');
    postStatus('error', detail + loc);
    if (typeof prevOnError === 'function') {
      try {
        return prevOnError.apply(this, arguments);
      } catch (_) {}
    }
    return false;
  };

  window.addEventListener('error', function (evt) {
    if (!evt) return;
    if (evt.target && evt.target !== window && evt.target.tagName) {
      var tag = String(evt.target.tagName).toLowerCase();
      if (tag === 'script') {
        var src = evt.target.src || 'script';
        postStatus('error', 'Failed to load script: ' + src);
      }
      return;
    }
    if (evt.message) {
      var loc = evt.lineno ? ' (line ' + evt.lineno + ')' : '';
      postStatus('error', evt.message + loc);
    }
  }, true);

  window.addEventListener('unhandledrejection', function (evt) {
    var reason = evt && 'reason' in evt ? formatPart(evt.reason) : 'Unhandled promise rejection';
    postStatus('error', 'Unhandled rejection: ' + reason);
  });

  if (typeof console !== 'undefined' && typeof console.error === 'function') {
    var origConsoleError = console.error;
    console.error = function () {
      try {
        var parts = [];
        for (var i = 0; i < arguments.length; i++) {
          parts.push(formatPart(arguments[i]));
        }
        var joined = parts.join(' ').trim();
        if (joined) {
          postStatus('error', joined);
        }
      } catch (_) {}
      return origConsoleError.apply(console, arguments);
    };
  }

  function runPostLoadHealthCheck() {
    if (reportedError) return;
    try {
      var body = document.body;
      if (!body) {
        postStatus('error', 'Blank preview: document.body is missing.');
        return;
      }

      var canvases = body.querySelectorAll('canvas');
      var hasHealthyCanvas = false;
      var hasZeroCanvas = false;
      for (var i = 0; i < canvases.length; i++) {
        var cv = canvases[i];
        var rect = cv.getBoundingClientRect ? cv.getBoundingClientRect() : { width: cv.width, height: cv.height };
        if (cv.width > 0 && cv.height > 0 && rect.width > 0 && rect.height > 0) {
          hasHealthyCanvas = true;
        } else {
          hasZeroCanvas = true;
        }
      }

      if (canvases.length > 0 && !hasHealthyCanvas && hasZeroCanvas) {
        postStatus('error', 'Blank 3D/Canvas preview: zero-sized canvas detected.');
        return;
      }

      var text = (body.innerText || '').trim();
      var mediaNodes = body.querySelectorAll('svg, img, video, iframe, button, input');
      var hasVisibleElement = false;
      var children = body.children || [];
      for (var c = 0; c < children.length; c++) {
        var el = children[c];
        var tagName = (el.tagName || '').toLowerCase();
        if (tagName === 'script' || tagName === 'style') continue;
        var r = el.getBoundingClientRect ? el.getBoundingClientRect() : { width: 0, height: 0 };
        if (r.width > 0 && r.height > 0) {
          hasVisibleElement = true;
          break;
        }
      }

      if (!hasHealthyCanvas && !text && mediaNodes.length === 0 && !hasVisibleElement) {
        postStatus('error', 'Blank preview: empty body 1.5s after load.');
        return;
      }

      postStatus('ok', hasHealthyCanvas ? 'Canvas & preview active' : 'Preview rendered');
    } catch (err) {
      postStatus('error', formatPart(err));
    }
  }

  function scheduleCheck() {
    window.setTimeout(runPostLoadHealthCheck, 1500);
  }

  if (document.readyState === 'complete') {
    scheduleCheck();
  } else {
    window.addEventListener('load', scheduleCheck, { once: true });
  }
})();
</script>`;

export function injectPreviewErrorSpy(html: string): string {
  if (!html) return SPY_SCRIPT_TAG;
  if (html.includes('data-sarfealam-spy="1"')) return html;

  if (/<head[^>]*>/i.test(html)) {
    return html.replace(/<head[^>]*>/i, (match) => `${match}\n${SPY_SCRIPT_TAG}`);
  }
  if (/<\/head>/i.test(html)) {
    return html.replace(/<\/head>/i, `${SPY_SCRIPT_TAG}\n</head>`);
  }
  if (/<body[^>]*>/i.test(html)) {
    return html.replace(/<body[^>]*>/i, (match) => `${SPY_SCRIPT_TAG}\n${match}`);
  }
  return `${SPY_SCRIPT_TAG}\n${html}`;
}
