import { requestStudioAICompletion } from './aiRouter';
import { studioBus } from './eventBus';
import { parseGitHubRepoInput } from './githubCloneService';
import { patchActiveJob } from './jobPersistenceService';
import { buildMemoryContext } from './memoryService';
import type { StudioSecrets, VirtualFile, WorldState } from '../types/studio';

export const ERROR_MEMORY_STORAGE_KEY = 'sarfealam_error_memory_v2';

const GITHUB_POLL_TIMEOUT_MS = 10_000;
const SUPABASE_TIMEOUT_MS = 5_000;
const MAX_ERROR_MEMORY_ENTRIES = 30;

export interface ErrorMemoryEntry {
  id: string;
  repo: string;
  runId: number;
  workflowName: string;
  failureSignature: string;
  summary: string;
  patchApplied: string;
  createdAt: number;
}

export interface CheckAndHealGitHubRunOptions {
  targetRepo: string;
  githubPat?: string;
  files: VirtualFile[];
  state: WorldState;
}

export type SelfHealStatus =
  | 'no_runs'
  | 'in_progress'
  | 'success'
  | 'healed'
  | 'failure'
  | 'error';

export interface CheckAndHealGitHubRunResult {
  status: SelfHealStatus;
  healedFiles: VirtualFile[];
  changedPaths: string[];
  summary: string;
  runId: number | null;
  htmlUrl?: string;
  providerUsed?: string;
  errorMemoryEntry?: ErrorMemoryEntry;
  supabaseSynced?: boolean;
}

interface GitHubActionRun {
  id?: number;
  name?: string;
  status?: string;
  conclusion?: string | null;
  html_url?: string;
  head_sha?: string;
  run_number?: number;
}

interface GitHubActionJob {
  name?: string;
  conclusion?: string | null;
  steps?: {
    name?: string;
    conclusion?: string | null;
    number?: number;
  }[];
}

function makeErrorMemoryId(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return `err-${crypto.randomUUID()}`;
  }
  return `err-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

async function fetchWithTimeout(
  url: string,
  init: RequestInit,
  timeoutMs: number
): Promise<Response> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...init, signal: controller.signal });
  } finally {
    window.clearTimeout(timer);
  }
}

export function loadErrorMemory(): ErrorMemoryEntry[] {
  try {
    const raw = window.localStorage.getItem(ERROR_MEMORY_STORAGE_KEY);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter(
        (item): item is ErrorMemoryEntry =>
          Boolean(item) &&
          typeof item === 'object' &&
          typeof (item as ErrorMemoryEntry).failureSignature === 'string'
      )
      .slice(0, MAX_ERROR_MEMORY_ENTRIES);
  } catch {
    return [];
  }
}

export function saveErrorMemory(entries: ErrorMemoryEntry[]): ErrorMemoryEntry[] {
  const trimmed = entries.slice(0, MAX_ERROR_MEMORY_ENTRIES);
  try {
    window.localStorage.setItem(
      ERROR_MEMORY_STORAGE_KEY,
      JSON.stringify(trimmed)
    );
  } catch {
    // Ignore storage quota errors gracefully
  }
  return trimmed;
}

export function buildErrorMemoryPromptContext(entries: ErrorMemoryEntry[]): string {
  if (entries.length === 0) return '';
  const lines = entries
    .slice(0, 8)
    .map(
      (e, idx) =>
        `${idx + 1}. [${e.workflowName}] ${e.failureSignature} -> ${e.patchApplied || e.summary}`
    );
  return [
    'PAST ERROR_MEMORY (DO NOT REPEAT THESE BROKEN BUILD PATTERNS):',
    ...lines,
  ].join('\n');
}

export function recordPreviewErrorMemory(options: {
  projectName: string;
  errorMessage: string;
  fixSummary?: string;
}): ErrorMemoryEntry {
  const existing = loadErrorMemory();
  const cleanSig = options.errorMessage.trim().slice(0, 220) || 'Display A runtime error';
  const cleanFix = options.fixSummary?.trim().slice(0, 240) || 'Avoid repeating this preview runtime/WebGL failure';

  const entry: ErrorMemoryEntry = {
    id: makeErrorMemoryId(),
    repo: options.projectName.trim() || 'Display A Local',
    runId: 0,
    workflowName: 'Display A Preview',
    failureSignature: cleanSig,
    summary: `Preview Self-Heal captured: ${cleanSig}`,
    patchApplied: cleanFix,
    createdAt: Date.now(),
  };

  const deduped = existing.filter(
    (e) =>
      !(
        e.workflowName === 'Display A Preview' &&
        e.failureSignature.toLowerCase() === cleanSig.toLowerCase()
      )
  );
  saveErrorMemory([entry, ...deduped]);
  return entry;
}

async function syncErrorMemoryToStudioSupabase(
  secrets: StudioSecrets,
  entry: ErrorMemoryEntry
): Promise<boolean> {
  // STRICT ISOLATION: Studio Supabase ONLY — NEVER touch appsSupabaseUrl
  const rawUrl = secrets.studioSupabaseUrl?.trim() ?? '';
  const anonKey = secrets.studioSupabaseAnonKey?.trim() ?? '';
  if (!rawUrl || !anonKey) return false;

  let baseUrl = '';
  try {
    const parsed = new URL(rawUrl);
    if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
      return false;
    }
    baseUrl = parsed.origin + parsed.pathname.replace(/\/+$/, '');
  } catch {
    return false;
  }

  try {
    const res = await fetchWithTimeout(
      `${baseUrl}/rest/v1/error_memory`,
      {
        method: 'POST',
        headers: {
          apikey: anonKey,
          Authorization: `Bearer ${anonKey}`,
          'Content-Type': 'application/json',
          Prefer: 'return=minimal',
        },
        body: JSON.stringify({
          repo: entry.repo,
          run_id: entry.runId,
          workflow_name: entry.workflowName,
          failure_signature: entry.failureSignature,
          summary: entry.summary,
          patch_applied: entry.patchApplied,
        }),
      },
      SUPABASE_TIMEOUT_MS
    );
    return res.ok;
  } catch {
    return false;
  }
}

function inferLanguage(path: string, fallback?: string): string {
  if (fallback && fallback.trim()) return fallback.trim().toLowerCase();
  const ext = path.split('.').pop()?.toLowerCase() ?? '';
  if (ext === 'yml' || ext === 'yaml') return 'yaml';
  if (ext === 'json') return 'json';
  if (ext === 'html' || ext === 'htm') return 'html';
  if (ext === 'css') return 'css';
  if (ext === 'tsx' || ext === 'ts') return ext;
  if (ext === 'jsx' || ext === 'js') return ext;
  return 'text';
}

function parseHealPatchJson(
  rawText: string
): { summary: string; updatedFiles: { path: string; content: string; language?: string }[] } | null {
  const trimmed = rawText.trim();
  if (!trimmed) return null;

  const fenceMatch = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const candidate = fenceMatch ? fenceMatch[1].trim() : trimmed;

  const tryParse = (str: string) => {
    try {
      const parsed: unknown = JSON.parse(str);
      if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
        return null;
      }
      const obj = parsed as Record<string, unknown>;
      if (!Array.isArray(obj.updatedFiles)) return null;

      const updatedFiles: { path: string; content: string; language?: string }[] =
        [];
      for (const item of obj.updatedFiles) {
        if (!item || typeof item !== 'object') continue;
        const rec = item as Record<string, unknown>;
        const path =
          typeof rec.path === 'string'
            ? rec.path.trim().replace(/^\/+/, '')
            : '';
        const content = typeof rec.content === 'string' ? rec.content : null;
        if (!path || content === null) continue;
        updatedFiles.push({
          path,
          content,
          language:
            typeof rec.language === 'string' ? rec.language.trim() : undefined,
        });
      }

      if (updatedFiles.length === 0) return null;

      const summary =
        typeof obj.summary === 'string' && obj.summary.trim()
          ? obj.summary.trim()
          : `Patched ${updatedFiles.length} file${updatedFiles.length === 1 ? '' : 's'} to fix GitHub Actions failure.`;

      return { summary, updatedFiles };
    } catch {
      return null;
    }
  };

  const direct = tryParse(candidate);
  if (direct) return direct;

  const firstBrace = candidate.indexOf('{');
  const lastBrace = candidate.lastIndexOf('}');
  if (firstBrace !== -1 && lastBrace > firstBrace) {
    return tryParse(candidate.slice(firstBrace, lastBrace + 1));
  }

  return null;
}

function buildFilesSnapshotForHealer(files: VirtualFile[]): string {
  const prioritized = [...files].sort((a, b) => {
    const score = (p: string) => {
      const l = p.toLowerCase();
      if (l.includes('workflow') || l.endsWith('.yml')) return 100;
      if (l === 'package.json' || l === 'capacitor.config.json') return 90;
      if (l === 'index.html' || l === 'docs/index.html') return 80;
      if (l === 'docs/admin.html' || l === 'assets/manifest.json') return 70;
      return 50;
    };
    return score(b.path) - score(a.path);
  });

  const blocks: string[] = [];
  let chars = 0;
  for (const file of prioritized.slice(0, 7)) {
    const body =
      file.content.length > 3000
        ? `${file.content.slice(0, 3000)}\n/* ...truncated... */`
        : file.content;
    const block = `--- FILE: ${file.path} ---\n${body}`;
    if (chars + block.length > 13_000 && blocks.length > 0) break;
    blocks.push(block);
    chars += block.length;
  }
  return blocks.join('\n\n');
}

/**
 * Polls `/repos/${owner}/${repo}/actions/runs?per_page=1` (10s timeout).
 * When a workflow fails (`conclusion === 'failure'`), logs the failure pattern
 * into `localStorage` (`sarfealam_error_memory_v2`) AND Studio-only Supabase
 * `/rest/v1/error_memory` (NEVER `appsSupabaseUrl`), then asks `aiRouter` to patch
 * broken virtual files while avoiding past `error_memory` mistakes.
 */
export async function checkAndHealGitHubRun(
  options: CheckAndHealGitHubRunOptions
): Promise<CheckAndHealGitHubRunResult> {
  const parsedRepo = parseGitHubRepoInput(options.targetRepo);
  if (!parsedRepo) {
    return {
      status: 'error',
      healedFiles: options.files,
      changedPaths: [],
      summary: 'Invalid GitHub target repo (expected owner/repo).',
      runId: null,
    };
  }

  const { owner, repo, normalized } = parsedRepo;
  const pat = (options.githubPat ?? options.state.secrets.githubToken ?? '').trim();
  const headers: Record<string, string> = {
    Accept: 'application/vnd.github+json',
    'X-GitHub-Api-Version': '2022-11-28',
  };
  if (pat) {
    headers.Authorization = `Bearer ${pat}`;
  }

  const apiBase = `https://api.github.com/repos/${encodeURIComponent(
    owner
  )}/${encodeURIComponent(repo)}`;

  studioBus.emit('bot:progress', {
    botId: 'github',
    status: 'working',
    progress: 25,
    message: `Polling Actions run for ${normalized}...`,
  });

  try {
    const runsRes = await fetchWithTimeout(
      `${apiBase}/actions/runs?per_page=1`,
      { method: 'GET', headers },
      GITHUB_POLL_TIMEOUT_MS
    );

    if (!runsRes.ok) {
      throw new Error(
        runsRes.status === 404
          ? `Repository ${normalized} not found or token lacks Actions read permission.`
          : `GitHub Actions API returned HTTP ${runsRes.status}.`
      );
    }

    const runsJson = (await runsRes.json()) as {
      workflow_runs?: GitHubActionRun[];
    };
    const latestRun = Array.isArray(runsJson.workflow_runs)
      ? runsJson.workflow_runs[0]
      : undefined;

    if (!latestRun || typeof latestRun.id !== 'number') {
      studioBus.emit('bot:progress', {
        botId: 'github',
        status: 'ready',
        progress: 100,
        message: 'No Actions runs found yet',
      });
      return {
        status: 'no_runs',
        healedFiles: options.files,
        changedPaths: [],
        summary: `No GitHub Actions runs found yet for ${normalized}.`,
        runId: null,
      };
    }

    const runId = latestRun.id;
    const workflowName = latestRun.name?.trim() || 'Build APK Workflow';
    const htmlUrl = latestRun.html_url || `https://github.com/${normalized}/actions/runs/${runId}`;

    // Still queued / in progress
    if (latestRun.status !== 'completed') {
      patchActiveJob({
        status: 'polling',
        runId,
        targetRepo: normalized,
      });
      studioBus.emit('bot:progress', {
        botId: 'github',
        status: 'working',
        progress: 65,
        message: `Run #${latestRun.run_number ?? runId} ${latestRun.status || 'running'}...`,
      });
      return {
        status: 'in_progress',
        healedFiles: options.files,
        changedPaths: [],
        summary: `Workflow "${workflowName}" (Run #${latestRun.run_number ?? runId}) is currently ${latestRun.status || 'in_progress'}.`,
        runId,
        htmlUrl,
      };
    }

    // Completed with success
    if (latestRun.conclusion === 'success') {
      patchActiveJob({
        status: 'completed',
        runId,
        targetRepo: normalized,
      });
      studioBus.emit('bot:progress', {
        botId: 'github',
        status: 'ready',
        progress: 100,
        message: `Actions Run #${latestRun.run_number ?? runId} passed`,
      });
      return {
        status: 'success',
        healedFiles: options.files,
        changedPaths: [],
        summary: `Workflow "${workflowName}" (Run #${latestRun.run_number ?? runId}) succeeded! APK and Pages are ready.`,
        runId,
        htmlUrl,
      };
    }

    // Completed with failure -> inspect jobs, log to error_memory, ask aiRouter to heal
    if (latestRun.conclusion === 'failure') {
      patchActiveJob({
        status: 'healing',
        runId,
        targetRepo: normalized,
      });

      studioBus.emit('bot:progress', {
        botId: 'github',
        status: 'working',
        progress: 50,
        message: `Run #${latestRun.run_number ?? runId} failed — diagnosing & self-healing...`,
      });

      let failedStepsDesc = `Workflow "${workflowName}" failed (Run #${latestRun.run_number ?? runId}).`;
      try {
        const jobsRes = await fetchWithTimeout(
          `${apiBase}/actions/runs/${runId}/jobs`,
          { method: 'GET', headers },
          GITHUB_POLL_TIMEOUT_MS
        );
        if (jobsRes.ok) {
          const jobsJson = (await jobsRes.json()) as { jobs?: GitHubActionJob[] };
          const failedDetails: string[] = [];
          for (const job of jobsJson.jobs ?? []) {
            if (job.conclusion === 'failure') {
              const badSteps = (job.steps ?? [])
                .filter((s) => s.conclusion === 'failure')
                .map((s) => s.name || `step-${s.number ?? '?'}`);
              failedDetails.push(
                `${job.name || 'job'} [${badSteps.join(', ') || 'failed'}]`
              );
            }
          }
          if (failedDetails.length > 0) {
            failedStepsDesc = `Failed jobs: ${failedDetails.join(' | ')}`;
          }
        }
      } catch {
        // Proceed with run-level failure signature even if jobs detail call fails
      }

      const existingMemory = loadErrorMemory();
      const errorMemoryBlock = buildErrorMemoryPromptContext(existingMemory);
      const userMemoryBlock = buildMemoryContext(options.state.memoryRules);

      const systemPrompt = [
        'You are Sarfealam Auto-Studio Self-Healing CI/CD Engineer.',
        'A GitHub Actions APK/Pages workflow run failed. Analyze the failed step and workspace files, then return minimal, production-safe file patches.',
        ...(userMemoryBlock ? [userMemoryBlock] : []),
        ...(errorMemoryBlock ? [errorMemoryBlock] : []),
        'Return STRICT JSON ONLY (no markdown fences):',
        '{"summary":"concise root cause and fix","updatedFiles":[{"path":"exact/file/path","content":"full patched file content","language":"yaml|json|html|ts|js"}]}',
      ].join('\n');

      const userPrompt = [
        `Repository: ${normalized}`,
        `Failed Run ID: ${runId}`,
        `Workflow: ${workflowName}`,
        `Failure Details: ${failedStepsDesc}`,
        '',
        'Current Virtual Workspace Files:',
        buildFilesSnapshotForHealer(options.files),
      ].join('\n');

      const completion = await requestStudioAICompletion(
        systemPrompt,
        userPrompt,
        options.state
      );

      let healedFiles = options.files;
      let changedPaths: string[] = [];
      let healSummary = `Logged CI failure (${failedStepsDesc}).`;
      let status: SelfHealStatus = 'failure';

      if (completion.ok) {
        const parsedPatch = parseHealPatchJson(completion.rawText);
        if (parsedPatch) {
          const now = Date.now();
          const map = new Map<string, VirtualFile>();
          for (const f of options.files) {
            map.set(f.path, { ...f });
          }
          for (const patch of parsedPatch.updatedFiles) {
            const existing = map.get(patch.path);
            map.set(patch.path, {
              path: patch.path,
              content: patch.content,
              language: inferLanguage(
                patch.path,
                patch.language ?? existing?.language
              ),
              updatedAt: now,
              generatedBy: 'github',
            });
            changedPaths.push(patch.path);
          }
          healedFiles = Array.from(map.values());
          healSummary = parsedPatch.summary;
          status = 'healed';
        } else {
          healSummary = `Logged CI failure (${failedStepsDesc}). AI response did not include structured file patches.`;
        }
      } else {
        healSummary = `Logged CI failure (${failedStepsDesc}). ${completion.error || 'Configure an AI API key in Secrets for automatic patching.'}`;
      }

      const entry: ErrorMemoryEntry = {
        id: makeErrorMemoryId(),
        repo: normalized,
        runId,
        workflowName,
        failureSignature: failedStepsDesc.slice(0, 220),
        summary: healSummary.slice(0, 280),
        patchApplied:
          changedPaths.length > 0 ? changedPaths.join(', ') : 'none',
        createdAt: Date.now(),
      };

      saveErrorMemory([entry, ...existingMemory]);
      const supabaseSynced = await syncErrorMemoryToStudioSupabase(
        options.state.secrets,
        entry
      );

      studioBus.emit('bot:progress', {
        botId: 'github',
        status: status === 'healed' ? 'ready' : 'error',
        progress: status === 'healed' ? 100 : 0,
        message:
          status === 'healed'
            ? `Self-healed ${changedPaths.length} file${changedPaths.length === 1 ? '' : 's'} via ${completion.providerUsed}`
            : `Run #${latestRun.run_number ?? runId} failed (logged to error_memory)`,
      });

      return {
        status,
        healedFiles,
        changedPaths,
        summary: healSummary,
        runId,
        htmlUrl,
        providerUsed: completion.providerUsed,
        errorMemoryEntry: entry,
        supabaseSynced,
      };
    }

    // Any other conclusion (cancelled, skipped, neutral, etc.)
    studioBus.emit('bot:progress', {
      botId: 'github',
      status: 'ready',
      progress: 100,
      message: `Run #${latestRun.run_number ?? runId}: ${latestRun.conclusion || 'completed'}`,
    });

    return {
      status: 'failure',
      healedFiles: options.files,
      changedPaths: [],
      summary: `Workflow "${workflowName}" finished with conclusion: ${latestRun.conclusion || 'unknown'}.`,
      runId,
      htmlUrl,
    };
  } catch (err) {
    const isTimeout = err instanceof DOMException && err.name === 'AbortError';
    const message = isTimeout
      ? 'GitHub Actions poll timed out after 10s.'
      : err instanceof Error
        ? err.message
        : 'Unable to check GitHub Actions run.';

    studioBus.emit('bot:progress', {
      botId: 'github',
      status: 'error',
      progress: 0,
      message,
    });

    return {
      status: 'error',
      healedFiles: options.files,
      changedPaths: [],
      summary: message,
      runId: null,
    };
  }
}
