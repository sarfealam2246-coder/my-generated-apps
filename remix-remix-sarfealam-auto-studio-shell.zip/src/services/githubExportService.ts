import { studioBus } from './eventBus';
import { parseGitHubRepoInput } from './githubCloneService';
import {
  createActiveJob,
  patchActiveJob,
} from './jobPersistenceService';
import { waitIfPaused } from './pipelineController';
import type { StudioSecrets, VirtualFile } from '../types/studio';

const GITHUB_API_TIMEOUT_MS = 10_000;

export interface OwnerAdminHtmlOptions {
  appName: string;
  version?: string;
  ownerPin: string;
  appsSupabaseUrl?: string;
  appsSupabaseAnonKey?: string;
}

export interface AtomicPushToGitHubOptions {
  files: VirtualFile[];
  appName: string;
  version?: string;
  ownerPin: string;
  secrets: StudioSecrets;
  branch?: string;
  commitMessage?: string;
  signal?: AbortSignal;
}

export interface AtomicPushToGitHubResult {
  ok: boolean;
  commitSha: string;
  repo: string;
  branch: string;
  pagesUrl: string;
  adminUrl: string;
  actionsUrl: string;
  apkReleaseUrl: string;
  filesPushed: number;
  generatedAdminFile?: VirtualFile;
  workflowFile?: VirtualFile;
  error?: string;
}

function escapeHtml(raw: string): string {
  return raw
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function sanitizeJsonForScriptTag(value: unknown): string {
  return JSON.stringify(value).replace(/</g, '\\u003c');
}

function computeDeterministicPinDigest(pin: string): string {
  // Lightweight salted FNV-1a double-hash digest so raw PIN is not compared as a bare string
  const salted = `sarfealam-owner-v1::${pin.trim()}`;
  let h1 = 0x811c9dc5;
  let h2 = 0x9e3779b9;
  for (let i = 0; i < salted.length; i++) {
    const code = salted.charCodeAt(i);
    h1 ^= code;
    h1 = Math.imul(h1, 0x01000193);
    h2 ^= code + ((i + 1) * 31);
    h2 = Math.imul(h2, 0x85ebca6b);
  }
  return `${(h1 >>> 0).toString(16).padStart(8, '0')}${(h2 >>> 0)
    .toString(16)
    .padStart(8, '0')}`;
}

function slugifyPackageName(appName: string): string {
  const cleaned = appName
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '')
    .slice(0, 24);
  return cleaned || 'studioapp';
}

function normalizeSafeSupabaseUrl(raw?: string): string {
  const trimmed = (raw ?? '').trim();
  if (!trimmed) return '';
  try {
    const parsed = new URL(trimmed);
    if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
      return '';
    }
    return parsed.origin + parsed.pathname.replace(/\/+$/, '');
  } catch {
    return '';
  }
}

/**
 * Generates a standalone PIN-locked Owner Admin Web Panel (`docs/admin.html`).
 * STRICT ISOLATION: Accepts ONLY `appsSupabaseUrl` and `appsSupabaseAnonKey`
 * — NEVER receives or embeds Studio Supabase credentials, GitHub PAT, or AI API keys.
 */
export function generateOwnerAdminHtml(options: OwnerAdminHtmlOptions): string {
  const safeAppName = options.appName.trim() || 'Sarfealam App';
  const safeVersion = (options.version || '1.0.0').trim();
  const safePin = (options.ownerPin || '2026').trim();
  const pinDigest = computeDeterministicPinDigest(safePin);

  // STRICT ISOLATION: Apps Supabase ONLY
  const appsSupabaseUrl = normalizeSafeSupabaseUrl(options.appsSupabaseUrl);
  const appsSupabaseAnonKey = (options.appsSupabaseAnonKey ?? '').trim();

  const runtimeConfig = {
    appName: safeAppName,
    version: safeVersion,
    pinDigest,
    appsSupabaseUrl,
    appsSupabaseAnonKey,
    generatedAt: new Date().toISOString(),
  };

  return `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, maximum-scale=1.0, viewport-fit=cover"
    />
    <title>${escapeHtml(safeAppName)} · Owner Admin</title>
    <style>
      :root {
        --bg: #f3f6fb;
        --glass: rgba(255, 255, 255, 0.88);
        --border: rgba(148, 163, 184, 0.28);
        --ink: #0f172a;
        --muted: #64748b;
        --blue: #007aff;
        --indigo: #5856d6;
        --green: #10b981;
        --amber: #f59e0b;
        --red: #ff3b30;
      }
      * { box-sizing: border-box; }
      html, body {
        margin: 0;
        padding: 0;
        min-height: 100dvh;
        width: 100%;
        max-width: 100vw;
        overflow-x: hidden;
        background:
          radial-gradient(circle at 12% 10%, rgba(0, 122, 255, 0.14), transparent 44%),
          radial-gradient(circle at 88% 12%, rgba(88, 86, 214, 0.14), transparent 42%),
          var(--bg);
        color: var(--ink);
        font-family: -apple-system, BlinkMacSystemFont, "Plus Jakarta Sans", "Segoe UI", sans-serif;
      }
      .wrap {
        max-width: 480px;
        margin: 0 auto;
        padding: 16px 12px 40px;
      }
      .card {
        background: var(--glass);
        backdrop-filter: blur(20px);
        -webkit-backdrop-filter: blur(20px);
        border: 1px solid var(--border);
        border-radius: 22px;
        box-shadow: 0 12px 34px rgba(15, 23, 42, 0.08);
        padding: 16px;
        margin-bottom: 12px;
      }
      .row { display: flex; align-items: center; justify-content: space-between; gap: 10px; }
      .badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        font-size: 11px;
        font-weight: 700;
        padding: 4px 10px;
        border-radius: 999px;
        background: rgba(0, 122, 255, 0.1);
        color: var(--blue);
        border: 1px solid rgba(0, 122, 255, 0.22);
      }
      .badge.ok {
        background: rgba(16, 185, 129, 0.12);
        color: #047857;
        border-color: rgba(16, 185, 129, 0.28);
      }
      .badge.warn {
        background: rgba(245, 158, 11, 0.14);
        color: #b45309;
        border-color: rgba(245, 158, 11, 0.3);
      }
      h1 { font-size: 18px; margin: 0; letter-spacing: -0.02em; }
      h2 { font-size: 14px; margin: 0 0 8px; }
      p { margin: 4px 0 0; font-size: 12.5px; color: var(--muted); line-height: 1.45; }
      input[type="password"], input[type="text"], select {
        width: 100%;
        height: 44px;
        border-radius: 14px;
        border: 1px solid rgba(148, 163, 184, 0.45);
        background: #fff;
        color: var(--ink);
        font-size: 14px;
        padding: 0 12px;
        outline: none;
      }
      input:focus, select:focus {
        border-color: var(--blue);
        box-shadow: 0 0 0 3px rgba(0, 122, 255, 0.14);
      }
      .btn {
        height: 42px;
        padding: 0 14px;
        border: none;
        border-radius: 14px;
        font-size: 13px;
        font-weight: 700;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        transition: transform 0.12s ease, opacity 0.15s ease;
      }
      .btn:active { transform: scale(0.97); }
      .btn-primary {
        width: 100%;
        color: #fff;
        background: linear-gradient(135deg, var(--blue), var(--indigo));
        box-shadow: 0 6px 18px rgba(0, 122, 255, 0.24);
      }
      .btn-green {
        color: #fff;
        background: linear-gradient(135deg, #10b981, #059669);
      }
      .btn-soft {
        color: var(--ink);
        background: rgba(241, 245, 249, 0.95);
        border: 1px solid rgba(148, 163, 184, 0.35);
      }
      .btn-danger {
        color: #fff;
        background: var(--red);
      }
      .grid2 { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 8px; margin-top: 10px; }
      .stat {
        background: #f8fafe;
        border: 1px solid rgba(148, 163, 184, 0.25);
        border-radius: 14px;
        padding: 10px;
      }
      .stat-label { font-size: 10.5px; color: var(--muted); font-weight: 600; }
      .stat-val { font-size: 14px; font-weight: 800; margin-top: 2px; word-break: break-word; }
      .toggle-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 10px 12px;
        border-radius: 14px;
        background: #f8fafe;
        border: 1px solid rgba(148, 163, 184, 0.25);
        margin-top: 8px;
      }
      .err {
        margin-top: 8px;
        padding: 8px 10px;
        border-radius: 12px;
        font-size: 12px;
        font-weight: 600;
        color: #b91c1c;
        background: rgba(255, 59, 48, 0.1);
        display: none;
      }
      pre {
        margin: 8px 0 0;
        padding: 10px;
        border-radius: 12px;
        background: #0f172a;
        color: #e2e8f0;
        font-size: 11px;
        max-height: 180px;
        overflow: auto;
        white-space: pre-wrap;
        word-break: break-word;
      }
      .hidden { display: none !important; }
    </style>
  </head>
  <body>
    <main class="wrap">
      <section class="card">
        <div class="row">
          <div>
            <h1>${escapeHtml(safeAppName)}</h1>
            <p>Owner Admin Web Panel · v${escapeHtml(safeVersion)}</p>
          </div>
          <span id="lock-badge" class="badge warn">PIN Locked</span>
        </div>
      </section>

      <section id="pin-gate" class="card">
        <h2>Owner PIN Verification</h2>
        <p>Enter your Owner PIN to unlock live app controls and Apps Supabase inspection.</p>
        <form id="pin-form" style="margin-top: 12px; display: flex; flex-direction: column; gap: 10px;">
          <input
            id="pin-input"
            type="password"
            inputmode="numeric"
            autocomplete="one-time-code"
            placeholder="Enter Owner PIN"
            required
          />
          <button type="submit" class="btn btn-primary">Unlock Owner Panel</button>
        </form>
        <div id="pin-error" class="err">Incorrect Owner PIN. Please try again.</div>
      </section>

      <div id="owner-dashboard" class="hidden">
        <section class="card">
          <div class="row">
            <h2>Live App Telemetry</h2>
            <button id="lock-btn" type="button" class="btn btn-danger" style="height: 32px; font-size: 11.5px;">Lock</button>
          </div>
          <div class="grid2">
            <div class="stat">
              <div class="stat-label">App Version</div>
              <div class="stat-val">v${escapeHtml(safeVersion)}</div>
            </div>
            <div class="stat">
              <div class="stat-label">Apps Supabase</div>
              <div id="supa-status" class="stat-val">Checking...</div>
            </div>
          </div>

          <div class="toggle-row">
            <div>
              <strong style="font-size: 12.5px;">Maintenance Mode</strong>
              <p style="margin: 0; font-size: 11px;">Pause public writes during hotfixes</p>
            </div>
            <input id="toggle-maintenance" type="checkbox" style="width: 20px; height: 20px;" />
          </div>

          <div class="toggle-row">
            <div>
              <strong style="font-size: 12.5px;">Push Broadcast Banner</strong>
              <p style="margin: 0; font-size: 11px;">Toggle promotional notice inside app</p>
            </div>
            <input id="toggle-banner" type="checkbox" style="width: 20px; height: 20px;" />
          </div>

          <div style="margin-top: 10px; display: flex; gap: 8px;">
            <button id="save-flags-btn" type="button" class="btn btn-green" style="flex: 1;">Save Flags</button>
            <a href="./index.html" class="btn btn-soft" style="text-decoration: none;">Open App</a>
          </div>
          <p id="flags-msg" style="margin-top: 8px; font-weight: 600;"></p>
        </section>

        <section class="card">
          <h2>Apps Supabase Live Inspector</h2>
          <p>Strictly isolated to your App Supabase project only (zero Studio secrets embedded).</p>
          <div style="margin-top: 10px; display: flex; gap: 8px;">
            <input id="table-input" type="text" value="app_config" placeholder="Table name (e.g. app_config)" style="flex: 1; height: 38px; font-size: 12.5px;" />
            <button id="query-btn" type="button" class="btn btn-primary" style="width: auto; height: 38px;">Fetch</button>
          </div>
          <pre id="supa-output">Tap Fetch to query your Apps Supabase table.</pre>
        </section>
      </div>
    </main>

    <script id="owner-admin-config" type="application/json">${sanitizeJsonForScriptTag(runtimeConfig)}</script>
    <script>
      (function () {
        var cfg = JSON.parse(document.getElementById('owner-admin-config').textContent || '{}');
        var gate = document.getElementById('pin-gate');
        var dash = document.getElementById('owner-dashboard');
        var badge = document.getElementById('lock-badge');
        var pinInput = document.getElementById('pin-input');
        var pinErr = document.getElementById('pin-error');
        var supaStatus = document.getElementById('supa-status');
        var supaOut = document.getElementById('supa-output');
        var maintEl = document.getElementById('toggle-maintenance');
        var bannerEl = document.getElementById('toggle-banner');
        var flagsMsg = document.getElementById('flags-msg');
        var FLAGS_KEY = 'sarfealam_owner_flags_' + (cfg.appName || 'app');

        function digestPin(pin) {
          var salted = 'sarfealam-owner-v1::' + String(pin || '').trim();
          var h1 = 0x811c9dc5;
          var h2 = 0x9e3779b9;
          for (var i = 0; i < salted.length; i++) {
            var c = salted.charCodeAt(i);
            h1 ^= c;
            h1 = Math.imul(h1, 0x01000193);
            h2 ^= c + ((i + 1) * 31);
            h2 = Math.imul(h2, 0x85ebca6b);
          }
          return (h1 >>> 0).toString(16).padStart(8, '0') + (h2 >>> 0).toString(16).padStart(8, '0');
        }

        function loadFlags() {
          try {
            var saved = JSON.parse(localStorage.getItem(FLAGS_KEY) || '{}');
            maintEl.checked = Boolean(saved.maintenance);
            bannerEl.checked = Boolean(saved.banner);
          } catch (e) {}
        }

        function unlock() {
          gate.classList.add('hidden');
          dash.classList.remove('hidden');
          badge.textContent = 'Owner Unlocked';
          badge.className = 'badge ok';
          supaStatus.textContent = cfg.appsSupabaseUrl && cfg.appsSupabaseAnonKey ? 'Connected' : 'Local Only';
          loadFlags();
        }

        function lock() {
          dash.classList.add('hidden');
          gate.classList.remove('hidden');
          badge.textContent = 'PIN Locked';
          badge.className = 'badge warn';
          pinInput.value = '';
          sessionStorage.removeItem('owner_unlocked');
        }

        if (sessionStorage.getItem('owner_unlocked') === cfg.pinDigest) {
          unlock();
        }

        document.getElementById('pin-form').addEventListener('submit', function (e) {
          e.preventDefault();
          var entered = digestPin(pinInput.value);
          if (entered === cfg.pinDigest) {
            pinErr.style.display = 'none';
            sessionStorage.setItem('owner_unlocked', cfg.pinDigest);
            unlock();
          } else {
            pinErr.style.display = 'block';
          }
        });

        document.getElementById('lock-btn').addEventListener('click', lock);

        document.getElementById('save-flags-btn').addEventListener('click', function () {
          var payload = {
            app_name: cfg.appName,
            version: cfg.version,
            maintenance: maintEl.checked,
            banner: bannerEl.checked,
            updated_at: new Date().toISOString()
          };
          localStorage.setItem(FLAGS_KEY, JSON.stringify(payload));
          flagsMsg.textContent = 'Saved flags locally.';

          if (cfg.appsSupabaseUrl && cfg.appsSupabaseAnonKey) {
            var ctrl = new AbortController();
            var t = setTimeout(function () { ctrl.abort(); }, 6000);
            fetch(cfg.appsSupabaseUrl + '/rest/v1/app_config', {
              method: 'POST',
              signal: ctrl.signal,
              headers: {
                apikey: cfg.appsSupabaseAnonKey,
                Authorization: 'Bearer ' + cfg.appsSupabaseAnonKey,
                'Content-Type': 'application/json',
                Prefer: 'return=minimal'
              },
              body: JSON.stringify(payload)
            }).then(function (r) {
              clearTimeout(t);
              flagsMsg.textContent = r.ok ? 'Saved locally & synced to Apps Supabase.' : 'Saved locally (Apps Supabase HTTP ' + r.status + ').';
            }).catch(function () {
              clearTimeout(t);
              flagsMsg.textContent = 'Saved locally (Apps Supabase unreachable).';
            });
          }
        });

        document.getElementById('query-btn').addEventListener('click', function () {
          var table = String(document.getElementById('table-input').value || '').trim().replace(/[^a-zA-Z0-9_]/g, '');
          if (!table) {
            supaOut.textContent = 'Enter a valid table name.';
            return;
          }
          if (!cfg.appsSupabaseUrl || !cfg.appsSupabaseAnonKey) {
            supaOut.textContent = 'Apps Supabase credentials were not configured during export.';
            return;
          }
          supaOut.textContent = 'Querying ' + table + '...';
          var ctrl = new AbortController();
          var t = setTimeout(function () { ctrl.abort(); }, 6000);
          fetch(cfg.appsSupabaseUrl + '/rest/v1/' + encodeURIComponent(table) + '?select=*&limit=10', {
            method: 'GET',
            signal: ctrl.signal,
            headers: {
              apikey: cfg.appsSupabaseAnonKey,
              Authorization: 'Bearer ' + cfg.appsSupabaseAnonKey
            }
          }).then(function (r) {
            clearTimeout(t);
            return r.text().then(function (txt) {
              try {
                supaOut.textContent = 'HTTP ' + r.status + '\\n' + JSON.stringify(JSON.parse(txt), null, 2);
              } catch (e) {
                supaOut.textContent = 'HTTP ' + r.status + '\\n' + txt.slice(0, 1200);
              }
            });
          }).catch(function (err) {
            clearTimeout(t);
            supaOut.textContent = 'Query failed: ' + (err && err.message ? err.message : 'Network error');
          });
        });
      })();
    </script>
  </body>
</html>
`;
}

export function generateApkWorkflowYaml(appName: string, version: string): string {
  const safeName = appName.trim() || 'Sarfealam App';
  const safePkg = slugifyPackageName(safeName);
  const safeVersion = version.trim() || '1.0.0';

  return `name: Build Capacitor 6 Android APK & Deploy Pages

on:
  push:
    branches: [ main, master ]
  workflow_dispatch:

permissions:
  contents: write
  pages: write
  id-token: write

concurrency:
  group: "pages-and-apk"
  cancel-in-progress: false

jobs:
  deploy-pages:
    name: Deploy Web & Admin to GitHub Pages
    runs-on: ubuntu-latest
    environment:
      name: github-pages
      url: \${{ steps.deployment.outputs.page_url }}
    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Setup Pages
        uses: actions/configure-pages@v5

      - name: Upload docs artifact
        uses: actions/upload-pages-artifact@v3
        with:
          path: './docs'

      - name: Deploy to GitHub Pages
        id: deployment
        uses: actions/deploy-pages@v4

  build-android-apk:
    name: Build Capacitor 6 APK (Java 21 + Node 22)
    runs-on: ubuntu-latest
    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Setup Node.js 22
        uses: actions/setup-node@v4
        with:
          node-version: '22'

      - name: Setup Java 21 (Temurin)
        uses: actions/setup-java@v4
        with:
          distribution: 'temurin'
          java-version: '21'

      - name: Setup Android SDK
        uses: android-actions/setup-android@v3

      - name: Prepare Capacitor 6 Web Bundle
        run: |
          mkdir -p www
          cp -r docs/* www/ || true
          if [ -f index.html ] && [ ! -f www/index.html ]; then cp index.html www/index.html; fi
          if [ -d assets ]; then mkdir -p www/assets && cp -r assets/* www/assets/ || true; fi
          if [ ! -f package.json ]; then
            cat << 'EOF' > package.json
          {
            "name": "${safePkg}",
            "version": "${safeVersion}",
            "private": true
          }
          EOF
          fi
          npm install @capacitor/core@^6.2.0 @capacitor/cli@^6.2.0 @capacitor/android@^6.2.0
          if [ ! -f capacitor.config.json ]; then
            cat << 'EOF' > capacitor.config.json
          {
            "appId": "com.sarfealam.${safePkg}",
            "appName": "${safeName.replace(/"/g, '\\"')}",
            "webDir": "www",
            "bundledWebRuntime": false
          }
          EOF
          fi
          if [ ! -d android ]; then
            npx cap add android
          fi
          npx cap sync android

      - name: Assemble Debug APK
        working-directory: android
        run: |
          chmod +x gradlew
          ./gradlew assembleDebug

      - name: Upload APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: ${safePkg}-v${safeVersion}-debug-apk
          path: android/app/build/outputs/apk/debug/app-debug.apk

      - name: Publish APK Release
        uses: softprops/action-gh-release@v2
        with:
          tag_name: v${safeVersion}-\${{ github.run_number }}
          name: "${safeName.replace(/"/g, '\\"')} v${safeVersion} (Build #\${{ github.run_number }})"
          files: android/app/build/outputs/apk/debug/app-debug.apk
        env:
          GITHUB_TOKEN: \${{ secrets.GITHUB_TOKEN }}
`;
}

async function fetchGitHubWith10sTimeout(
  url: string,
  init: RequestInit,
  externalSignal?: AbortSignal
): Promise<Response> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), GITHUB_API_TIMEOUT_MS);

  const onExternalAbort = () => controller.abort();
  if (externalSignal) {
    if (externalSignal.aborted) {
      window.clearTimeout(timer);
      throw new DOMException('Export aborted', 'AbortError');
    }
    externalSignal.addEventListener('abort', onExternalAbort, { once: true });
  }

  try {
    return await fetch(url, { ...init, signal: controller.signal });
  } finally {
    window.clearTimeout(timer);
    if (externalSignal) {
      externalSignal.removeEventListener('abort', onExternalAbort);
    }
  }
}

function buildGitHubAuthHeaders(pat: string): Record<string, string> {
  return {
    Accept: 'application/vnd.github+json',
    Authorization: `Bearer ${pat.trim()}`,
    'Content-Type': 'application/json',
    'X-GitHub-Api-Version': '2022-11-28',
  };
}

function resolveTargetRepoFromSecrets(secrets: StudioSecrets): string {
  if (secrets.targetRepo?.trim()) {
    return secrets.targetRepo.trim();
  }
  const owner = secrets.githubOwner?.trim() ?? '';
  const repo = secrets.githubRepo?.trim() ?? '';
  if (owner && repo) {
    return `${owner}/${repo}`;
  }
  return '';
}

function resolveEntryHtml(files: VirtualFile[], appName: string): string {
  const rootIndex = files.find((f) => f.path.toLowerCase() === 'index.html');
  const docsIndex = files.find((f) => f.path.toLowerCase() === 'docs/index.html');

  if (rootIndex && docsIndex) {
    return rootIndex.updatedAt >= docsIndex.updatedAt
      ? rootIndex.content
      : docsIndex.content;
  }
  if (rootIndex) return rootIndex.content;
  if (docsIndex) return docsIndex.content;

  return `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>${escapeHtml(appName)}</title>
  </head>
  <body>
    <main style="font-family:sans-serif;padding:24px;">
      <h1>${escapeHtml(appName)}</h1>
      <p>Exported via Sarfealam Auto-Studio.</p>
    </main>
  </body>
</html>
`;
}

function resolveAssetsManifest(files: VirtualFile[], appName: string): string {
  const existing = files.find(
    (f) => f.path.toLowerCase() === 'assets/manifest.json'
  );
  if (existing && existing.content.trim()) {
    return existing.content;
  }
  return `${JSON.stringify(
    {
      studio: 'Sarfealam Auto-Studio',
      appName,
      schemaVersion: 1,
      updatedAt: new Date().toISOString(),
      assets: [],
    },
    null,
    2
  )}\n`;
}

/**
 * 1-Commit Atomic GitHub Trees API Exporter:
 * Pushes `index.html`, `docs/index.html`, `docs/admin.html`, `assets/manifest.json`,
 * and `.github/workflows/build-apk.yml` (plus safe workspace files) in 1 single atomic commit.
 */
export async function atomicPushToGitHub(
  options: AtomicPushToGitHubOptions
): Promise<AtomicPushToGitHubResult> {
  const appName = options.appName.trim() || 'Sarfealam App';
  const version = (options.version || '1.0.0').trim();
  const pat = options.secrets.githubToken?.trim() ?? '';
  const rawRepo = resolveTargetRepoFromSecrets(options.secrets);
  const parsedRepo = parseGitHubRepoInput(rawRepo);

  const emptyFailure = (error: string): AtomicPushToGitHubResult => ({
    ok: false,
    commitSha: '',
    repo: parsedRepo?.normalized ?? rawRepo,
    branch: options.branch?.trim() || 'main',
    pagesUrl: '',
    adminUrl: '',
    actionsUrl: '',
    apkReleaseUrl: '',
    filesPushed: 0,
    error,
  });

  if (!pat) {
    studioBus.emit('bot:progress', {
      botId: 'github',
      status: 'error',
      progress: 0,
      message: 'Missing GitHub PAT in Secrets',
    });
    return emptyFailure(
      'GitHub Personal Access Token (PAT) is required in Secrets for 1-Commit export.'
    );
  }

  if (!parsedRepo) {
    studioBus.emit('bot:progress', {
      botId: 'github',
      status: 'error',
      progress: 0,
      message: 'Invalid target GitHub repo (owner/repo)',
    });
    return emptyFailure(
      'Configure Target Repo (owner/repo) or GitHub Owner + Repo in Secrets first.'
    );
  }

  const { owner, repo, normalized } = parsedRepo;
  const headers = buildGitHubAuthHeaders(pat);
  const apiBase = `https://api.github.com/repos/${encodeURIComponent(
    owner
  )}/${encodeURIComponent(repo)}`;

  createActiveJob({
    title: `GitHub 1-Commit Export (${appName})`,
    stage: '5. Package',
    paused: false,
    targetRepo: normalized,
    status: 'exporting',
    runId: null,
  });

  studioBus.emit('bot:progress', {
    botId: 'github',
    status: 'working',
    progress: 12,
    message: `Preparing atomic bundle for ${normalized}...`,
  });

  try {
    await waitIfPaused(options.signal);

    // 1. Resolve default branch if not explicitly supplied
    let branch = options.branch?.trim() || '';
    if (!branch) {
      const repoRes = await fetchGitHubWith10sTimeout(
        apiBase,
        { method: 'GET', headers },
        options.signal
      );
      if (!repoRes.ok) {
        throw new Error(
          repoRes.status === 404
            ? `Repository ${normalized} not found or token lacks repo scope.`
            : `Unable to read repository metadata (HTTP ${repoRes.status}).`
        );
      }
      const repoJson = (await repoRes.json()) as { default_branch?: string };
      branch = repoJson.default_branch?.trim() || 'main';
    }

    studioBus.emit('bot:progress', {
      botId: 'github',
      status: 'working',
      progress: 25,
      message: `Reading HEAD ref (${branch})...`,
    });

    // 2. GET /git/ref/heads/${branch}
    const refRes = await fetchGitHubWith10sTimeout(
      `${apiBase}/git/ref/heads/${encodeURIComponent(branch)}`,
      { method: 'GET', headers },
      options.signal
    );
    if (!refRes.ok) {
      throw new Error(
        `Failed to fetch branch ref heads/${branch} (HTTP ${refRes.status}). Ensure repo has an initial commit.`
      );
    }
    const refJson = (await refRes.json()) as { object?: { sha?: string } };
    const baseCommitSha = refJson.object?.sha?.trim();
    if (!baseCommitSha) {
      throw new Error('GitHub ref response missing base commit SHA.');
    }

    // 3. GET /git/commits/${baseCommitSha} to retrieve base tree SHA
    const baseCommitRes = await fetchGitHubWith10sTimeout(
      `${apiBase}/git/commits/${encodeURIComponent(baseCommitSha)}`,
      { method: 'GET', headers },
      options.signal
    );
    if (!baseCommitRes.ok) {
      throw new Error(
        `Failed to read base commit ${baseCommitSha.slice(0, 7)} (HTTP ${baseCommitRes.status}).`
      );
    }
    const baseCommitJson = (await baseCommitRes.json()) as {
      tree?: { sha?: string };
    };
    const baseTreeSha = baseCommitJson.tree?.sha?.trim();
    if (!baseTreeSha) {
      throw new Error('Base commit missing tree SHA.');
    }

    // Build atomic file map (enforcing Apps-only Supabase isolation in docs/admin.html)
    const now = Date.now();
    const entryHtml = resolveEntryHtml(options.files, appName);
    const manifestJson = resolveAssetsManifest(options.files, appName);
    const adminHtml = generateOwnerAdminHtml({
      appName,
      version,
      ownerPin: options.ownerPin,
      appsSupabaseUrl: options.secrets.appsSupabaseUrl,
      appsSupabaseAnonKey: options.secrets.appsSupabaseAnonKey,
    });
    const workflowYaml = generateApkWorkflowYaml(appName, version);

    const generatedAdminFile: VirtualFile = {
      path: 'docs/admin.html',
      content: adminHtml,
      language: 'html',
      updatedAt: now,
      generatedBy: 'github',
    };
    const workflowFile: VirtualFile = {
      path: '.github/workflows/build-apk.yml',
      content: workflowYaml,
      language: 'yaml',
      updatedAt: now,
      generatedBy: 'github',
    };

    const bundleMap = new Map<string, string>();
    // Include safe non-secret workspace files first
    for (const file of options.files) {
      const cleanPath = file.path.trim().replace(/^\/+/, '');
      if (!cleanPath || cleanPath.includes('..') || cleanPath.startsWith('.env')) {
        continue;
      }
      bundleMap.set(cleanPath, file.content);
    }

    // Set required atomic export deliverables
    bundleMap.set('index.html', entryHtml);
    bundleMap.set('docs/index.html', entryHtml);
    bundleMap.set('docs/admin.html', adminHtml);
    bundleMap.set('assets/manifest.json', manifestJson);
    bundleMap.set('.github/workflows/build-apk.yml', workflowYaml);

    const entries = Array.from(bundleMap.entries());

    // 4. POST /git/blobs for each file
    const treeItems: {
      path: string;
      mode: '100644';
      type: 'blob';
      sha: string;
    }[] = [];

    for (let i = 0; i < entries.length; i++) {
      await waitIfPaused(options.signal);
      const [filePath, content] = entries[i];
      const progress = Math.min(
        72,
        30 + Math.round(((i + 1) / entries.length) * 42)
      );
      studioBus.emit('bot:progress', {
        botId: 'github',
        status: 'working',
        progress,
        message: `Creating blob ${i + 1}/${entries.length} (${filePath})...`,
      });

      const blobRes = await fetchGitHubWith10sTimeout(
        `${apiBase}/git/blobs`,
        {
          method: 'POST',
          headers,
          body: JSON.stringify({
            content,
            encoding: 'utf-8',
          }),
        },
        options.signal
      );

      if (!blobRes.ok) {
        throw new Error(
          `Failed to create blob for ${filePath} (HTTP ${blobRes.status}).`
        );
      }

      const blobJson = (await blobRes.json()) as { sha?: string };
      if (!blobJson.sha) {
        throw new Error(`GitHub returned empty blob SHA for ${filePath}.`);
      }

      treeItems.push({
        path: filePath,
        mode: '100644',
        type: 'blob',
        sha: blobJson.sha,
      });
    }

    studioBus.emit('bot:progress', {
      botId: 'github',
      status: 'working',
      progress: 80,
      message: 'Creating atomic Git tree...',
    });

    // 5. POST /git/trees
    const treeRes = await fetchGitHubWith10sTimeout(
      `${apiBase}/git/trees`,
      {
        method: 'POST',
        headers,
        body: JSON.stringify({
          base_tree: baseTreeSha,
          tree: treeItems,
        }),
      },
      options.signal
    );
    if (!treeRes.ok) {
      throw new Error(`Failed to create Git tree (HTTP ${treeRes.status}).`);
    }
    const treeJson = (await treeRes.json()) as { sha?: string };
    const newTreeSha = treeJson.sha?.trim();
    if (!newTreeSha) {
      throw new Error('GitHub tree response missing SHA.');
    }

    studioBus.emit('bot:progress', {
      botId: 'github',
      status: 'working',
      progress: 90,
      message: 'Creating single atomic commit...',
    });

    // 6. POST /git/commits
    const commitMessage =
      options.commitMessage?.trim() ||
      `feat(studio): atomic export ${appName} v${version} (Web + Owner Admin + APK workflow)`;
    const commitRes = await fetchGitHubWith10sTimeout(
      `${apiBase}/git/commits`,
      {
        method: 'POST',
        headers,
        body: JSON.stringify({
          message: commitMessage,
          tree: newTreeSha,
          parents: [baseCommitSha],
        }),
      },
      options.signal
    );
    if (!commitRes.ok) {
      throw new Error(`Failed to create Git commit (HTTP ${commitRes.status}).`);
    }
    const commitJson = (await commitRes.json()) as { sha?: string };
    const newCommitSha = commitJson.sha?.trim();
    if (!newCommitSha) {
      throw new Error('GitHub commit response missing SHA.');
    }

    // 7. PATCH /git/refs/heads/${branch}
    const patchRefRes = await fetchGitHubWith10sTimeout(
      `${apiBase}/git/refs/heads/${encodeURIComponent(branch)}`,
      {
        method: 'PATCH',
        headers,
        body: JSON.stringify({
          sha: newCommitSha,
          force: false,
        }),
      },
      options.signal
    );
    if (!patchRefRes.ok) {
      throw new Error(
        `Failed to update branch heads/${branch} (HTTP ${patchRefRes.status}). Check token workflow & contents permissions.`
      );
    }

    const pagesBase = `https://${owner.toLowerCase()}.github.io/${repo}`;
    const pagesUrl = `${pagesBase}/`;
    const adminUrl = `${pagesBase}/admin.html`;
    const actionsUrl = `https://github.com/${owner}/${repo}/actions`;
    const apkReleaseUrl = `https://github.com/${owner}/${repo}/releases`;

    patchActiveJob({
      status: 'polling',
      stage: '5. Package',
      targetRepo: normalized,
      paused: false,
    });

    studioBus.emit('bot:progress', {
      botId: 'github',
      status: 'ready',
      progress: 100,
      message: `Atomic commit ${newCommitSha.slice(0, 7)} pushed (${treeItems.length} files)`,
    });

    return {
      ok: true,
      commitSha: newCommitSha,
      repo: normalized,
      branch,
      pagesUrl,
      adminUrl,
      actionsUrl,
      apkReleaseUrl,
      filesPushed: treeItems.length,
      generatedAdminFile,
      workflowFile,
    };
  } catch (err) {
    const isTimeout = err instanceof DOMException && err.name === 'AbortError';
    const message = isTimeout
      ? 'GitHub export timed out after 10s.'
      : err instanceof Error
        ? err.message
        : 'Atomic GitHub push failed.';

    patchActiveJob({
      status: 'failed',
    });

    studioBus.emit('bot:progress', {
      botId: 'github',
      status: 'error',
      progress: 0,
      message,
    });

    return emptyFailure(message);
  }
}
