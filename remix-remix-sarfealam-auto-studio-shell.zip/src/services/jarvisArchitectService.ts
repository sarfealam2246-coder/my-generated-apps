import { requestStudioAICompletion } from './aiRouter';
import { buildMemoryContext } from './memoryService';
import type {
  Language,
  LockedStepPlanItem,
  WorldState,
} from '../types/studio';

export interface GenerateLockedStepPlanOptions {
  goal: string;
  language: Language;
  state: WorldState;
}

export interface GenerateLockedStepPlanResult {
  ok: boolean;
  reply: string;
  steps: LockedStepPlanItem[];
  providerUsed: string;
  errorNote?: string;
}

/**
 * Permanent JARVIS Architect rules live in TypeScript so swapping any API key
 * in Universal Key Pool (Groq, NVIDIA, Cloudflare, Gemini, OpenRouter, Cohere)
 * acts strictly as Fuel without altering JARVIS's decomposition discipline.
 */
const ARCHITECT_CORE_RULES = [
  'You are Sarfealam Auto-Studio JARVIS Architect.',
  'Decompose any requested game or commercial app into 4 to 6 small, atomic, sequential build steps.',
  'Each step MUST be self-contained, testable, and preserve all previous steps without regression.',
  'Every step MUST enforce mobile 360px no-overflow safety, offline-first resilience, and Android WebView compatibility (zero importmap, zero esm.sh).',
  'For EVERY step N (starting at 1):',
  '- Step 1 lockedPrompt MUST start with: "STRICT STEP 1 LOCK — DO NOT MODIFY OR BREAK EXISTING FEATURES:"',
  '- Step N (N > 1) lockedPrompt MUST start with: "STRICT STEP N LOCK — DO NOT MODIFY OR BREAK STEPS 1..(N-1):"',
  '- Every lockedPrompt MUST include: "Do NOT build Step (N+1) yet."',
  'Return STRICT JSON ONLY (no markdown fences) matching this exact schema:',
  '{"summary":"concise 1-2 sentence overview","steps":[{"stepNumber":1,"title":"Short Step Title","lockedPrompt":"Full locked implementation prompt for this step"}]}',
];

export function detectArchitectPlanIntent(text: string): boolean {
  const clean = text.trim().toLowerCase();
  if (!clean) return false;

  const patterns: RegExp[] = [
    /\bsteps?\s+banao\b/i,
    /\bstep\s+by\s+step(\s+plan|\s+roadmap|\s+banao)?\b/i,
    /\bplan\s+lock\s+karo\b/i,
    /\block(ed)?\s+step(s|\s+plan)?\b/i,
    /\bmake\s+(a\s+)?step[\s-]+by[\s-]+step(\s+plan)?\b/i,
    /\broadmap\s+banao\b/i,
    /\b(build|project|architecture|dev|development)\s+(roadmap|step\s+plan)\b/i,
    /\bsteps?\s+(me|mein)\s+(todo|tod|divide|split|baanto|banto)\b/i,
    /स्टेप्स?\s*बनाओ/,
    /प्लान\s*लॉक\s*करो/,
    /रोडमैप\s*बनाओ/,
    /स्टेप\s*बाय\s*स्टेप/,
  ];

  return patterns.some((re) => re.test(clean));
}

function enforceLockedPromptFormat(
  stepNumber: number,
  title: string,
  rawPrompt: string
): string {
  const trimmed = rawPrompt.trim();
  const lockHeader =
    stepNumber <= 1
      ? 'STRICT STEP 1 LOCK — DO NOT MODIFY OR BREAK EXISTING FEATURES:'
      : `STRICT STEP ${stepNumber} LOCK — DO NOT MODIFY OR BREAK STEPS 1..${stepNumber - 1}:`;
  const nextGuard = `Do NOT build Step ${stepNumber + 1} yet.`;

  let out = trimmed;

  if (!new RegExp(`^STRICT\\s+STEP\\s+${stepNumber}\\s+LOCK`, 'i').test(out)) {
    out = `${lockHeader}\nBuild ONLY Step ${stepNumber} (${title}).\n${out}`;
  }

  if (!new RegExp(`Do\\s+NOT\\s+build\\s+Step\\s+${stepNumber + 1}\\s+yet`, 'i').test(out)) {
    out = `${out}\n${nextGuard}`;
  }

  return out.trim();
}

function parseArchitectJson(
  rawText: string
): { summary: string; steps: LockedStepPlanItem[] } | null {
  const trimmed = rawText.trim();
  if (!trimmed) return null;

  const fenceMatch = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const candidate = fenceMatch ? fenceMatch[1].trim() : trimmed;

  const tryParse = (
    str: string
  ): { summary: string; steps: LockedStepPlanItem[] } | null => {
    try {
      const parsed: unknown = JSON.parse(str);
      if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
        return null;
      }
      const obj = parsed as Record<string, unknown>;
      if (!Array.isArray(obj.steps) || obj.steps.length === 0) {
        return null;
      }

      const steps: LockedStepPlanItem[] = [];
      for (let i = 0; i < obj.steps.length; i++) {
        const rawItem = obj.steps[i];
        if (!rawItem || typeof rawItem !== 'object') continue;
        const rec = rawItem as Record<string, unknown>;
        const stepNumber =
          typeof rec.stepNumber === 'number' && Number.isFinite(rec.stepNumber) && rec.stepNumber >= 1
            ? Math.floor(rec.stepNumber)
            : i + 1;
        const title =
          typeof rec.title === 'string' && rec.title.trim()
            ? rec.title.trim()
            : `Step ${stepNumber}`;
        const rawPrompt =
          typeof rec.lockedPrompt === 'string' && rec.lockedPrompt.trim()
            ? rec.lockedPrompt.trim()
            : typeof rec.prompt === 'string' && rec.prompt.trim()
              ? rec.prompt.trim()
              : '';
        if (!rawPrompt) continue;

        steps.push({
          stepNumber,
          title,
          lockedPrompt: enforceLockedPromptFormat(stepNumber, title, rawPrompt),
        });
      }

      if (steps.length === 0) return null;

      // Normalize sequential numbering 1..N
      const normalized = steps.slice(0, 8).map((s, idx) => {
        const num = idx + 1;
        return {
          stepNumber: num,
          title: s.title,
          lockedPrompt: enforceLockedPromptFormat(num, s.title, s.lockedPrompt),
        };
      });

      const summary =
        typeof obj.summary === 'string' && obj.summary.trim()
          ? obj.summary.trim()
          : `Locked ${normalized.length}-step build plan generated.`;

      return { summary, steps: normalized };
    } catch {
      return null;
    }
  };

  const direct = tryParse(candidate);
  if (direct) return direct;

  const firstBrace = candidate.indexOf('{');
  const lastBrace = candidate.lastIndexOf('}');
  if (firstBrace !== -1 && lastBrace > firstBrace) {
    return tryParse(candidate.slice(firstBrace, lastBrace + 1));
  }

  return null;
}

function buildFallbackLockedSteps(
  goal: string,
  state: WorldState
): LockedStepPlanItem[] {
  const cleanGoal = goal.trim() || state.projectName || 'Studio App';
  const isGame = /(game|3d|drive|racing|truck|car|fps|village|shooter|गेम)/i.test(
    cleanGoal
  );

  const blueprint = isGame
    ? [
        {
          title: 'Core Shell, Scene & Camera Rig',
          body: `Create the responsive 360px mobile container and classic WebView-safe Three.js scene for "${cleanGoal}" with sky, lighting, ground plane, and smooth follow camera.`,
        },
        {
          title: 'Player Physics & Mobile Touch Controls',
          body: `Add responsive multi-touch steering, throttle/brake controls, collision checks, and smooth 60fps animation loop for "${cleanGoal}".`,
        },
        {
          title: 'World Props, Assets & Web Audio SFX',
          body: `Wire selected Vault and Open-Web assets into "${cleanGoal}", populate environment landmarks/traffic, and unlock Web Audio SFX on first touch.`,
        },
        {
          title: 'HUD Polish, Score Loop & Export Readiness',
          body: `Add compact non-occluding HUD, objective/score persistence in localStorage, and verify zero runtime errors in Display A preview.`,
        },
      ]
    : [
        {
          title: 'App Shell, Navigation & Design System',
          body: `Build the mobile-first 360px layout, frosted-glass header/navigation, and clean state container for "${cleanGoal}".`,
        },
        {
          title: 'Core Interactive Feature Flows',
          body: `Implement the primary interactive screens, forms, filters, and live previews required by "${cleanGoal}" with zero placeholder dead buttons.`,
        },
        {
          title: 'Offline Persistence & Asset Integration',
          body: `Wire offline localStorage/IndexedDB persistence, selected Vault/Open-Web media assets, and reactive state updates for "${cleanGoal}".`,
        },
        {
          title: 'QA Polish, Edge-Case Handling & Packaging',
          body: `Add validation states, empty/error boundaries, performance polish, and verify clean lint + build with zero Display A runtime errors.`,
        },
      ];

  return blueprint.map((item, idx) => {
    const stepNumber = idx + 1;
    return {
      stepNumber,
      title: item.title,
      lockedPrompt: enforceLockedPromptFormat(stepNumber, item.title, item.body),
    };
  });
}

export async function generateLockedStepPlan(
  options: GenerateLockedStepPlanOptions
): Promise<GenerateLockedStepPlanResult> {
  const { goal, language, state } = options;
  const cleanGoal = goal.trim() || state.projectName || 'Mobile App';
  const memoryBlock = buildMemoryContext(state.memoryRules);
  const filesList = state.files.map((f) => f.path).join(', ') || 'none';

  const systemPrompt = [
    ...ARCHITECT_CORE_RULES,
    language === 'hi'
      ? 'Write the "summary" in natural, clear Hindi/Hinglish. Keep each "lockedPrompt" in crisp technical English so any coding builder executes it cleanly.'
      : 'Write the "summary" and each "lockedPrompt" in crisp, unambiguous technical English.',
    ...(memoryBlock ? [memoryBlock] : []),
  ].join('\n');

  const userPrompt = [
    `Project Name: ${state.projectName}`,
    `Target Engine: ${state.targetEngine}`,
    `Current Stage: ${state.currentStage}`,
    `Workspace Files: [${filesList}]`,
    `Selected Assets Count: ${state.selectedAssets.length}`,
    '',
    `User Goal / Request: ${cleanGoal}`,
    '',
    'Decompose this goal into 4 to 5 locked sequential build steps.',
  ].join('\n');

  const completion = await requestStudioAICompletion(
    systemPrompt,
    userPrompt,
    state
  );

  if (completion.ok) {
    const parsed = parseArchitectJson(completion.rawText);
    if (parsed && parsed.steps.length > 0) {
      return {
        ok: true,
        reply: parsed.summary,
        steps: parsed.steps,
        providerUsed: `JARVIS Architect · ${completion.providerUsed}`,
      };
    }
  }

  const fallbackSteps = buildFallbackLockedSteps(cleanGoal, state);
  const fallbackReply =
    language === 'hi'
      ? `JARVIS Architect ने "${cleanGoal}" के लिए ${fallbackSteps.length} लॉक्ड स्टेप्स तैयार किए हैं। किसी भी कार्ड पर "Copy" या "Send to Builder" टैप करें।`
      : `JARVIS Architect locked a ${fallbackSteps.length}-step plan for "${cleanGoal}". Tap "Copy" or "Send to Builder" on any step card below.`;

  return {
    ok: true,
    reply: fallbackReply,
    steps: fallbackSteps,
    providerUsed: 'JARVIS Architect (Local)',
    errorNote: completion.error,
  };
}
